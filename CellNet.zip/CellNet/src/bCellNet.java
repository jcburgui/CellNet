
import java.util.Locale;
import java.util.Vector;

		



















// BEGIN: Imports used to reproduce sound
import javax.sound.sampled.Clip;
import javax.sound.sampled.AudioSystem;

import java.io.File;
		// END: Imports used to reproduce sound





















import window.MainWindow;
import file.IOFile;
import games.*;
import games.coaIPD.GameCoaIPD;
import games.coaLife.GameCoaLife;
import games.coaOptimization.GameCoaOptimization;
import games.coaPrediction.GameCoaPrediction;
import games.coaReputation.GameCoaReputation;
import games.iHawkDovePossessorTrader.GameHDPT;
import games.satBall.GameSatBall;
import games.socialGroups.GameSocialGroups;


/**
 * Cellular Networks in Batch Mode
 *
 * @author  Juan C. Burguillo Rial
 * @version 1.0
 */
public class bCellNet implements GameCons {
public Game oGame;


public static void main (String args[]) {
	
  bCellNet oLanzador = new bCellNet(); 
  
  MainWindow.iBatchMode = 2;

  //Game.iGameType = iSOCIALGROUPS;
  //Game.iGameType = iCOA_LIFE;
  //Game.iGameType = iSAT_BALL;
  //Game.iGameType = iPRISONERs_DILEMMA;
  //Game.iGameType = iHAWK_DOVE_POS_TRADER;  
  //Game.iGameType = iCOA_IPD;
  Game.iGameType = iCOA_REPUTATION;
  //Game.iGameType = iCOA_OPTIMIZATION;
  //Game.iGameType = iCOA_PREDICTION;


  switch (Game.iGameType) {
	case Game.iSOCIALGROUPS:                       oLanzador.oGame = new GameSocialGroups(); break;
	case Game.iCOA_LIFE:                    oLanzador.oGame = new GameCoaLife (); break;
	case Game.iSAT_BALL:                    oLanzador.oGame = new GameSatBall(); break;
	case Game.iPRISONERs_DILEMMA:
	case Game.iHAWK_DOVE_POSS_TRADER:       oLanzador.oGame = new GameHDPT (); break;
	case Game.iCOA_IPD:                     oLanzador.oGame = new GameCoaIPD (); break;
	case Game.iCOA_REPUTATION:     					oLanzador.oGame = new GameCoaReputation (); break;
	case Game.iCOA_OPTIMIZATION:            oLanzador.oGame = new GameCoaOptimization (); break;
	case Game.iCOA_PREDICTION:              oLanzador.oGame = new GameCoaPrediction (); break;
	}

  oLanzador.vBatchRun (args);
  }






/**
 * This method contains the code to be executed in batch mode for the GameReputation
 */
private void vBatchRun (String[] args) {
  int iSimEstable = 0;
  int iTimeMin, iTimeSec;
  int iNumRuns=100;							// Number of executions to average
  int[][] imNumTimesStrat = new int[iNumRuns][12];
  int[] imTotNumTimesStrat = new int[12];		// 12 Strategies
  int iTotNumTimesStratC=0, iTotNumTimesStratD=0;
  double dAux, dTimeA, dTimeB;
  double[] dmAvg = new double[12];
  double[] dmVar = new double[12];
  double[] dmStdDev = new double [12];
  
  
//-------------------------------- INI: BATCH Reputation ---------------------------------------

  Game.iGameType = iCOA_REPUTATION;
  Game.iChangeType = 0;
  Game.iNetType = 0;
  Game.dProbMut = 0;
  Game.dProbRewireRandom = 0;		// Rewires to the best

  System.out.println ("CellNet: " + sGAME_TYPE[Game.iGameType]);
  System.out.println ("NumGen: "+Game.iNumGen+"     N: "+Game.iTotPosMatrix);
  System.out.println ("Game: "+Game.iGameType);
  System.out.println ("Net: "+Game.iNetType);

  
  MainWindow.iOutputMode = iOUTPUT_VERBOSE;
  //MainWindow.iOutputMode = iOUTPUT_PYTHON;
  
  //MainWindow.iGenStopTMP = MainWindow.iGenStop;
  MainWindow.iGenStopTMP = 500;
  
  iNumRuns = 5;
  
  System.out.print ("\n#>>> bCellNet Reputation: STARTING THE BATCH ("+ iNumRuns +" RUNS) !!!\n\n");
  dTimeA = System.currentTimeMillis();

  //for (int iNet=0; iNet<=3; iNet++) {     	// Networks: 0->SP	1->SW	 2->SF	3->RN
  for (int iNet=0; iNet<=0; iNet++) {     // Networks: 0->SP	1->SW	 2->SF	3->RN
		Game.iNetType = iNet;
		if (MainWindow.iOutputMode == iOUTPUT_VERBOSE)
		  System.out.print ("\n ******* Net: " + sCOMPLEX_NET[iNet] + " *******");

  //for (int iCoa=0; iCoa<=1; iCoa++) {     				// Coalitions 0 false, 1 true
  for (int iCoa=1; iCoa<=1; iCoa++) {     				// Coalitions 0 false, 1 true
  	if (iCoa == 0) Game.bCoalitions = false;
  	else Game.bCoalitions = true;
  	if (MainWindow.iOutputMode == iOUTPUT_VERBOSE)
      System.out.print ("\n bCoalitions: " + Game.bCoalitions);
  
  //for (double dPrew=0; dPrew<=1; dPrew+=0.1) {     			// Rewiring: 1 YES, 0 NO
  for (double dPrew=1; dPrew<=1; dPrew+=1) {     				// Rewiring: 1 YES, 0 NO
  	//Game.dProbRewiring = dPrew;
  	Game.dProbRewiring = 1;
    Game.dProbRewireRandom = 0;
    if (MainWindow.iOutputMode == iOUTPUT_VERBOSE)
    	System.out.print ("\n Prew: " + Game.dProbRewiring + "  dProbRewireRandom: " + Game.dProbRewireRandom);

  //for (double dProbD=0.0; dProbD<=0.5; dProbD+=0.05) {     		// Defector probability
  for (double dProbD=0; dProbD<=0; dProbD+=0.1) {     				// Defector probability
  	GameCoaReputation.dProbDefector = dProbD;
  	if (MainWindow.iOutputMode == iOUTPUT_VERBOSE)
  	  System.out.print ("\n dProbDefector: " + GameCoaReputation.dProbDefector);

  //for (double dMut=0.0; dMut<=0.011; dMut+=0.001) {     			// Mutation probability
  for (double dMut=0; dMut<=0; dMut+=0.01) {     							// Mutation probability
  	Game.dProbMut = dMut;
  	if (MainWindow.iOutputMode == iOUTPUT_VERBOSE)
  	  System.out.print ("\n dProbMut: " + Game.dProbMut);
  	
  Game.dProbInf = 1;
  //for (int iChange=0; iChange<=7; iChange+=1) {     	// Change type
  for (int iChange=0; iChange<=0; iChange+=1) {     	// Change type
  	Game.iChangeType = iChange;
  	if (MainWindow.iOutputMode == iOUTPUT_VERBOSE)
  	  System.out.println ("\n iChangeType: " + Game.iChangeType);

	imNumTimesStrat = new int[iNumRuns][imTotNumTimesStrat.length];
	imTotNumTimesStrat = new int[imTotNumTimesStrat.length];
	iTotNumTimesStratC=0;
	iTotNumTimesStratD=0;
  for (int i=0; i<iNumRuns; i++) {     // Number of iterations

    oGame.vNewGame();

    iSimEstable = 0;
    while (true) {
      oGame.vRunLoop();

      if (Game.iNumChanges == 0)
        iSimEstable++;
      else
        iSimEstable = 0;
      
      if ((Game.iNumGen % MainWindow.iGenStopTMP == 0) || (iSimEstable >= 25) ) {
	    	if (MainWindow.iOutputMode == iOUTPUT_VERBOSE)
		      System.out.print ("  [Run:" + i + ", iGen:" + Game.iNumGen + "]");
		      
	    	int iWinStrat=0, iStratsD=0, iStratsC=0, iMaxVal = 0;
	    	for (int iStrat=0; iStrat<GameCoaReputation.imCellsAction.length; iStrat++) {
	    		imNumTimesStrat[i][iStrat] = GameCoaReputation.imCellsAction[iStrat];
	    	  imTotNumTimesStrat[iStrat] += GameCoaReputation.imCellsAction[iStrat];
	    	  if (GameCoaReputation.imCellsAction[iStrat] > iMaxVal) {
		    		iMaxVal = GameCoaReputation.imCellsAction[iStrat];
		    		iWinStrat = iStrat-5;
	    	  }
	    	  if (iStrat <= 5)
	    	  	iStratsC += GameCoaReputation.imCellsAction[iStrat];
	    	  else
	    	  	iStratsD += GameCoaReputation.imCellsAction[iStrat];
	    	}
	    	
	    	iTotNumTimesStratC += iStratsC;
	    	iTotNumTimesStratD += iStratsD;

	    	/*
				if (MainWindow.iOutputMode == iOUTPUT_VERBOSE) {
					System.out.print ("   Winner Strat: " + iWinStrat + " with "+ (100 * iMaxVal / Game.iTotNumCells)+"% of cells, where "
														+ (100 * iStratsC / Game.iTotNumCells) +"% are C and " + (100 * iStratsD / Game.iTotNumCells) +"% are D.");
					if (iStratsD > iStratsC) System.out.print (" <---");
					System.out.println();
				} */
  
        break;
      }

    }		// from while loop

  }   // for (int i=0; i<iNumRuns; i++)       // Iterations
  
  double dTotNumCells = (double) Game.iTotNumCells;
  double dTotNumCellxRuns = (double) (iNumRuns*Game.iTotNumCells);
  for (int iStrat=0; iStrat<GameCoaReputation.imCellsAction.length; iStrat++)
  	dmAvg[iStrat] = (double) imTotNumTimesStrat[iStrat] / dTotNumCellxRuns;
  
  for (int iStrat=0; iStrat<GameCoaReputation.imCellsAction.length; iStrat++) {
  	dmVar[iStrat] = 0;
  	for (int i=0; i<iNumRuns; i++) {
  		dAux = (double) (imNumTimesStrat[i][iStrat]) / dTotNumCells - dmAvg[iStrat];
  		dmVar[iStrat] += dAux * dAux;
  	}
  	dmVar[iStrat] = dmVar[iStrat] / iNumRuns;
    dmStdDev[iStrat] = Math.sqrt (dmVar[iStrat]);
  }
  
  if (MainWindow.iOutputMode == iOUTPUT_VERBOSE) {
		System.out.println ("\n  Results after " + iNumRuns + " executions !!");
		for (int j=0; j<imTotNumTimesStrat.length; j++)
		  System.out.println ("    Strat[" + (j-5) + "] = " + String.format (Locale.ENGLISH, "%.2f", dmAvg[j]) + "   StdDev=" + String.format (Locale.ENGLISH, "%.2f", dmStdDev[j]));
			System.out.println ("\n  Cooperation: "+ String.format (Locale.ENGLISH, "%.2f", ((double) iTotNumTimesStratC / dTotNumCellxRuns) ));
			System.out.println ("  Defection:   "+ String.format (Locale.ENGLISH, "%.2f", ((double) iTotNumTimesStratD / dTotNumCellxRuns) ));
	  }
  
  System.out.print ("\n  Results for Python: ");
  for (int j=0; j<imTotNumTimesStrat.length; j++)
	  if (j==0)
	  	System.out.print ("" + String.format (Locale.ENGLISH, "%.2f", dmAvg[j]) );
	  else
	  	System.out.print ("," + String.format (Locale.ENGLISH, "%.2f", dmAvg[j]) );
  
  System.out.print("\n\n");
   

  }		//	for (int iChange=0; iChange<=3; iChange+=1) {     		// Change type
  }		//	for (double dMut=0; dMut<=0.1; dMut+=0.01) {     			// Mutation probability
  System.out.println();
  }		//	for (double dProbD=0; dProbD<=1; dProbD+=0.1) {     	// Defector probability
  System.out.println();
  }		//	for (double dPrew=0.0; dPrew<=1.0; dPrew+=0.1) {     	// Rewiring: 1 YES, 0 NO
  System.out.println();
  }		// 	for (int iCoa=0; iCoa<=1; iCoa++) {     							// Coalitions 0 false, 1 true
  System.out.println();
  }		//	for (int iNet=0; iNet<=3; iNet++) {										// Networks: 0->SP	1->SW	2->SF	3->RN
  
  dTimeB = System.currentTimeMillis();
  iTimeMin = 0;
  iTimeSec = (int) ((dTimeB - dTimeA) / 1000);
  if (iTimeSec > 60) {
  	iTimeMin = iTimeSec / 60;
  	iTimeSec = iTimeSec - iTimeMin * 60;
  }
  System.out.println ("\n#>>> END OF THE BATCH EXECUTION (" + iTimeMin + " mins, " + iTimeSec +" secs.) !!!");

  try {
      Clip oSound = AudioSystem.getClip();
      oSound.open (AudioSystem.getAudioInputStream(new File("./sound/cuckoo.wav")));
      oSound.start();
      while (oSound.isRunning())
          Thread.sleep(1000);
      oSound.close();
  } catch (Exception e) {
      System.out.println ("" + e);
  }

  

}   // private void vBatchRun (String[] args) {


//-------------------------------- END: BATCH Reputation ---------------------------------------


}	// public class bCellNet implements GameCons