package window;

import games.Game;
import games.coaPrediction.GameCoaPrediction;

import java.awt.*;
import java.text.DecimalFormat;
import java.util.Vector;


public class VisorSerieDouble extends Visor implements WindowCons 
{
int iTipoGrafica;

public VisorSerieDouble (MainWindow oVentAux, int iTipoGraficaAux) {
  super(oVentAux);
  iTipoGrafica = iTipoGraficaAux;
  }

public void paint (Graphics g) {
  DecimalFormat oDF5 = new DecimalFormat("0.00000");
  Vector oVect=null;
    
  g.setColor (Color.black);
  g.drawLine (50, 50, 50, 300);
  g.drawLine (50, 300, 350, 300);
  g.drawString ("1", 30, 50);
  g.drawLine (45, 50, 55, 50);
  g.drawString (".75", 25, 113);
  g.drawLine (45, 113, 55, 113);
  g.drawString (".5", 25, 175);
  g.drawLine (45, 175, 55, 175);
  g.drawString (".25", 25, 238);
  g.drawLine (45, 238, 55, 238);
  g.drawLine (125, 295, 125, 305);
  g.drawLine (200, 295, 200, 305);
  g.drawLine (275, 295, 275, 305);
  g.drawLine (350, 295, 350, 305);
  
  switch (iTipoGrafica) {
  	case iNET_CC_STATS:   g.drawString ("Clustering Coefficient", 145, 20);
  			oVect = Game.oVNetCCStats;
  			break;

    case iGLOBAL_PROFIT:   g.drawString ("Global Profit", 145, 20);
            oVect = Game.oVGlobalProfit;
            break;
            
    case iERR_VALUES:  g.drawString ("Error Value", 145, 20);
            oVect = GameCoaPrediction.oVGraphErrorBuffer;
            break;
  }
  
  if (oVect == null) return;

  if (oVect.size() > 0) {
    Double oDouble;
    double dAux, dMax, dMin, dAvg=0;
    int iX1, iY1, iX2, iY2;
    
    int iGenIni = Game.iNumGen - MainWindow.iLastNGen;
    if (iGenIni < 0)
      iGenIni = 0;
    int iGenSize = Game.iNumGen - iGenIni - 1;
    if ( (iGenSize == 0) || (oVect.size() < iGenSize) ) return;

    dMax = 0; dAvg = 0; dMin = Double.MAX_VALUE;         				// I use the maximum value obtained for normalizing
    for (int i=0; i<iGenSize; i++) {
      oDouble = (Double) oVect.elementAt(i);
      dAux = oDouble.doubleValue();
      dAvg += dAux;
      if (dAux > dMax)
        dMax = dAux;
      if (dAux < dMin)
        dMin = dAux;
      }
    dAvg = dAvg / iGenSize;

    if (dMax == 0) return;
    
    g.setColor (Color.blue);

    iX1 = 50; iY1 = 175; iX2 = 50; iY2 = 175;
    for (int i=0; i<iGenSize; i++) {
      iX2 = 50 + (300 * (i+1)) / iGenSize;
      oDouble = (Double) oVect.elementAt(i);
      iY2 = (int) (300.0 - 250.0 * oDouble.doubleValue() / dMax);
      g.drawLine (iX1, iY1, iX2, iY2);
      iX1 = iX2;
      iY1 = iY2;
      }
    
    g.setColor (Color.black);
    g.drawString ("IniG = "+iGenIni, 30, 315);
    g.drawString ("EndG = "+Game.iNumGen, 310, 315);
    g.drawString ("Max. Value = " + oDF5.format(dMax), 40, 40);
    g.drawString ("Max. Value = " + oDF5.format(dMax), 145, 315);
    g.drawString ("Avg. Value = " + oDF5.format(dAvg), 145, 325);
    g.drawString ("Min. Value = " + oDF5.format(dMin), 145, 335);

    }

  }

}		// from the class






