package window;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
  * This class make appear dialog windows with graphics and an OK button
  *
  * @author  Juan C. Burguillo Rial
  * @version 1.0
  */
public class DlGraphics extends JDialog implements ActionListener, WindowCons
{
Visor oVisor;


/**
 * This is the constructor
 *
 * @param	oPadre 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 * @param iGraphicType	This is the type of the graphic window that will appear
 */
public DlGraphics (JFrame oPadre, String sTit, boolean bBool, int iGraphicType) {
  super (oPadre, sTit, bBool);

  GridBagLayout oGBL = new GridBagLayout();
  GridBagConstraints oGBCons = new GridBagConstraints();

  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(oGBL);

  oGBCons.fill = GridBagConstraints.BOTH;					// Crece a lo ancho y alto
  oGBCons.weightx = 1.0;									// Entre [0.0, 1.0]
  oGBCons.weighty = 1.0;									// Entre [0.0, 1.0]
  oGBCons.gridheight = GridBagConstraints.RELATIVE;
  oGBCons.gridwidth = GridBagConstraints.REMAINDER;
    
  switch (iGraphicType) {

    case iNODE_DEGREE_DIST:
		  VisorNodeDegree oVisorNodeDegree = new VisorNodeDegree ((MainWindow) oPadre);
		  oGBL.setConstraints (oVisorNodeDegree, oGBCons);
		  add(oVisorNodeDegree);
		  oVisor = oVisorNodeDegree;
		  break;

    case iNET_STATS:
      VisorSerieVectDouble oVisorNetStats = new VisorSerieVectDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorNetStats, oGBCons);
      add(oVisorNetStats);
      oVisor = oVisorNetStats;
      break;
      
    case iNET_CC_STATS:
      VisorSerieDouble oVisorNetCCStats = new VisorSerieDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorNetCCStats, oGBCons);
      add(oVisorNetCCStats);
      oVisor = oVisorNetCCStats;
      break;
	  
    case iCHANGESxGEN:
      VisorSerieInteger oVisorChangesxGen = new VisorSerieInteger ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorChangesxGen, oGBCons);
      add (oVisorChangesxGen);
      oVisor = oVisorChangesxGen;
      break;
      
    case iPROFITxACTION:
      VisorSerieVectDouble oVisorProfitxAction = new VisorSerieVectDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorProfitxAction, oGBCons);
      add(oVisorProfitxAction);
      oVisor = oVisorProfitxAction;
      break;    
  
    case iGLOBAL_PROFIT:
      VisorSerieDouble oVisorGlobalProfit = new VisorSerieDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorGlobalProfit, oGBCons);
      add(oVisorGlobalProfit);
      oVisor = oVisorGlobalProfit;
      break;
      
    case iPROFITxTYPE:
      VisorSerieVectDouble oVisorProfitLeadervsNonLeader = new VisorSerieVectDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorProfitLeadervsNonLeader, oGBCons);
      add(oVisorProfitLeadervsNonLeader);
      oVisor = oVisorProfitLeadervsNonLeader;
      break;
      
    case iTAX_HISTOGRAM:
      VisorHistogramaInteger oVisorTaxes = new VisorHistogramaInteger ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorTaxes, oGBCons);
      add(oVisorTaxes);
      oVisor = oVisorTaxes;
      break;
      
    case iTAXxCOA_CELL:
      VisorSerieInteger oVisorAvgTax = new VisorSerieInteger ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorAvgTax, oGBCons);
      add(oVisorAvgTax);
      oVisor = oVisorAvgTax;
      break;
      
    case iSTRATS_HISTOGRAM:
      VisorHistogramaInteger oVisorStrats = new VisorHistogramaInteger ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorStrats, oGBCons);
      add(oVisorStrats);
      oVisor = oVisorStrats;
      break;
  
    case iSCORES_HISTOGRAM:
      VisorHistogramaInteger oVisorScore = new VisorHistogramaInteger ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorScore, oGBCons);
      add(oVisorScore);
      oVisor = oVisorScore;
      break;
      
    case iDYNAMIC_BV:
      VisorSerieVectDouble oVisorDynamicBV = new VisorSerieVectDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorDynamicBV, oGBCons);
      add(oVisorDynamicBV);
      oVisor = oVisorDynamicBV;
      break;
      
    case iSTATIC_BV:
      VisorStaticBV oVisorStaticBV = new VisorStaticBV ((MainWindow) oPadre);
      oGBL.setConstraints (oVisorStaticBV, oGBCons);
      add(oVisorStaticBV);
      oVisor = oVisorStaticBV;
      break;
      
    case iNEIGHBORSxACTION:
      VisorNeighborsxAction oVisorVecxAcc = new VisorNeighborsxAction ((MainWindow) oPadre);
      oGBL.setConstraints (oVisorVecxAcc, oGBCons);
      add(oVisorVecxAcc);
      oVisor = oVisorVecxAcc;
      break;

    case iACTIONSxNEIGHBORHOOD_SIZE:
      VisorNeighborsxSize oVisorVecxTam = new VisorNeighborsxSize ((MainWindow) oPadre);
      oGBL.setConstraints (oVisorVecxTam, oGBCons);
      add(oVisorVecxTam);
      oVisor = oVisorVecxTam;
      break;
      
    case iAVG_LINKSxACTION:
      VisorLinksxAction oVisorLinksxAcc = new VisorLinksxAction ((MainWindow) oPadre);
      oGBL.setConstraints (oVisorLinksxAcc, oGBCons);
      add(oVisorLinksxAcc);
      oVisor = oVisorLinksxAcc;
      break;

    case iAVG_PROB_LA_ACTION:
      VisorProbLAxAction oVisorPLAxAcc = new VisorProbLAxAction ((MainWindow) oPadre);
      oGBL.setConstraints (oVisorPLAxAcc, oGBCons);
      add(oVisorPLAxAcc);
      oVisor = oVisorPLAxAcc;
      break;

    case iFUN_VALUES:
      VisorSerieVectDouble oVisorFunValues = new VisorSerieVectDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorFunValues, oGBCons);
      add(oVisorFunValues);
      oVisor = oVisorFunValues;
      break;

    case iERR_VALUES:
      VisorSerieDouble oVisorErrorValues = new VisorSerieDouble ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorErrorValues, oGBCons);
      add(oVisorErrorValues);
      oVisor = oVisorErrorValues;
      break;
      
    default:
      VisorSerieVectInteger oVisorSerieVectInteger = new VisorSerieVectInteger ((MainWindow) oPadre, iGraphicType);
      oGBL.setConstraints (oVisorSerieVectInteger, oGBCons);
      add(oVisorSerieVectInteger);
      oVisor = oVisorSerieVectInteger;
  }


  Panel oPanel = new Panel();
  oPanel.setForeground (Color.black);
  oPanel.setLayout (new GridLayout(1,3));
  oPanel.add (new Label("",Label.CENTER));
  JButton oOK = new JButton ("OK");
  oOK.addActionListener (this);
  oPanel.add (oOK);
  oPanel.add (new Label("",Label.CENTER));
  add (oPanel);

//  oGBCons.fill = GridBagConstraints.HORIZONTAL;					// Crece a lo ancho
//  oGBCons.weightx = 1.0;																// Entre [0.0, 1.0]
//  oGBCons.weighty = 0.1;																// Entre [0.0, 1.0]
//  oGBCons.gridheight = GridBagConstraints.REMAINDER;
//  oGBCons.gridwidth = GridBagConstraints.REMAINDER;
//  oGBCons.insets = new Insets (5,5,5,5);
//  oGBL.setConstraints (oPanel, oGBCons);
//  add (oPanel);

  if (iGraphicType == iNODE_DEGREE_DIST)
  	setSize(new Dimension(800,400));
  else
  	setSize(new Dimension(400,400));
  setResizable(false);
  setLocation (new Point (MainWindow.iMapSize+220 + 10 * (iGraphicType-1), 25 * (iGraphicType-1) ) );
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
  public void actionPerformed (ActionEvent evt) {
  if ("OK".equals (evt.getActionCommand()))
    setVisible(false);
  }

}	// from the class
