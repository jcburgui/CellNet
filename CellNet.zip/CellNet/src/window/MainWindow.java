package window;

import java.awt.*;
import java.awt.event.*;

import games.*;
import games.coaIPD.*;
import games.coaLife.*;
import games.coaMetaNorms.*;
import games.coaOptimization.*;
import games.coaPrediction.*;
import games.coaReputation.*;
import games.iHawkDovePossessorTrader.*;
import games.satBall.*;
import games.socialGroups.*;
import file.IOFile;

import java.util.Locale;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;




/**
  * This is the main frame of the tool.
  *
  * @author  Juan C. Burguillo Rial
  * @version 3.0
  */
public class MainWindow extends JFrame implements
	WindowCons, GameCons, ActionListener, MouseMotionListener, WindowListener, Runnable
{
public static int iBatchMode = 0;	  			// Indicates BATCH mode: 0-No batch, 1-Batch with windows, 2-Text batch (bCellNet)
public static int iOutputMode = iOUTPUT_VERBOSE;

public Game oGame;				                		// Contains the games to play
private boolean bApplet;			            		// Tells if is an applet or an application
private	Thread oProcess = null;			      		// This object will contain the execution Thread
private boolean bRunThread = false;		      	// Tells if the thread is running or not
private boolean bInsideThread = false;		  	// Tells if the execution is still inside the Thread
public boolean bEndThread = true;  		      	// Finishes execution

public int iDelayMilisecs = 1;           			// Waiting time in milliseconds
public int iNGenRepaint = 1;			        		// Number of generations to repaint

public static int iMapSize = 600;         		// Map size in pixels for painting the cells
public static int iCellSize;               		// Cell size in pixels per cell
public static int iGenStop = 2500000;					// Generation to stop the simulation
public static int iGenStopTMP = iGenStop; 		// To be used with Step execution
public static int iLastNGen = 100;        		// To visualize only the last N generations in graphic windows
public static Menu oMenuGames;
public static MenuItem oMIPayMatrix;
public static MenuItem[] oMIWindow = new MenuItem[25];  	// Elements from MenuItem

public static DlGraphics[] omDlGraf = new DlGraphics[25]; 	// Graphics

public static DlgInfoCell oDlgInfoCell;					  	// Information about a particular cell in the World Cell





/**
  * This is the constructor of the MainWindow class.
  *
  * @param	bBool   Indicates if this is an applet (true) or not
  */
public MainWindow (boolean bBool) {
  super(" CellNet: ");

  bApplet = bBool;		// if it is an applet, then receives true
  addWindowListener (this);

  setBackground (Color.lightGray);
  setForeground (Color.black);

  MenuBar oMB = new MenuBar();

  Menu oMenu = new Menu("File");
  MenuItem oMI = new MenuItem ("Load Matrix", new MenuShortcut('L'));
  oMI.addActionListener (this);
  if (bApplet) oMI.setEnabled (false);
  oMenu.add(oMI);
  oMI = new MenuItem ("Save Matrix", new MenuShortcut('S'));
  oMI.addActionListener (this);
  if (bApplet) oMI.setEnabled (false);
  oMenu.add(oMI);
  oMI = new MenuItem ("Import Network");
  oMI.addActionListener (this);
  if (bApplet) oMI.setEnabled (false);
  oMenu.add(oMI);
  oMI = new MenuItem ("Export Network");
  oMI.addActionListener (this);
  if (bApplet) oMI.setEnabled (false);
  oMenu.add(oMI);
  oMI = new MenuItem ("Quit", new MenuShortcut('Q'));
  oMI.addActionListener (this);
  oMenu.add(oMI);
  oMB.add (oMenu);

  oMenuGames = new Menu ("Games");
  for (int i=0; i<Game.sGAME_TYPE.length; i++) {
    oMI = new MenuItem (sGAME_TYPE[i]);
    oMI.addActionListener (this);
    oMenuGames.add(oMI);
    }
  oMB.add (oMenuGames);  
  
  oMenu = new Menu("Options");
  oMI = new MenuItem ("General Configuration", new MenuShortcut('C'));
  oMI.addActionListener (this);
  oMenu.add(oMI);
  oMI = new MenuItem ("Network Param", new MenuShortcut('N'));
  oMI.addActionListener (this);
  oMenu.add(oMI);
  
  oMI = new MenuItem ("-");
  oMenu.add(oMI);
  
  oMIPayMatrix = new MenuItem ("Payoff Matrix", new MenuShortcut('M'));
  oMIPayMatrix.addActionListener (this);
  oMenu.add(oMIPayMatrix);
  
  oMI = new MenuItem ("-");
  oMenu.add(oMI);
  
  oMI = new MenuItem ("Game Param", new MenuShortcut('G'));
  oMI.addActionListener (this);
  oMenu.add(oMI);
  
  oMB.add (oMenu);
  
  oMenu = new Menu("Window");
  oMIWindow[iREDRAW] = new MenuItem ("ReDraw", new MenuShortcut('0'));
  oMIWindow[iREDRAW].addActionListener (this);
  oMenu.add(oMIWindow[iREDRAW]);
  oMIWindow[iNODE_DEGREE_DIST] = new MenuItem ("Node Degree Distribution", new MenuShortcut('1'));
  oMIWindow[iNODE_DEGREE_DIST].addActionListener (this);
  oMenu.add(oMIWindow[iNODE_DEGREE_DIST]);
  oMIWindow[iNET_STATS] = new MenuItem ("Net Basic Stats", new MenuShortcut('2'));
  oMIWindow[iNET_STATS].addActionListener (this);
  oMenu.add(oMIWindow[iNET_STATS]);
  oMIWindow[iNET_CC_STATS] = new MenuItem ("Net CC Stats", new MenuShortcut('3'));
  oMIWindow[iNET_CC_STATS].addActionListener (this);
  oMenu.add(oMIWindow[iNET_CC_STATS]);
  oMIWindow[iMOVEMENT] = new MenuItem ("Graph Movement", new MenuShortcut('4'));
  oMIWindow[iMOVEMENT].addActionListener (this);
  oMenu.add(oMIWindow[iMOVEMENT]);
  oMI = new MenuItem ("-");
  oMenu.add(oMI);
  oMIWindow[iFREQxACTION] = new MenuItem ("Graph Freq. x Action");
  oMIWindow[iFREQxACTION].addActionListener (this);
  oMenu.add(oMIWindow[iFREQxACTION]);
  oMIWindow[iCHANGESxGEN] = new MenuItem ("Graph Changes x Gen");
  oMIWindow[iCHANGESxGEN].addActionListener (this);
  oMenu.add(oMIWindow[iCHANGESxGEN]);
  oMIWindow[iCELLSxSTRAT] = new MenuItem ("Graph Cells x Strat");
  oMIWindow[iCELLSxSTRAT].addActionListener (this);
  oMenu.add(oMIWindow[iCELLSxSTRAT]);
  oMI = new MenuItem ("-");
  oMenu.add(oMI);
  oMIWindow[iGLOBAL_PROFIT] = new MenuItem ("Graph Global Profit");
  oMIWindow[iGLOBAL_PROFIT].addActionListener (this);
  oMenu.add(oMIWindow[iGLOBAL_PROFIT]);
  oMIWindow[iPROFITxTYPE] = new MenuItem ("Graph Profit x Type");
  oMIWindow[iPROFITxTYPE].addActionListener (this);
  oMIWindow[iPROFITxACTION] = new MenuItem ("Graph Profit x Action");
  oMIWindow[iPROFITxACTION].addActionListener (this);
  oMenu.add(oMIWindow[iPROFITxACTION]);
  oMenu.add(oMIWindow[iPROFITxTYPE]);
  oMIWindow[iTAX_HISTOGRAM] = new MenuItem ("Graph Tax Histogram");
  oMIWindow[iTAX_HISTOGRAM].addActionListener (this);
  oMenu.add(oMIWindow[iTAX_HISTOGRAM]);
  oMIWindow[iTAXxCOA_CELL] = new MenuItem ("Graph Tax per Cell");
  oMIWindow[iTAXxCOA_CELL].addActionListener (this);
  oMenu.add(oMIWindow[iTAXxCOA_CELL]);
  oMI = new MenuItem ("-");
  oMenu.add(oMI);
  oMIWindow[iSTRATS_HISTOGRAM] = new MenuItem ("Strats Histogram");
  oMIWindow[iSTRATS_HISTOGRAM].addActionListener (this);
  oMenu.add(oMIWindow[iSTRATS_HISTOGRAM]);
  oMIWindow[iSCORES_HISTOGRAM] = new MenuItem ("Scores Histogram");
  oMIWindow[iSCORES_HISTOGRAM].addActionListener (this);
  oMenu.add(oMIWindow[iSCORES_HISTOGRAM]);
  oMIWindow[iDYNAMIC_BV] = new MenuItem ("Graph B & V Dynamic");
  oMIWindow[iDYNAMIC_BV].addActionListener (this);
  oMenu.add(oMIWindow[iDYNAMIC_BV]);
  oMIWindow[iSTATIC_BV] = new MenuItem ("Graph B & V Static");
  oMIWindow[iSTATIC_BV].addActionListener (this);
  oMenu.add(oMIWindow[iSTATIC_BV]); 
  oMI = new MenuItem ("-");
  oMenu.add(oMI);
  oMIWindow[iFREQxTYPE] = new MenuItem ("Graph Freq. x Type");
  oMIWindow[iFREQxTYPE].addActionListener (this);
  oMenu.add(oMIWindow[iFREQxTYPE]);
  oMIWindow[iAVG_PROBS_YPQ] = new MenuItem ("Graph Average Probabilities (y, p, q)");
  oMIWindow[iAVG_PROBS_YPQ].addActionListener (this);
  oMenu.add(oMIWindow[iAVG_PROBS_YPQ]);
  oMIWindow[iNEIGHBORSxACTION] = new MenuItem ("Neighbours x Action");
  oMIWindow[iNEIGHBORSxACTION].addActionListener (this);
  oMenu.add(oMIWindow[iNEIGHBORSxACTION]);
  oMIWindow[iACTIONSxNEIGHBORHOOD_SIZE] = new MenuItem ("Actions x Neighborhood Size");
  oMIWindow[iACTIONSxNEIGHBORHOOD_SIZE].addActionListener (this);
  oMenu.add(oMIWindow[iACTIONSxNEIGHBORHOOD_SIZE]);
  oMIWindow[iAVG_LINKSxACTION] = new MenuItem ("Average Links x Action");
  oMIWindow[iAVG_LINKSxACTION].addActionListener (this);
  oMenu.add(oMIWindow[iAVG_LINKSxACTION]);
  oMIWindow[iAVG_PROB_LA_ACTION] = new MenuItem ("Average Prob. LA x Action");
  oMIWindow[iAVG_PROB_LA_ACTION].addActionListener (this);
  oMenu.add(oMIWindow[iAVG_PROB_LA_ACTION]);
  oMI = new MenuItem ("-");
  oMenu.add(oMI);
  oMIWindow[iFUN_VALUES] = new MenuItem ("Functional Values");
  oMIWindow[iFUN_VALUES].addActionListener (this);
  oMenu.add(oMIWindow[iFUN_VALUES]);
  oMIWindow[iERR_VALUES] = new MenuItem ("Error Values");
  oMIWindow[iERR_VALUES].addActionListener (this);
  oMenu.add(oMIWindow[iERR_VALUES]);


  oMB.add (oMenu);

  oMIPayMatrix.setEnabled (false);
  for (int i=4; i<oMIWindow.length; i++)
    oMIWindow[i].setEnabled(false);

  oMenu = new Menu("Help");
  oMI = new MenuItem ("CellNet Help");
  oMI.addActionListener (this);
  oMenu.add(oMI);
  oMI = new MenuItem ("About");
  oMI.addActionListener (this);
  oMenu.add(oMI);
  oMB.add (oMenu);
  oMB.setHelpMenu (oMenu);

  setMenuBar(oMB);

  oDlgInfoCell = new DlgInfoCell (this, "Cell Information", false);
  
  //Game.iGameType = iSOCIALGROUPS;
  //Game.iGameType = iCOA_LIFE;
  //Game.iGameType = iSAT_BALL;
  Game.iGameType = iPRISONERs_DILEMMA;
  //Game.iGameType = iHAWK_DOVE_POSS_TRADER;
  //Game.iGameType = iCOA_IPD;
  //Game.iGameType = iCOA_REPUTATION;
  //Game.iGameType = iCOA_META_NORMS;
  //Game.iGameType = iCOA_OPTIMIZATION;
  //Game.iGameType = iCOA_PREDICTION;

  setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]);					// Must be here, before initializing the games
  
  switch (Game.iGameType) {
		case Game.iSOCIALGROUPS:                oGame = new GameSocialGroups(); break;
		case Game.iCOA_LIFE:                    oGame = new GameCoaLife(); break;
		case Game.iSAT_BALL:                    oGame = new GameSatBall(this); break;
		case Game.iPRISONERs_DILEMMA:
		case Game.iHAWK_DOVE_POSS_TRADER:       oGame = new GameHDPT (this); break;
		case Game.iCOA_IPD:                     oGame = new GameCoaIPD (this); break;
		case Game.iCOA_REPUTATION:     					oGame = new GameCoaReputation (this); break;
		case Game.iCOA_META_NORMS:     					oGame = new GameCoaMetaNorms (this); break;
		case Game.iCOA_OPTIMIZATION:            oGame = new GameCoaOptimization (this); break;
		case Game.iCOA_PREDICTION:              oGame = new GameCoaPrediction (this); break;
	}

  setLayout(new GridLayout (1,1));
  JPanelMainWindow oJPanelVentana = new JPanelMainWindow (this);
  add (oJPanelVentana);
  
  JPanelMainWindow.oStatusJLabel.setText("NumGen: "+Game.iNumGen+"     N: "+Game.iTotPosMatrix);
  JPanelMainWindow.oJLabelInfo.setText ("Change: "+Game.iChangeType);
  JPanelMainWindow.oJLabelGame.setText ("Game: "+Game.iGameType);
  JPanelMainWindow.oJLabelNet.setText ("Net: "+sSHORT_COMPLEX_NET[Game.iNetType]);
  JPanelMainWindow.vActivateButtons();
  
  setSize(new Dimension (iMapSize+150,iMapSize+90)); 	// Window size
  setResizable(false);
  setLocation (new Point (0,0));			// Window position
  setVisible (true);						// We make the window visible
  
  vSetupThread();
}


//----------------------- INI: Methods related with WindowListener interface -------------
public void windowClosing(WindowEvent e)
  {vQuit();}
public void windowClosed(WindowEvent e) {}
public void windowOpened(WindowEvent e)	{}
public void windowActivated(WindowEvent e) {}
public void windowDeactivated(WindowEvent e) {}
public void windowDeiconified(WindowEvent e) {}
public void windowIconified(WindowEvent e) {}
//----------------------- END: Methods related with WindowListener interface -------------

//-------------------- INI: Methods related with MouseMotionListener interface -------------
public void mouseMoved (MouseEvent oME){}
public void mouseDragged (MouseEvent oME){}
//-------------------- END: Methods related with MouseMotionListener interface -------------





/**
  * This method receives and processes the events in the objects from this class
  *
  *	@param evt the generated event
  */
public void actionPerformed (ActionEvent evt) {
  String sCommand = evt.getActionCommand();

  if ("Load Matrix".equals (sCommand)) {
    IOFile.vLoadMatrix (this, Game.oCellMatrix);
    vMatrixReloaded();
    return;
  }
  
  else if ("Save Matrix".equals (sCommand)) {
    IOFile.vSaveMatrix (this, Game.oCellMatrix);
    return;
  }
  
  else if ("Import Network".equals (sCommand)) {
    IOFile.vImportNetwork (this, Game.oCellMatrix);
    JPanelMainWindow.oVisorWorld.repaint();
    return;
  }
  else if ("Export Network".equals (sCommand)) {
    IOFile.vExportNetwork (this, Game.oCellMatrix);
    return;
  }

  else if ("Quit".equals (sCommand))
    vQuit();

  else if ("General Configuration".equals (sCommand)) {
    vStopThread();
    new DlgConfiguration (this, "Configuration", true);
    JPanelMainWindow.oVisorWorld.repaint();
  }
  
  else if ("Network Param".equals (sCommand)) {
    vStopThread();
    new DlgParamNet (this, "Network Parameters", true);
    JPanelMainWindow.oVisorWorld.repaint();
  }

  else if ("Payoff Matrix".equals (sCommand)) {
    vStopThread();
    new DlgPayoffMatrix (this, "Payoff Matrix", true);
    JPanelMainWindow.oVisorWorld.repaint();
  }
 
  else if ("Game Param".equals (sCommand)) {
  	vStopThread();
    switch (Game.iGameType) {
  		case Game.iSOCIALGROUPS:                new DlgParamSocialGroups (this, "Social Groups Parameters", true); break;
  		case Game.iCOA_LIFE:                    new DlgParamCoaLife (this, "CoaLife Parameters", true); break;
  		case Game.iSAT_BALL:                    new DlgParamSatBall (this, "Sat Ball Parameters", true); break;
  		case Game.iPRISONERs_DILEMMA:						new DlgParamIPD (this, "IPD Parameters", true); break;
  		case Game.iHAWK_DOVE_POSS_TRADER:       new DlgParamHDPT (this, "Hawk-Dove-Possessor-Trader Parameters", true); break;
  		case Game.iCOA_IPD:                     new DlgParamCoaIPD (this, "Coalitions SIPD Parameters", true); break;
  		case Game.iCOA_REPUTATION:     					new DlgParamRep (this, "Reputation Parameters", true); break;
  		case Game.iCOA_META_NORMS:     					new DlgParamNorms (this, "MetaNorms Parameters", true); break;
  		case Game.iCOA_OPTIMIZATION:            new DlgParamOpt (this, "Optimization Parameters", true); break;
  		case Game.iCOA_PREDICTION:              new DlgParamPred (this, "Prediction Parameters", true); break;
  	}
    JPanelMainWindow.oVisorWorld.repaint();
  }
  
  
  else if ("ReDraw".equals (sCommand))
    JPanelMainWindow.oVisorWorld.repaint();

  else if ("Node Degree Distribution".equals (sCommand)) {
	  if (omDlGraf[iNODE_DEGREE_DIST] == null)
		  omDlGraf[iNODE_DEGREE_DIST] = new DlGraphics (this, " CellNet: Node Degree Distribution", false, iNODE_DEGREE_DIST);
      omDlGraf[iNODE_DEGREE_DIST].setVisible(true);
    }

  else if ("Net Basic Stats".equals (sCommand)) {
	  if (omDlGraf[iNET_STATS] == null)
		  omDlGraf[iNET_STATS] = new DlGraphics (this, " CellNet: Network Basic Statistics", false, iNET_STATS);
      omDlGraf[iNET_STATS].setVisible(true);
    }
  
  else if ("Net CC Stats".equals (sCommand)) {
	  if (omDlGraf[iNET_CC_STATS] == null)
		  omDlGraf[iNET_CC_STATS] = new DlGraphics (this, " CellNet: Network Cluster Coefficient", false, iNET_CC_STATS);
      omDlGraf[iNET_CC_STATS].setVisible(true);
    }
  
 
  
  else if ("Graph Movement".equals (sCommand)) {
	  if (omDlGraf[iMOVEMENT] == null)
		  omDlGraf[iMOVEMENT] = new DlGraphics (this, " CellNet: Movement of Cells", false, iMOVEMENT);
      omDlGraf[iMOVEMENT].setVisible(true);
    }

  else if ("Graph Freq. x Action".equals (sCommand)) {
	  if (omDlGraf[iFREQxACTION] == null)
		  omDlGraf[iFREQxACTION] = new DlGraphics (this, " CellNet: Freq. x Action", false, iFREQxACTION);
      omDlGraf[iFREQxACTION].setVisible(true);
    }

  else if ("Graph Changes x Gen".equals (sCommand)) {
	  if (omDlGraf[iCHANGESxGEN] == null)
		  omDlGraf[iCHANGESxGEN] = new DlGraphics (this, " CellNet: Action Changes", false, iCHANGESxGEN);
      omDlGraf[iCHANGESxGEN].setVisible(true);
    }

  else if ("Graph Cells x Strat".equals (sCommand)) {
	  if (omDlGraf[iCELLSxSTRAT] == null)
		  omDlGraf[iCELLSxSTRAT] = new DlGraphics (this, " CellNet: Cells x Strat", false, iCELLSxSTRAT);
      omDlGraf[iCELLSxSTRAT].setVisible(true);
    }

  else if ("Graph Global Profit".equals (sCommand)) {
	  if (omDlGraf[iGLOBAL_PROFIT] == null)
		  omDlGraf[iGLOBAL_PROFIT] = new DlGraphics (this, " CellNet: Global Profit", false, iGLOBAL_PROFIT);
      omDlGraf[iGLOBAL_PROFIT].setVisible(true);
    }

  else if ("Graph Profit x Type".equals (sCommand)) {
	  if (omDlGraf[iPROFITxTYPE] == null)
		  omDlGraf[iPROFITxTYPE] = new DlGraphics (this, " CellNet: Profit x Type", false, iPROFITxTYPE);
      omDlGraf[iPROFITxTYPE].setVisible(true);
    }

  else if ("Graph Profit x Action".equals (sCommand)) {
	  if (omDlGraf[iPROFITxACTION] == null)
		  omDlGraf[iPROFITxACTION] = new DlGraphics (this, " CellNet: Profit x Action", false, iPROFITxACTION);
      omDlGraf[iPROFITxACTION].setVisible(true);
    }
  
  else if ("Graph Tax Histogram".equals (sCommand)) {
	  if (omDlGraf[iTAX_HISTOGRAM] == null)
		  omDlGraf[iTAX_HISTOGRAM] = new DlGraphics (this, " CellNet: Tax Histogram", false, iTAX_HISTOGRAM);
      omDlGraf[iTAX_HISTOGRAM].setVisible(true);
    }

  else if ("Graph Tax per Cell".equals (sCommand)) {
	  if (omDlGraf[iTAXxCOA_CELL] == null)
		  omDlGraf[iTAXxCOA_CELL] = new DlGraphics (this, " CellNet: Average Tax x Coalition Cell", false, iTAXxCOA_CELL);
      omDlGraf[iTAXxCOA_CELL].setVisible(true);
    }

  else if ("Strats Histogram".equals (sCommand)) {
	  if (omDlGraf[iSTRATS_HISTOGRAM] == null)
		  omDlGraf[iSTRATS_HISTOGRAM] = new DlGraphics (this, " CellNet: Strats Histogram", false, iSTRATS_HISTOGRAM);
      omDlGraf[iSTRATS_HISTOGRAM].setVisible(true);
    }

  else if ("Scores Histogram".equals (sCommand)) {
	  if (omDlGraf[iSCORES_HISTOGRAM] == null)
		  omDlGraf[iSCORES_HISTOGRAM] = new DlGraphics (this, " CellNet: Score Histogram", false, iSCORES_HISTOGRAM);
      omDlGraf[iSCORES_HISTOGRAM].setVisible(true);
    }

  else if ("Graph B & V Dynamic".equals (sCommand)) {
	  if (omDlGraf[iDYNAMIC_BV] == null)
		  omDlGraf[iDYNAMIC_BV] = new DlGraphics (this, " CellNet: B & V Evolution", false, iDYNAMIC_BV);
	  omDlGraf[iDYNAMIC_BV].setVisible(true);
  	}
  
  else if ("Graph B & V Static".equals (sCommand)) {
	  if (omDlGraf[iSTATIC_BV] == null)
		  omDlGraf[iSTATIC_BV] = new DlGraphics (this, " CellNet: B & V Map", false, iSTATIC_BV);
	  omDlGraf[iSTATIC_BV].setVisible(true);
  	}
    
  else if ("Graph Freq. x Type".equals (sCommand)) {
	  if (omDlGraf[iFREQxTYPE] == null)
		  omDlGraf[iFREQxTYPE] = new DlGraphics (this, " CellNet: Frequency of Cell Types", false, iFREQxTYPE);
      omDlGraf[iFREQxTYPE].setVisible(true);
    }

  else if ("Graph Average Probabilities (y, p, q)".equals (sCommand)) {
	  if (omDlGraf[iAVG_PROBS_YPQ] == null)
		  omDlGraf[iAVG_PROBS_YPQ] = new DlGraphics (this, " CellNet: Average Probabilities (y, p, q)", false, iAVG_PROBS_YPQ);
      omDlGraf[iAVG_PROBS_YPQ].setVisible(true);
    }
  
  else if ("Neighbours x Action".equals (sCommand)) {
	  if (omDlGraf[iNEIGHBORSxACTION] == null)
		  omDlGraf[iNEIGHBORSxACTION] = new DlGraphics (this, " CellNet: Neighbours x Action", false, iNEIGHBORSxACTION);
      omDlGraf[iNEIGHBORSxACTION].setVisible(true);
    }

  else if ("Actions x Neighborhood Size".equals (sCommand)) {
	  if (omDlGraf[iACTIONSxNEIGHBORHOOD_SIZE] == null)
		  omDlGraf[iACTIONSxNEIGHBORHOOD_SIZE] = new DlGraphics (this, " CellNet: Actions x Neighborhood Size", false, iACTIONSxNEIGHBORHOOD_SIZE);
      omDlGraf[iACTIONSxNEIGHBORHOOD_SIZE].setVisible(true);
    }

  else if ("Average Links x Action".equals (sCommand)) {
	  if (omDlGraf[iAVG_LINKSxACTION] == null)
		  omDlGraf[iAVG_LINKSxACTION] = new DlGraphics (this, " CellNet: Average Links x Action", false, iAVG_LINKSxACTION);
      omDlGraf[iAVG_LINKSxACTION].setVisible(true);
    }

  else if ("Average Prob. LA x Action".equals (sCommand)) {
	  if (omDlGraf[iAVG_PROB_LA_ACTION] == null)
		  omDlGraf[iAVG_PROB_LA_ACTION] = new DlGraphics (this, " CellNet: Average Prob. LA x Action", false, iAVG_PROB_LA_ACTION);
      omDlGraf[iAVG_PROB_LA_ACTION].setVisible(true);
    }

  else if ("Functional Values".equals (sCommand)) {
	  if (omDlGraf[iFUN_VALUES] == null)
		  omDlGraf[iFUN_VALUES] = new DlGraphics (this, " CellNet: Functional Values", false, iFUN_VALUES);
      omDlGraf[iFUN_VALUES].setVisible(true);
    }

  else if ("Error Values".equals (sCommand)) {
	  if (omDlGraf[iERR_VALUES] == null)
		  omDlGraf[iERR_VALUES] = new DlGraphics (this, " CellNet: Error Values", false, iERR_VALUES);
      omDlGraf[iERR_VALUES].setVisible(true);
    }
  
  else if ("CellNet Help".equals (sCommand))
  	new DialogHelp (this, "CellNet Help", true);

  else if ("About".equals (sCommand)) {
    vStopThread();
    String sAux[] ={"Cellular Network (version 2018)", "© Juan C. Burguillo", "e-mail: J.C.Burguillo@uvigo.es", "January 2018"};
    new DialogOK (this, "About", true, sAux);
    }
  
  else {
    for (int j=0; j<Game.sGAME_TYPE.length; j++)
      if (sGAME_TYPE[j].equals (sCommand)) {
        Game.iGameType = j;
                
        oMIPayMatrix.setEnabled (false);
        for (int i=4; i<oMIWindow.length; i++)
          oMIWindow[i].setEnabled (false);          // Disabling menus to be enabled by every games
        for (int i=4; i<omDlGraf.length; i++)
          if (MainWindow.omDlGraf[i] != null) {
            MainWindow.omDlGraf[i].dispose();                  // Disposing graphic windows to be enabled by every games
            MainWindow.omDlGraf[i] = null;
          }
        
        try {Thread.sleep(500);}						// Introducing a certain delay to avoid window problems
        catch (InterruptedException oIE) {}

        switch (Game.iGameType) {
          case Game.iSOCIALGROUPS:                oGame = new GameSocialGroups(); break;
          case Game.iCOA_LIFE:                    oGame = new GameCoaLife (); break;
          case Game.iSAT_BALL:                    oGame = new GameSatBall(this); break;
          case Game.iPRISONERs_DILEMMA:
          case Game.iHAWK_DOVE_POSS_TRADER:       oGame = new GameHDPT (this); break;
          case Game.iCOA_IPD:                     oGame = new GameCoaIPD (this); break;
          case Game.iCOA_REPUTATION:     	  	  	oGame = new GameCoaReputation (this); break;
      	  case Game.iCOA_META_NORMS:     		  		oGame = new GameCoaMetaNorms (this); break;
          case Game.iCOA_OPTIMIZATION:            oGame = new GameCoaOptimization (this); break;
          case Game.iCOA_PREDICTION:              oGame = new GameCoaPrediction (this); break;
        }

        vSetupThread();
        
        setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]);
        oDlgInfoCell.setVisible (false);
        JPanelMainWindow.vActivateButtons();
        JPanelMainWindow.oJLabelInfo.setText ("Change: "+Game.iChangeType);
        JPanelMainWindow.oJLabelGame.setText ("Game: "+Game.iGameType);
        if ( (Game.iGameType == iCOA_OPTIMIZATION) || (Game.iGameType == iCOA_PREDICTION) )
          JPanelMainWindow.oJLabelInfo.setText ("Problem: "+GameCoaOptimization.iProblemTypeI);
        else
          JPanelMainWindow.oJLabelInfo.setText ("Change: "+Game.iChangeType);
        
        break;
      }

    }
    
  }




/**
  * This method creates a new thread when the matrix of cells is reloaded
  */
public void vMatrixReloaded() {                    	// Restarts the thread
  vEndThread ();
  while (bInsideThread) {           				// Waiting for the end of the actual cycle
    try {Thread.sleep(10);}							// Introducing a certain delay
    catch (InterruptedException oIE) {}
    }
  bRunThread = false;
   
  JPanelMainWindow.oVisorWorld.repaint();	            // Repainting the world
  oDlgInfoCell.setVisible (false); 
  JPanelMainWindow.oStatusJLabel.setText("NumGen: "+Game.iNumGen+"     N: "+Game.iTotPosMatrix);
  JPanelMainWindow.oGoStopBut.setText("GO");
  for (int i=1; i<omDlGraf.length; i++)                 // Repainting graphic windows
    if (omDlGraf[i] != null) omDlGraf[i].oVisor.repaint();
  }



/**
  * This method creates a new thread
  */
public void vSetupThread() {                    	// Starts the thread
  vEndThread ();
  while (bInsideThread) {           				// Waiting for the end of the actual cycle
    try {Thread.sleep(10);}							// Introducing a certain delay
    catch (InterruptedException oIE) {}
    }
  bRunThread = false;
  
  oGame.vNewGame();
  oMenuGames.setEnabled (true);
  
  JPanelMainWindow.oVisorWorld.repaint();	                // Repainting the world
  JPanelMainWindow.oStatusJLabel.setText("NumGen: "+Game.iNumGen+"     N: "+Game.iTotPosMatrix);
  JPanelMainWindow.oGoStopBut.setText("GO");
  for (int i=1; i<omDlGraf.length; i++)                 // Repainting graphic windows
    if (omDlGraf[i] != null) omDlGraf[i].oVisor.repaint();
  }



/**
 * This method starts/continues the thread
 */
public void vGoThread () {
  iGenStopTMP = iGenStop;
  oMenuGames.setEnabled (false);
  if (oProcess == null)
    vStartThread();
  else if (bEndThread == false)
    bRunThread = true;
  
  JPanelMainWindow.oGoStopBut.setText("STOP");
}



/**
  * This methods starts the thread
  */
public void vStartThread() {
  if (!bRunThread) {
    bEndThread = false;
    bRunThread = true;
    oProcess = new Thread (this);
    oProcess.start();
  }
}


/**
 * This methods makes the thread go step by step
 */
public void vStepThread () {
  oMenuGames.setEnabled (false);
  JPanelMainWindow.oGoStopBut.setText("GO");
  if (oProcess == null) {
    iGenStopTMP = 1;
    vStartThread();
  }
  else if (bEndThread == false) {
    iGenStopTMP = Game.iNumGen + 1;
    bRunThread = true;
  }
}


/**
  * This method stops the thread
  */
public void vStopThread () {
  JPanelMainWindow.oGoStopBut.setText("GO");
  bRunThread = false;
}


/**
 * This method finishes the thread
 */
public void vEndThread () {
  bEndThread = true;
  bRunThread = true;
  if (iBatchMode == 0)
    oProcess = null;
}



/**
 * This method exits the program
 */
private void vQuit () {
  if (bApplet) {							// If it is an applet, we hide the window and stop the thread
    setVisible(false);
    vEndThread();
    }
  else {									// If it is an application, we free the resources and exit
    vEndThread();
    for (int i=0; i<oMIWindow.length; i++)
      if (omDlGraf[i] != null) {
    	  omDlGraf[i].dispose();
    	  omDlGraf[i] = null;
      }
    while (bInsideThread) {           		// Waiting for the end of the actual execution cycle
      try {Thread.sleep(10);}				// Introducing a certain delay
      catch (InterruptedException oIE) {}
    }
    dispose();
    try {Thread.sleep(500);}				// Introducing a certain delay to avoid window problems
    catch (InterruptedException oIE) {}
    System.exit(0);
    }
}



/**
  * This method contains the code to be executed as a thread
  */
public void run() {
  bInsideThread = true;
  if (iBatchMode > 0)
    vBatchRun ();
  else
    vNormalRun ();
  bInsideThread = false;
  }		// de run





/**
  * This method contains the code executed in normal mode
  */
private void vNormalRun () {

  while (true) {
    if (!bRunThread) {
      try {Thread.sleep(100);}                  	// We introduce a certain delay if stopped
      catch (InterruptedException oIE) {}
      continue;
    }

    if (bEndThread) break;

    oGame.vRunLoop();

    if (Game.iNumGen % iNGenRepaint == 0) {	     // We update the windows every iNGenRepaint
      if (oDlgInfoCell.isVisible()) oDlgInfoCell.repaint();
      JPanelMainWindow.oVisorWorld.repaint();	                			// Repainting the present world
      JPanelMainWindow.oStatusJLabel.setText (Game.sTextStateBar);	// Repainting the state line
      for (int i=1; i<omDlGraf.length; i++)                 				// Repainting graphic windows
        if (omDlGraf[i] != null) omDlGraf[i].oVisor.repaint();
      
      try {Thread.sleep(iDelayMilisecs);}				// Introducing a certain delay in the display
      catch (InterruptedException oIE) {}
    }

				// If there is a STOP or the simulation did not change it stops.
    if (Game.iNumGen % iGenStopTMP == 0) {
      vStopThread();
      String sCad = JPanelMainWindow.oStatusJLabel.getText() +  "   STOP !";
      JPanelMainWindow.oStatusJLabel.setText(sCad);
    }

  }		// from the while
  bRunThread = false;
}







/**
* This method contains the code to be executed in batch mode using graphics
*/
private void vBatchRun() {

  int iCounter=0, iNumRuns=5;								// Number of executions to determine the average values
	
  double dVarError=0, dAvgTotError=0, dTotError = 0;
  double[] dmError;

  MainWindow.iOutputMode = iOUTPUT_VERBOSE;
  
//-------------------------------- BATCH Prediction ---------------------------------------
  iNGenRepaint = 50;
  iGenStopTMP = iGenStop+1;
  Game.iGameType = iCOA_PREDICTION;
  Game.iNetType = 0;
  
  
  GameCoaPrediction.iNumInputVar = 2;
  GameCoaPrediction.iTrainEpochs = 20;

  oGame = new GameCoaPrediction (this);

  JPanelMainWindow.oVisorWorld.repaint();			// Painting the world
  setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]);

  JPanelMainWindow.oStatusJLabel.setText("NumGen: "+Game.iNumGen+"     N: "+Game.iTotPosMatrix);
  JPanelMainWindow.oJLabelGame.setText ("Game: "+Game.iGameType);
  JPanelMainWindow.oJLabelInfo.setText ("Change: "+Game.iChangeType);
  JPanelMainWindow.oJLabelNet.setText ("Net: "+sSHORT_COMPLEX_NET[Game.iNetType]);
  JPanelMainWindow.oJLabelInfo.setText ("Change: "+Game.iChangeType);
  

  System.out.println ("\n# Algoritm: " + Game.sALGOR_PRED[Game.iAlgorithm] +
			"   iNumInputVar: "+ GameCoaPrediction.iNumInputVar +
			"   iTrainEpochs: "+ GameCoaPrediction.iTrainEpochs +
			"   Problem: " + Game.sPROBLEM_PRED[GameCoaPrediction.iFunctionType] +
			"   Pu: " + String.format(Locale.ENGLISH, "%.2f", GameCoaPrediction.dProbUpdateCell) +
			"   Pinf: " + String.format(Locale.ENGLISH, "%.2f", Game.dProbInf) +
			"   Prew: " + String.format(Locale.ENGLISH, "%.2f", Game.dProbRewiring) );
  
  iNumRuns=25;
  System.out.print ("\n#>>> bCellNet: STARTING THE BATCH ("+ iNumRuns +" RUNS) !!!\n\n");
  
  // ************************************* BEGIN: Cycles **********************************************
  
  for (int j=1; j<=2; j++) {     // Algorithms 0->SOM and 1->CASOMinf and 2->CASOMjoin
    Game.iAlgorithm = j;
	if (MainWindow.iOutputMode == iOUTPUT_VERBOSE) System.out.print ("\n Algoritm: " + Game.sALGOR_PRED[Game.iAlgorithm]);
    
  for (int k=0; k<=3; k++) {     // Networks: 0->SP	1->SW	2->SF	3->RN
	Game.iNetType = k;
	if (MainWindow.iOutputMode == iOUTPUT_VERBOSE) System.out.print ("\n Net Type: " + sCOMPLEX_NET[k]);

  //for (double dPinf=0.0; dPinf<0.25; dPinf+=0.01) {         // Probability of infection
  for (double dPinf=0.05; dPinf<=0.05; dPinf+=0.01) {         // Probability of infection
	Game.dProbInf = dPinf;
	//if (MainWindow.iOutputMode == iOUTPUT_VERBOSE) System.out.print ("\n Prob. of Infection: " + Game.dProbInf);
        
  //for (double dPu=0.25; dPu<=1.0; dPu+=0.25) {			// Neurons to update 0.25->1, 0.5->2, 0.75->3 or 1.0->4
  for (double dPu=0.25; dPu<=0.25; dPu+=0.25) {			// Neurons to update 0.25->1, 0.5->2, 0.75->3 or 1.0->4
	GameCoaPrediction.dProbUpdateCell = dPu;
	// if (MainWindow.iOutputMode == iOUTPUT_VERBOSE) System.out.print ("\n Pu: " + GamePrediction.dProbUpdateCell);

  for (double dPrew=0.0; dPrew<=1.0; dPrew+=0.1) {     		// Probability of rewiring
  // for (double dPrew=0; dPrew<=0; dPrew+=0.1) {     		// Probability of rewiring
    Game.dProbRewiring = dPrew;
	// if (MainWindow.iOutputMode == iOUTPUT_VERBOSE) System.out.print ("\n Prew: " + GamePrediction.dProbRewiring);
 
  JPanelMainWindow.vActivateButtons();
  JPanelMainWindow.oJLabelGame.setText ("Game: "+Game.iGameType);
  JPanelMainWindow.oJLabelInfo.setText ("Change: "+Game.iChangeType);
  JPanelMainWindow.oJLabelNet.setText ("Net: "+Game.iNetType);
  JPanelMainWindow.oJLabelInfo.setText ("Function: "+GameCoaPrediction.iFunctionType);
  if (Game.iAlgorithm == Game.iSOM)
    setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (SOM)");
  else
    setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (CASOM)");
  
  dTotError = 0;
  dmError = new double[iNumRuns];
  for (int i=0; i<iNumRuns; i++) {     // Number of steps
	  
    bEndThread = false;
    oGame.vNewGame();

    for (int n=0; n<iGenStop; n++) {

      if (bEndThread) return;

      oGame.vRunLoop();

      if (Game.iNumGen % iNGenRepaint == 0) { // We update the world every iNGenRepaint
        JPanelMainWindow.oVisorWorld.repaint();  // Repainting the world
        for (int iInd=1; iInd<omDlGraf.length; iInd++)
          if (omDlGraf[iInd] != null) omDlGraf[iInd].oVisor.repaint();

        JPanelMainWindow.oStatusJLabel.setText (Game.sTextStateBar);
      }
      
    }		// from the loop of every iteration
    
    dmError [i] = GameCoaPrediction.dAvgPredError;
    dTotError += GameCoaPrediction.dAvgPredError; 
  }   // for (int i=0; i<iNumRuns; i++)

  dAvgTotError = dTotError/iNumRuns;
  dVarError = 0;
  for (int m=0; m<=iNumRuns; m++)
    dVarError += (dmError[m] - dAvgTotError) * (dmError[m] - dAvgTotError);
  dVarError = dVarError / iNumRuns;

  
  if (iOutputMode == iOUTPUT_VERBOSE)
	System.out.print ("  Pu: "+ String.format(Locale.ENGLISH, "%.2f", GameCoaPrediction.dProbUpdateCell)
			+ "\t NumRuns: " + iNumRuns
			+ "\t iNumGen: " + Game.iNumGen
			+ "\t Avg. Error: "+ String.format(Locale.ENGLISH, "%.5f", dAvgTotError)
			+ "\t Var. Error: " + dVarError);
  else if (iCounter==0)
	System.out.print (String.format(Locale.ENGLISH, "%.5f", dAvgTotError));
  else
  	System.out.print (","+String.format(Locale.ENGLISH, "%.5f", dAvgTotError));

  iCounter++;
  
  }			// for (double dPrew=0.0; dPrew<=1.0; dPrew+=0.1) {     // Probability of rewiring
  System.out.println (); iCounter=0;
  }			// for (double dPu=0.25; dPu<=0.25; dPu+=0.25)		// Neurons to update 0.25->1, 0.5->2, 0.75->3 or 1.0->4
  //System.out.println (); iCounter=0;
  }			// for (double dInf=0.1; dInf<1.0; dInf+=0.1)       // Probability of infection
  //System.out.println (); iCounter=0;
  }   		// for (int k=0; k<=3; k++)         				// Networks
  System.out.println (); iCounter=0;
  }   	  	// for (int j=0; j<2; j++)         				  	// Algorithms SOM and CASOM

  // ************************************* END: Cycles **********************************************
  
  System.out.println ("\n\n#>>> END OF THE BATCH EXECUTION !!!");
  
  System.out.println ("\n# Algoritm: " + Game.sALGOR_PRED[Game.iAlgorithm] +
			"   iNumInputVar: "+ GameCoaPrediction.iNumInputVar +
			"   iTrainEpochs: "+ GameCoaPrediction.iTrainEpochs +
			"   Problem: " + Game.sPROBLEM_PRED[GameCoaPrediction.iFunctionType] +
			"   Pu: " + String.format(Locale.ENGLISH, "%.2f", GameCoaPrediction.dProbUpdateCell) +
			"   Pinf: " + String.format(Locale.ENGLISH, "%.2f", Game.dProbInf) +
			"   Prew: " + String.format(Locale.ENGLISH, "%.2f", Game.dProbRewiring) );

}   // private void vEjecucionBatch() {


}   // from MainWindow class
