package window;

import games.*;
import games.coaMetaNorms.GameCoaMetaNorms;
import games.coaOptimization.GameCoaOptimization;
import games.coaPrediction.GameCoaPrediction;

import java.awt.*;
import java.text.DecimalFormat;
import java.util.Vector;


/**
  * This class allows to visualize a vector that contains vectors with Double values
  *
  * @author  Juan C. Burguillo Rial
  * @version 1.0
  */
public class VisorSerieVectDouble extends Visor implements WindowCons
{
private int iTipoGrafica;


public VisorSerieVectDouble (MainWindow oVentAux, int iTipo) {
  super(oVentAux);
  oWindow = oVentAux;
  iTipoGrafica = iTipo;
  }

public void paint (Graphics g) {
  int iGenIni=0;
  double dAux=0, dSizeMax;
  double dMin = Double.MAX_VALUE;
  double dMax = -Double.MAX_VALUE;
  Double oDouble;
  Vector oVVect=null, oVSerie;
  DecimalFormat oDF5 = new DecimalFormat("0.00000");
  
  switch (iTipoGrafica) {
  
  	case iNET_STATS:
  		g.drawString ("Network Basic Statistics", 160, 20);
  		oVVect = Game.oVNetStats;
  		break;
    
  	case iPROFITxACTION:
    	g.drawString ("Profit x Action", 160, 20);
        oVVect = Game.oVProfitAction;
        break;
    
    case iPROFITxTYPE:
    	g.drawString ("Profit x Type:  Ind (IC), CoaCells (CC) and Leaders (LC)", 80, 20);
    	oVVect = Game.oVProfitType;
    	break;
    	
    case iDYNAMIC_BV:
    	g.drawString ("Evolution of Boldness (B) and Vengefulness (V)", 80, 20);
    	oVVect = GameCoaMetaNorms.ovAvgBV;
    	break;

    case iFUN_VALUES:
    	if (Game.iGameType == Game.iCOA_OPTIMIZATION) {  
    		g.drawString ("Functional Values", 160, 20);
    		oVVect = GameCoaOptimization.oVValFun;
    	}
    	else if (Game.iGameType == Game.iCOA_PREDICTION) {
    		g.drawString ("Functional, Predicted and Error Values", 100, 20);
    		oVVect = GameCoaPrediction.oVValuesFPEL;
    	}

  }

  if ( (oVVect == null) || (oVVect.size() == 0)) return;

  iGenIni = Game.iNumGen - MainWindow.iLastNGen;
  if (iGenIni < 0)
    iGenIni = 0;
  int iGenSize = Game.iNumGen - iGenIni - 1;

  if (Game.iNumGen > 0)
	for (int j=0; j<oVVect.size(); j++) {
	  oVSerie = (Vector) oVVect.elementAt (j);
	  for (int i=0; i<oVSerie.size(); i++) {
	    oDouble = (Double) oVSerie.elementAt(i);
	    dAux = oDouble.doubleValue();
	    if (dAux > dMax)
	      dMax = dAux;
	    if (dAux < dMin)
	      dMin = dAux;
	    }
	}


  dSizeMax = dMax - dMin;
  if (dSizeMax == 0) dSizeMax = Double.MIN_VALUE;                   // To avoid division by zero
  
  g.setColor (Color.black);
  g.drawLine (50, 50, 50, 300);										// Vertical line: Y axis
  g.drawString ("1", 30, 50);
  g.drawLine (45, 50, 55, 50);
  g.drawLine (45, 113, 55, 113);
  g.drawLine (45, 175, 55, 175);
  g.drawLine (45, 238, 55, 238);
  g.drawLine (45, 300, 55, 300);
  if (dMax > -Double.MAX_VALUE) {
    g.drawString ("Max. Value = " + oDF5.format(dMax), 145, 315);
    g.drawString ("Max. Value = " + oDF5.format(dMax), 40, 40);
  }
  if (dMin < Double.MAX_VALUE)
    g.drawString ("Min. Value = " + oDF5.format(dMin), 145, 325);
  g.drawString ("IniG = "+iGenIni, 30, 315);
  g.drawString ("EndG = "+Game.iNumGen, 320, 315);
  
  if (Game.iGameType == Game.iCOA_PREDICTION) {
		int iY = (int) (300.0 - (250.0 * (-dMin)) / dSizeMax);     // Using dSizeMax to normalize
		if (Game.iNumGen==0)
		  iY=300; 
			g.drawLine (50, iY, 350, iY);			// Horizontal line: X axis
			g.drawString ("0", 30, iY);
	    g.drawLine (125, iY-5, 125, iY+5);
	    g.drawLine (200, iY-5, 200, iY+5);
	    g.drawLine (275, iY-5, 275, iY+5);
	    g.drawLine (350, iY-5, 350, iY+5);
	  } else {
			g.drawLine (50, 300, 350, 300);			// Horizontal line: X axis
			g.drawString (".75", 25, 113);
			g.drawString (".5", 25, 175);
			g.drawString (".25", 25, 238);
		  g.drawLine (125, 295, 125, 305);		// Vertical lines in the axis
		  g.drawLine (200, 295, 200, 305);
		  g.drawLine (275, 295, 275, 305);
		  g.drawLine (350, 295, 350, 305);
	  }

  
  
  for (int j=0; j<oVVect.size(); j++) {
	//if (Game.imCellsAction[j]==0) continue;
	  
	  oVSerie = (Vector) oVVect.elementAt (j);
	  if (oVSerie.size() == 0) continue;
    
	  int iX1, iY1, iX2, iY2;
	  if ( (Game.iGameType == Game.iCOA_REPUTATION) && (iTipoGrafica != iNET_STATS) )
	  	g.setColor(new Color(-1677215 * (-5 + j)));
	  else switch (j) {
	  	case 0: 	g.setColor (Color.black); break;
	  	case 1: 	g.setColor (Color.green); break;
	  	case 2: 	g.setColor (Color.red); break;
	  	case 3: 	g.setColor (Color.blue); break;
	  	default: 	g.setColor(Color.orange);
	  }
	  
	  iX1 = 50; iY1 = 175; iX2 = 50; iY2 = 175;
	  for (int i=0; i<iGenSize; i++) {
	    iX2 = 50 + (300 * (i+1)) / iGenSize;
	    oDouble = (Double) oVSerie.elementAt(i);
	    if (iTipoGrafica == iDYNAMIC_BV)
	      iY2 = (int) (300.0 - (250.0 * oDouble.doubleValue()) );
	    else	
	      iY2 = (int) (300.0 - (250.0 * (oDouble.doubleValue()-dMin)) / dSizeMax);     	// Using dSizeMax to normalize
	    
	    g.drawLine (iX1, iY1, iX2, iY2);
	    iX1 = iX2;
	    iY1 = iY2;
	    }
	
	  switch (iTipoGrafica) {
	  
	  	case iNET_STATS:
	  		switch (j) {
	  			case 0: g.drawString ("Mean", iX2+2, iY2-10); break;
	  			case 1: g.drawString ("StDev", iX2+2, iY2-10); break;
	  			case 2: g.drawString ("Range", iX2+2, iY2-10); break;
	  			case 3: g.drawString ("Mode", iX2+2, iY2-10); break;
	  		}
	  		break;
	  		
	    case iPROFITxACTION:
	    	g.drawString ((String) Game.oVTextAction.elementAt(j), iX2+2, iY2-10);
	    	break;
	    		 
	    case iPROFITxTYPE:
	    	switch (j) {
	    		case 0: g.drawString ("IC", iX2+2, iY2-10); break;
	    		case 1: g.drawString ("CC", iX2+2, iY2-10); break;
	    		case 2: g.drawString ("LC", iX2+2, iY2-10); break;
	    	}
	    	break;
	    	
	    case iDYNAMIC_BV:
	    	switch (j) {
	    		case 0: g.drawString ("B", iX2+2, iY2-10); break;
	    		case 1: g.drawString ("V", iX2+2, iY2-10); break;        	}
	    	break;
	    	
	    case iFUN_VALUES:
	    	if (Game.iGameType == Game.iCOA_OPTIMIZATION)
	    		switch (j) {
	    			case 0: g.drawString ("Min", iX2+2, iY2-10); break;
	    			case 1: g.drawString ("Avg", iX2+2, iY2-10); break;
	    			case 2: g.drawString ("Max", iX2+2, iY2-10); break;
			  	}
	    	else if (Game.iGameType == Game.iCOA_PREDICTION)
	    		switch (j) {
	    			case 0: g.drawString ("Fun", iX2+2, iY2-10); break;
	    			case 1: g.drawString ("Pred", iX2+2, iY2-10); break;
	    			case 2: g.drawString ("Err", iX2+2, iY2-10); break;
	    			case 3: g.drawString ("LR", iX2+2, iY2-10); break;
		  	   	}  
	    	
	  }

  }   // for (int j=0; j<oVVect.size(); j++)


}   // public void paint (Graphics g)

}   // from the class






