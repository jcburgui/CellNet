package window;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import games.*;
import games.coaOptimization.CellCoaOpt;
import games.coaReputation.CellCoaRep;



/**
	* This class offers information about a particular cell clicked over the Cell World.
	*
	* @author  Juan C. Burguillo Rial
	* @version 1.0
	*/
class DlgInfoCell extends JDialog implements ActionListener
{
public static boolean bShowCoalition = false;

private Cell oCell;
private int iLastGameType = -1;
private JLabel oJLabelID;

JButton oJButtonNeighbors, oJButtonCoalition;

private JLabel oJLabelNeighbors;		// Alive cells around
private JLabel oJLabelStatus;				// Dead or alive
private JLabel oJLabelCoaState;			// Independent, CoaMember or Leader

private JLabel oJLabelPayoff;
private JLabel oJLabelLeader;
private JLabel oJLabelStrat;
private JLabel oJLabelScore;

private JLabel oJLabelState;
private JLabel oJLabelPosition;
private JLabel oJLabelLearningRate;
private JLabel oJLabelEpsilon;
private JLabel oJLabelAction[] = new JLabel[Game.iNumActions];

/**
  * This is the constructor
  *
  * @param	oParent Pointer to the object that creates this window
  * @param	sTit   Title of this window
  * @param	bBool  Tells if it is modal (true) or not
  */
DlgInfoCell (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);

  setBackground (Color.lightGray);
  setForeground (Color.black);
  
  setLayout(new GridLayout(1,2));
  
  JLabel oJLabel = new JLabel (" Cell Id:", JLabel.LEFT);
  add (oJLabel);
  oJLabelID = new JLabel ("", JLabel.CENTER);
  add (oJLabelID);

  setSize(new Dimension(200,200)); 
  setLocation (new Point (MainWindow.iMapSize + 220, 440));
  setResizable(false);
  setVisible(false);
  }




private void vResetLayout() {
  this.getContentPane().removeAll();
  oJLabelAction = new JLabel[Game.iNumActions];
  switch (Game.iGameType) {
  	case Game.iCOA_LIFE:
  		setLayout (new GridLayout(5,2));
	  	setSize (new Dimension(200,300));
  		break;
  
	  case Game.iSAT_BALL:
			setLayout (new GridLayout(6+Game.iNumActions,2));
			setSize (new Dimension(400,400));
		break;

	  case Game.iCOA_REPUTATION:
	  case Game.iCOA_META_NORMS:
	  	setLayout (new GridLayout(6,2));
	  	setSize (new Dimension(200,300));
	  	break;
			
	  default:
			setLayout (new GridLayout(3,2));
			setSize (new Dimension(200,200));
	}
  
  JLabel oJLabel = new JLabel (" Cell Id:", JLabel.LEFT);
  add (oJLabel);
  oJLabelID = new JLabel ("", JLabel.CENTER);
  add (oJLabelID);

	switch (Game.iGameType) {
		case Game.iCOA_LIFE:
			oJLabel = new JLabel (" Neighbors:", JLabel.LEFT);
	    add (oJLabel);
	    oJLabelNeighbors = new JLabel ("", JLabel.CENTER);
	    add (oJLabelNeighbors);
	    oJLabel = new JLabel (" Status:", JLabel.LEFT);
	    add (oJLabel);
	    oJLabelStatus = new JLabel ("", JLabel.CENTER);
	    add (oJLabelStatus);
	    oJLabel = new JLabel (" Coa State:", JLabel.LEFT);
	    add (oJLabel);
	    oJLabelCoaState = new JLabel ("", JLabel.CENTER);
	    add (oJLabelCoaState);
			break;

		case Game.iSAT_BALL:
	    oJLabel = new JLabel (" Position:", JLabel.LEFT);
	    add (oJLabel);
	    oJLabelPosition = new JLabel ("", JLabel.CENTER);
	    add (oJLabelPosition);
			oJLabel = new JLabel (" State:", JLabel.LEFT);
			add (oJLabel);
			oJLabelState = new JLabel ("", JLabel.CENTER);
			add (oJLabelState);
			oJLabel = new JLabel (" Learning rate:", JLabel.LEFT);
			add (oJLabel);
			oJLabelLearningRate = new JLabel ("", JLabel.CENTER);
			add (oJLabelLearningRate);			
			oJLabel = new JLabel (" Epsilon:", JLabel.LEFT);
			add (oJLabel);
			oJLabelEpsilon = new JLabel ("", JLabel.CENTER);
			add (oJLabelEpsilon);
			for (int i=0; i<Game.iNumActions; i++) {
			  oJLabel = new JLabel ("Action["+i+"]:", JLabel.LEFT);
			  oJLabel.setForeground (Color.blue);
			  add (oJLabel);
			  oJLabelAction[i] = new JLabel ("", JLabel.CENTER);
			  oJLabelAction[i].setForeground (Color.blue);
			  add (oJLabelAction[i]);
			}
			break;
			
		case Game.iCOA_REPUTATION:
		case Game.iCOA_META_NORMS:
	    oJLabel = new JLabel (" Payoff:", JLabel.LEFT);
	    add (oJLabel);
	    oJLabelPayoff = new JLabel ("", JLabel.CENTER);
	    add (oJLabelPayoff);
			oJLabel = new JLabel (" Leader:", JLabel.LEFT);
			add (oJLabel);
			oJLabelLeader = new JLabel ("", JLabel.CENTER);
			add (oJLabelLeader);
			oJLabel = new JLabel (" Strat:", JLabel.LEFT);
			add (oJLabel);
			oJLabelStrat = new JLabel ("", JLabel.CENTER);
			add (oJLabelStrat);
			oJLabel = new JLabel (" Score:", JLabel.LEFT);
			add (oJLabel);
			oJLabelScore = new JLabel ("", JLabel.CENTER);
			add (oJLabelScore);
			break;
			
  	case Game.iCOA_OPTIMIZATION:
  		oJLabel = new JLabel (" Leader:", JLabel.LEFT);
			add (oJLabel);
			oJLabelLeader = new JLabel ("", JLabel.CENTER);
			add (oJLabelLeader);
  		break;
			
		default:
	    oJLabel = new JLabel (" Payoff:", JLabel.LEFT);
	    add (oJLabel);
	    oJLabelPayoff = new JLabel ("", JLabel.CENTER);
	    add (oJLabelPayoff);
	  }
	
	
	
  oJButtonNeighbors = new JButton ("Neighbors");
  oJButtonNeighbors.addActionListener (this);
  add (oJButtonNeighbors);
  oJButtonCoalition = new JButton ("Coalition");
  oJButtonCoalition.addActionListener (this);
  add (oJButtonCoalition);
  
  switch (Game.iGameType) {
  	case Game.iCOA_LIFE:
  	case Game.iCOA_IPD:
  	case Game.iCOA_REPUTATION:
    case Game.iCOA_META_NORMS:
    case Game.iCOA_OPTIMIZATION:
    case Game.iCOA_PREDICTION:	
    	oJButtonCoalition.setEnabled (true);
    	break;
    default:
    	oJButtonCoalition.setEnabled (false);
  }
}



public void repaint() {
  vUpdate (oCell);
}



public void vUpdate (Cell oCellAux) {
  oCell = oCellAux;
  if (oCell == null) return;
  
  if (iLastGameType != Game.iGameType)
  	vResetLayout();

  oJLabelID.setText (oCell.sGetID());
  
  switch (Game.iGameType) {
	  case Game.iCOA_LIFE:
	  	vUpdateCoaLife ();
	  	break;
	  	
    case Game.iSAT_BALL:
    	vUpdateSatBall ();
    	break;
	  	
    case Game.iCOA_REPUTATION:
    case Game.iCOA_META_NORMS:
    	vUpdateRep ();
    	break;
    	
    case Game.iCOA_OPTIMIZATION:
    	vUpdateOpt ();
    	break;
    	
    default:
    	oJLabelPayoff.setText (""+oCell.dGetPayoff());
  }
  setVisible(true);
  iLastGameType = Game.iGameType;
}



private void vUpdateCoaLife() {
	int iNeighborsAlive=0;
	String sStatus, sCoaState;
	Cell oCellAux;
	CellCoa oCellCoa = (CellCoa) oCell;
	Vector<Cell> oVNeighbors = oCell.oVGetNeighbors();
	
	for (int i=0; i<oVNeighbors.size(); i++) {
		oCellAux = (Cell) oVNeighbors.elementAt(i);
		if (oCellAux.iGetAction() == 1)
			iNeighborsAlive++;
	}
	oJLabelNeighbors.setText(""+iNeighborsAlive);
	
	if (oCellCoa.iGetAction() == 0)
		sStatus = "Dead";
	else
		sStatus = "Alive";
	oJLabelStatus.setText(""+sStatus);
	
	if (oCellCoa.bIsIndependent())
		sCoaState = "Independent";
	else if (oCellCoa.bIsCoaMember())
		sCoaState = "CoaMember";
	else
		sCoaState = "Leader (" + oCellCoa.iGetHolonSize() + ")";
	oJLabelCoaState.setText(""+sCoaState);
}





private void vUpdateSatBall () {
  StateAction oStateAction = oCell.oGetLastStateAction();
  oJLabelPosition.setText(""+oCell.iGetPosX() + "," + oCell.iGetPosY());
  if (oStateAction != null) {
    oJLabelState.setText(oStateAction.sGetState());
    oJLabelLearningRate.setText (""+oCell.dGetLearningRate());
    oJLabelEpsilon.setText (""+oCell.dGetEpsilon());
    for (int i=0; i<Game.iNumActions; i++)
      oJLabelAction[i].setText(""+oStateAction.dGetQAction(i));
  }
  else {
    oJLabelState.setText("");
		oJLabelLearningRate.setText ("");
		oJLabelEpsilon.setText ("");
		for (int i=0; i<Game.iNumActions; i++)
		  oJLabelAction[i].setText("");
  }
}


private void vUpdateRep () {
  CellCoaRep oLeader, oCellCoaRep = (CellCoaRep) oCell;
  
  oJLabelPayoff.setText(""+oCell.dGetPayoff());
  oLeader = oCellCoaRep.oGetLeader();
  
  if (oLeader == null)
  	oJLabelLeader.setText("None");
  else
  	oJLabelLeader.setText(oLeader.sGetID());
  
  oJLabelStrat.setText(""+oCellCoaRep.iGetStrat());
  oJLabelScore.setText(""+oCellCoaRep.iGetScore());
}




private void vUpdateOpt () {
  CellCoaOpt oLeader, oCellCoaOpt = (CellCoaOpt) oCell;
  
  oLeader = oCellCoaOpt.oGetLeader();

  if (oCellCoaOpt.bIsLeader())
  	oJLabelLeader.setText("YES");
  else if (oLeader == null)
  	oJLabelLeader.setText("None");
  else
  	oJLabelLeader.setText(oLeader.sGetID());
  
}




/**
  * This method receives and process the events generated by this class
  *
  *	@param evt This is the event parameter generated
  */
public void actionPerformed (ActionEvent evt) {
	if ("Neighbors".equals (evt.getActionCommand()))
		bShowCoalition = false;
	else if ("Coalition".equals (evt.getActionCommand()))
		bShowCoalition = true;
	else
		setVisible(false);
		
	JPanelMainWindow.oVisorWorld.repaint();
}

}	// from the class
