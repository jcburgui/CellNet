package window;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import games.*;



/**
* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
class DlgParamNet extends JDialog implements ActionListener, GameCons
{
private MainWindow oVentana;
private Label oLabel;
private JTextField  oTProbSmallNets,
                    oTRadio,
                    oTNumNeighborsIni,
                    oTInitialNodesNet,
                    oTProbRewire,
                    oTProbRewireRandom,
                    oTNumIntervalos,
                    oTNumValIntervalo;
private Choice oChTipoRed;



/**
 * This is the Dialog constructor
 *
 * @param	oPadre 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 */
DlgParamNet (JFrame oPadre, String sTit, boolean bBool) {
  super (oPadre, sTit, bBool);
  oVentana = (MainWindow) oPadre;

  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(10,2));

  oLabel = new Label (" Network Type:", Label.LEFT);
  add (oLabel);
  oChTipoRed = new Choice();
  for (int i=0; i<sCOMPLEX_NET.length; i++)
    oChTipoRed.add (sCOMPLEX_NET[i]);
  oChTipoRed.select (Game.iNetType);
  add (oChTipoRed);

  oLabel = new Label (" Neighbor Radix (Spatial Net):", Label.LEFT);
  add (oLabel);
  oTRadio = new JTextField(String.valueOf(Game.dRadio), 7);
  if (!oVentana.bEndThread)			// If the thread is running we can not change it
    oTRadio.setEditable (false);
  add (oTRadio);
  
  oLabel = new Label (" Avg. Neighbourhood Size (Complex Nets):", Label.LEFT);
  add (oLabel);
  oTNumNeighborsIni = new JTextField(String.valueOf (Game.dAvgNeighborhoodSize), 7);
  add (oTNumNeighborsIni);

  oLabel = new Label (" Initial Rewire Prob (Small World Net):", Label.LEFT);
  add (oLabel);
  oTProbSmallNets = new JTextField(String.valueOf (Game.dProbSmallNets), 7);
  add (oTProbSmallNets);

  oLabel = new Label (" Initial Nodes (Scale Free):", Label.LEFT);
  add (oLabel);
  oTInitialNodesNet = new JTextField(String.valueOf (Game.iInitialNodesNet), 7);
  add (oTInitialNodesNet);

  oLabel = new Label (" Rewiring Probability:", Label.LEFT);
  oLabel.setForeground (Color.red);
  add (oLabel);
  oTProbRewire = new JTextField(String.valueOf (Game.dProbRewiring), 7);
  add (oTProbRewire);

  oLabel = new Label (" Prob. Rewire Random (0: Best, 1: Random): ", Label.LEFT);
  oLabel.setForeground (Color.red);
  add (oLabel);
  oTProbRewireRandom = new JTextField(String.valueOf (Game.dProbRewireRandom), 7);
  add (oTProbRewireRandom);

  oLabel = new Label (" Node Degree Intervals (Max. 40):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTNumIntervalos = new JTextField(String.valueOf (Game.iNumIntervals), 7);
  add (oTNumIntervalos);

  oLabel = new Label (" Node Degree Values x Interval:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTNumValIntervalo = new JTextField(String.valueOf (Game.iNumValInterval), 7);
  add (oTNumValIntervalo);

  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(650,450));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {
    Game.iNetType = oChTipoRed.getSelectedIndex();
    Game.dRadio = Double.parseDouble (oTRadio.getText());
    Game.dAvgNeighborhoodSize = Double.parseDouble (oTNumNeighborsIni.getText());
    Game.dProbSmallNets = Double.parseDouble (oTProbSmallNets.getText());
    Game.iInitialNodesNet = Integer.parseInt (oTInitialNodesNet.getText());
    Game.dProbRewiring = Double.parseDouble (oTProbRewire.getText());
    Game.dProbRewireRandom = Double.parseDouble (oTProbRewireRandom.getText());
    Game.iNumIntervals = Integer.parseInt (oTNumIntervalos.getText());
    Game.iNumValInterval = Integer.parseInt (oTNumValIntervalo.getText());
      
    JPanelMainWindow.oJLabelNet.setText ("Net: "+sSHORT_COMPLEX_NET[Game.iNetType]);
    
    oVentana.vSetupThread();
    }

  dispose();
}

}	// from the class
