package window;

/**
  * Contains constant definitions for Game
  *
  * @author  Juan C. Burguillo Rial
  * @version 1.0
  */
public interface WindowCons
{
// Graphic types
final int iREDRAW = 0;
final int iNODE_DEGREE_DIST = 1;
final int iNET_STATS = 2;
final int iNET_CC_STATS = 3;
final int iMOVEMENT = 4;
final int iFREQxACTION = 5;
final int iCHANGESxGEN = 6;
final int iCELLSxSTRAT = 7;
final int iGLOBAL_PROFIT = 8;
final int iPROFITxTYPE = 9;
final int iPROFITxACTION = 10;
final int iTAX_HISTOGRAM = 11;
final int iTAXxCOA_CELL = 12;
final int iSTRATS_HISTOGRAM = 13;
final int iSCORES_HISTOGRAM = 14;
final int iDYNAMIC_BV = 15;
final int iSTATIC_BV = 16;
final int iFREQxTYPE = 17;
final int iAVG_PROBS_YPQ = 18;
final int iNEIGHBORSxACTION = 19;
final int iACTIONSxNEIGHBORHOOD_SIZE = 20;
final int iAVG_LINKSxACTION = 21;
final int iAVG_PROB_LA_ACTION = 22;
final int iFUN_VALUES = 23;
final int iERR_VALUES = 24;

}

