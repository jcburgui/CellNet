package window;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import games.*;



/**
	* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
	*
	* @author  Juan C. Burguillo Rial
	* @version 1.0
	*/
class DlgConfiguration extends JDialog implements ActionListener, GameCons
{
private MainWindow oMainWindow;
private Label oLabel;
private JTextField  oTiChangeType,
                    oTdProbEmpty,
                    oTdProbImita,
                    oTiNGenIncubation,
                    oTdProbMut,
                    oTdProbReb,
                    oTdProbJoinCoa,
                    oTdProbInf,
                    oTdLearnRate,
                    oTiGenStop,
                    oTiBufferStat,
                    oTiMiliSeg,
                    oTiLastNGen,
                    oTdNumGen2ChangeAction,
                    oTdNumGen2Rewire,
                    oTiNGenRePaint,
                    oTiMatrixCells,
                    oTdepsGreedy,
                    oTdDecFactor;
private Choice oChChangeType, oChMovement;



/**
  * This is the Dialog constructor
  *
  * @param	oPadre 	Pointer to the parent
  * @param	sTit   	Dialog title
  * @param	bBool 	Tells if the window is modal (true) or not
  */
DlgConfiguration (JFrame oPadre, String sTit, boolean bBool) {
  super (oPadre, sTit, bBool);
  oMainWindow = (MainWindow) oPadre;

  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(11,4));
  
  oLabel = new Label (" Allow Movement (Games 0,1,2):", Label.LEFT);
  add (oLabel);
  oChMovement = new Choice();
  oChMovement.add ("no");
  oChMovement.add ("yes");
  if (Game.bMovement)
    oChMovement.select ("yes");
  add (oChMovement);

  oLabel = new Label (" Mechanism to Change Action:", Label.LEFT);
  add (oLabel);
  if (!oMainWindow.bEndThread) {     										// If the thread is executing, then it can not change
    oTiChangeType = new JTextField(sCHANGE_TYPE[Game.iChangeType], 7);
    oTiChangeType.setEditable (false);
    add (oTiChangeType);
  } else {
    oChChangeType = new Choice();
    for (int i=0; i<sCHANGE_TYPE.length; i++)
      oChChangeType.add (sCHANGE_TYPE[i]);
    oChChangeType.select (Game.iChangeType);
    add (oChChangeType);
  }

  oLabel = new Label (" Prob. of Imitation:", Label.LEFT);
  add (oLabel);
  oTdProbImita = new JTextField(String.valueOf(Game.dProbImita), 7);
  add (oTdProbImita);  
  
  oLabel = new Label (" Matrix Cells (Max. 40000):", Label.LEFT);
  add (oLabel);
  oTiMatrixCells = new JTextField(""+Game.iTotPosMatrix, 7);
  if (!oMainWindow.bEndThread)       										// If the thread is executing, then it can not change
    oTiMatrixCells.setEditable (false);
  add (oTiMatrixCells);

  oLabel = new Label (" Prob. of Mutation:", Label.LEFT);
  add (oLabel);
  oTdProbMut = new JTextField(String.valueOf(Game.dProbMut), 7);
  add (oTdProbMut);
  
  oLabel = new Label (" Break (in generations):", Label.LEFT);
  add (oLabel);
  oTiGenStop = new JTextField(String.valueOf(MainWindow.iGenStop), 7);
  add (oTiGenStop);

  oLabel = new Label (" Prob. of Joining a Coalition:", Label.LEFT);
  add (oLabel);
  oTdProbJoinCoa = new JTextField(String.valueOf(Game.dProbJoinCoa), 7);
  add (oTdProbJoinCoa);

  oLabel = new Label (" Delay in MiliSeconds per Frame:", Label.LEFT);
  add (oLabel);
  oTiMiliSeg = new JTextField(""+oMainWindow.iDelayMilisecs, 7);
  add (oTiMiliSeg);

  oLabel = new Label (" Prob. of Rebelion:", Label.LEFT);
  add (oLabel);
  oTdProbReb = new JTextField(String.valueOf(Game.dProbReb), 7);
  add (oTdProbReb);
   
  oLabel = new Label (" Num. Generations to RePaint:", Label.LEFT);
  add (oLabel);
  oTiNGenRePaint = new JTextField(""+oMainWindow.iNGenRepaint, 7);
  add (oTiNGenRePaint);

  oLabel = new Label (" Prob. of Infection:", Label.LEFT);
  add (oLabel);
  oTdProbInf = new JTextField(String.valueOf(Game.dProbInf), 7);
  add (oTdProbInf);

  oLabel = new Label (" Num. Gen. for Incubation:", Label.LEFT);
  add (oLabel);
  oTiNGenIncubation = new JTextField(String.valueOf(Game.iNGenIncubation), 7);
  add (oTiNGenIncubation);  

  oLabel = new Label (" Prob. of Empty Cell:", Label.LEFT);
  add (oLabel);
  oTdProbEmpty = new JTextField(String.valueOf(Game.dProbEmpty), 7);
  add (oTdProbEmpty);
  
  oLabel = new Label (" Last N Generations (Graphics):", Label.LEFT);
  add (oLabel);
  oTiLastNGen = new JTextField(String.valueOf(MainWindow.iLastNGen), 7);
  add (oTiLastNGen);
  
  oLabel = new Label (" Generations to Change Action:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdNumGen2ChangeAction = new JTextField(String.valueOf(Game.dNumGen2ChangeAction), 7);
  add (oTdNumGen2ChangeAction);
  
  oLabel = new Label (" Generations to Rewire:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdNumGen2Rewire = new JTextField(String.valueOf(Game.dNumGen2Rewire), 7);
  add (oTdNumGen2Rewire);

  oLabel = new Label (" Cell Learn Rate (Autom):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdLearnRate = new JTextField(String.valueOf(Game.dLearnRate), 7);
  add (oTdLearnRate);

  oLabel = new Label (" Buffer Size per Cell (Autom, Stats):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTiBufferStat = new JTextField(""+Game.iStatsBufferSize, 7);
  add (oTiBufferStat);

  oLabel = new Label (" epsilon (Greedy):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdepsGreedy = new JTextField(String.valueOf(Game.depsGreedy), 7);
  add (oTdepsGreedy);

  oLabel = new Label (" Discount factor (epsilon):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdDecFactor = new JTextField(""+Game.dDecFactor, 7);
  add (oTdDecFactor);


  oLabel = new Label ("");
  add (oLabel);         								// Simply to add some label to fit the layout

  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);
  oLabel = new Label ("");
  add (oLabel);         								// Simply to add some label to fit the layout

  setSize(new Dimension(900,500));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
  * This method process all the events produced by this class
  *
  *	@param evt This is the event received
  */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {
    Game.dProbEmpty = Double.parseDouble (oTdProbEmpty.getText());
    Game.dProbImita = Double.parseDouble (oTdProbImita.getText());
    Game.dProbMut = Double.parseDouble (oTdProbMut.getText());
    Game.dProbReb = Double.parseDouble (oTdProbReb.getText());
    Game.dProbJoinCoa = Double.parseDouble (oTdProbJoinCoa.getText());
    Game.dProbInf = Double.parseDouble (oTdProbInf.getText());

    if ("yes".equals (oChMovement.getSelectedItem()))
      Game.bMovement = true;
    else
      Game.bMovement = false;

    Game.iNGenIncubation = Integer.parseInt (oTiNGenIncubation.getText());
    MainWindow.iGenStop = Integer.parseInt (oTiGenStop.getText());
    oMainWindow.iDelayMilisecs = Integer.parseInt (oTiMiliSeg.getText());
    oMainWindow.iNGenRepaint = Integer.parseInt (oTiNGenRePaint.getText());
    MainWindow.iLastNGen = Integer.parseInt (oTiLastNGen.getText());
    Game.dNumGen2ChangeAction = Double.parseDouble (oTdNumGen2ChangeAction.getText());
    Game.dNumGen2Rewire = Double.parseDouble (oTdNumGen2Rewire.getText());
    Game.dLearnRate = Double.parseDouble (oTdLearnRate.getText());
    Game.iStatsBufferSize = Integer.parseInt (oTiBufferStat.getText());
    Game.depsGreedy = Double.parseDouble (oTdepsGreedy.getText());
    Game.dDecFactor = Double.parseDouble (oTdDecFactor.getText());

    if (oMainWindow.bEndThread) {											// If the thread is executing, then it can not change
      int iMatrixCells = Integer.parseInt (oTiMatrixCells.getText());
      if ( (iMatrixCells > 0) && (iMatrixCells <= 40000) )
      	Game.iTotPosMatrix = iMatrixCells;
      
      Game.iChangeType = oChChangeType.getSelectedIndex();
      JPanelMainWindow.oJLabelInfo.setText ("Change: "+Game.iChangeType);
      
      oMainWindow.oGame.vNewGame();
      JPanelMainWindow.oStatusJLabel.setText("NumGen: "+Game.iNumGen+"     N: "+Game.iTotPosMatrix);
    }

    dispose();
    }

  else if ("Cancel".equals (evt.getActionCommand()))
    dispose();
  }

}	// from class DlgConfiguration
