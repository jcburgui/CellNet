package window;

import games.*;
import games.coaReputation.GameCoaReputation;

import java.awt.*;


public class VisorHistogramaInteger extends Visor implements WindowCons
{
int iTipoGrafica;

public VisorHistogramaInteger (MainWindow oVentAux, int iTipoGraficaAux) {
  super(oVentAux);
  iTipoGrafica = iTipoGraficaAux;
  }

public void paint (Graphics g) {
  int[] imMatrix = new int[0];
  int iAux, iFrecMax;
  int iX1, iX2, iY2;

  g.setColor (Color.black);
  g.drawLine (50, 50, 50, 300);
  g.drawLine (50, 300, 350, 300);
  g.drawString ("1", 30, 50);
  g.drawLine (45, 50, 55, 50);
  g.drawString (".75", 25, 113);
  g.drawLine (45, 113, 55, 113);
  g.drawString (".5", 25, 175);
  g.drawLine (45, 175, 55, 175);
  g.drawString (".25", 25, 238);
  g.drawLine (45, 238, 55, 238);


  switch (iTipoGrafica) {
    case iTAX_HISTOGRAM:
    	g.drawString ("Tax Histogram", 170, 20);
    	g.drawString ("0", 50, 315);
    	g.drawString ("100%", 340, 315);
    	imMatrix = Game.iMFrecTax;
    	break;

    case iSTRATS_HISTOGRAM:
    	g.drawString ("Strats Histogram", 170, 20);
    	g.drawString ("C", 45, 315);
    	g.drawString ("D", 350, 315);
    	imMatrix = GameCoaReputation.iMFrecStrat;
    	for (int i=0; i<imMatrix.length; i++)
    	  g.drawString (""+(i-5), 60+25*i, 315);
    	break;

    case iSCORES_HISTOGRAM:
    	g.drawString ("Scores Histogram", 170, 20);
    	imMatrix = GameCoaReputation.iMFrecScore;
    	g.drawString ("Scores Histogram", 170, 20);
    	for (int i=0; i<imMatrix.length; i++)
    	  g.drawString (""+(i-5), 60+ 27*i, 315);
    	break;
  }

  for (int i=0; i<(imMatrix.length+1); i++) {
    iAux = 50 + (300 * i) / imMatrix.length;
    g.drawLine (iAux, 295, iAux, 305);
  }

  iFrecMax=0;
  for (int i=0; i<imMatrix.length; i++)
    if (imMatrix[i] > iFrecMax)
      iFrecMax = imMatrix[i];

  if (iFrecMax > 0) {
    iX1 = 50;
    for (int i=0; i<imMatrix.length; i++) {
      iX2 = 50 + (300 * (i+1)) / imMatrix.length;
      iY2 = 300 - (250 * imMatrix[i]) / iFrecMax;
      g.setColor(new Color(-1677215 * (-5 + i)));
      g.fillRect (iX1+2, iY2, iX2-iX1-4, 300-iY2);
      iX1 = iX2;
      }
    }

  g.setColor (Color.black);
  g.drawString ("Max Freq. = " + iFrecMax, 40, 40);
  }

}		// from the class






