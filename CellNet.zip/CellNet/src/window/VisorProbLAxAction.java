package window;

import java.awt.*;

import games.*;


public class VisorProbLAxAction extends Visor
{
  private boolean bDraw=false;

public VisorProbLAxAction (MainWindow oVentAux) {
  super(oVentAux);
  }

public void paint (Graphics g) {
  int iAux, dFrecMax;
  int iX1, iX2, iY2;
  int[] imNumVecAcc = new int [Game.iNumActions];
  double[][] dmFrecNeighbors = new double [Game.iNumActions][Game.iNumActions];
  int iAccionPropia;
  Cell oCell;

  g.setColor (Color.black);
  g.drawLine (50, 50, 50, 300);
  g.drawLine (50, 300, 350, 300);
  g.drawString ("100", 22, 50);
  g.drawLine (45, 50, 55, 50);
  g.drawString ("75", 25, 113);
  g.drawLine (45, 113, 55, 113);
  g.drawString ("50", 25, 175);
  g.drawLine (45, 175, 55, 175);
  g.drawString ("25", 25, 238);
  g.drawLine (45, 238, 55, 238);
  for (int i=0; i<(Game.iNumActions+1); i++) {
    iAux = 50 + (300 * i) / Game.iNumActions;
    g.drawLine (iAux, 295, iAux, 305);
    }

  g.drawString ("Prob. LA x Action (%)", 170, 20);
  for (int i=0; i<(Game.iNumActions); i++) {
    iAux = 85 + (300 * i) / Game.iNumActions;
    g.drawString ((String) Game.oVTextAction.elementAt(i), iAux, 320);
    }

       	// Reset all matrixes
  for (int i=0; i<Game.iNumActions; i++)
    imNumVecAcc[i] = 0;

  		//Setting the number of neighbors per cell type (adding all values)
  for (int y=0; y<Game.iCellV; y++)
    for (int x=0; x<Game.iCellH; x++)
      if (Game.oCellMatrix[x][y] == null)
        continue;
      else {
        bDraw = true;
        oCell = Game.oCellMatrix[x][y];
        iAccionPropia = oCell.iGetAction();
        imNumVecAcc[iAccionPropia]++;
        for (int j=0; j<Game.iNumActions; j++)
          dmFrecNeighbors[iAccionPropia][j] += oCell.dGetProbAction(j);
      }


  if (!bDraw) return;


  dFrecMax=0;
  for (int i=0; i<Game.iNumActions; i++) {
    if (imNumVecAcc[i] > 0)
      for (int j=0; j<Game.iNumActions; j++) {
        dmFrecNeighbors[i][j] = 100.0 * dmFrecNeighbors[i][j] / (double) imNumVecAcc[i];
        if (dmFrecNeighbors[i][j] > dFrecMax)
          dFrecMax = (int)dmFrecNeighbors[i][j];
      }
  }


  iAux = Game.iNumActions*Game.iNumActions;
  if (dFrecMax > 0) {
    iX1 = 50;
    for (int i=0; i<Game.iNumActions; i++)
      for (int j=0; j<Game.iNumActions; j++) {
        iX2 = 50 + (300 * (1+j+i*Game.iNumActions)) / iAux;
        iY2 = 300 - (250 * (int) dmFrecNeighbors[i][j]) / 100;
        switch (j) {
          case 0: g.setColor (Color.black); break;
          case 1: g.setColor (Color.green); break;
          case 2: g.setColor (Color.red); break;
          case 3: g.setColor (Color.blue);
        }

        g.fillRect (iX1+2, iY2, 15, 300-iY2);
        iX1 = iX2;
      }
    }

  g.setColor (Color.black);
  g.drawString ("Max Freq. = " + dFrecMax, 40, 40);
  }

}		// from class
