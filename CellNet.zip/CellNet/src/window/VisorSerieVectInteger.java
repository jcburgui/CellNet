package window;

import games.*;

import java.awt.*;
import java.util.Vector;


/**
  * This class allows to visualize a vector that contains series of Integers
  *
  * @author  Juan C. Burguillo Rial
  * @version 1.0
  */
public class VisorSerieVectInteger extends Visor implements WindowCons
{
private static final long serialVersionUID = 1L;
private int iTipoGrafica;
private int iMax = 100;     		// Using iMax to normalize graphics

public VisorSerieVectInteger (MainWindow oVentAux, int iTipo) {
  super(oVentAux);
  oWindow = oVentAux;
  iTipoGrafica = iTipo;
  }

public void paint (Graphics g) {
  int iGenIni=0;
  Integer oInt;
  Vector oVVect = new Vector(1,1);
  Vector<Integer> oVSerie;
  
  g.setColor (Color.black);
  g.drawLine (50, 50, 50, 300);
  g.drawLine (50, 300, 350, 300);
  g.drawString ("1", 30, 50);
  g.drawLine (45, 50, 55, 50);
  g.drawString (".75", 25, 113);
  g.drawLine (45, 113, 55, 113);
  g.drawString (".5", 25, 175);
  g.drawLine (45, 175, 55, 175);
  g.drawString (".25", 25, 238);
  g.drawLine (45, 238, 55, 238);
  g.drawLine (125, 295, 125, 305);
  g.drawLine (200, 295, 200, 305);
  g.drawLine (275, 295, 275, 305);
  g.drawLine (350, 295, 350, 305);

  switch (iTipoGrafica) {
    case iMOVEMENT:
    	g.drawString ("Movements of Cells per Action", 120, 20);
    	oVVect = Game.oVFrecMov;
    	break;
              
    case iFREQxACTION:
    	g.drawString ("Frequency of Cells x Action", 130, 20);
    	oVVect = Game.oVFrecActions;
    	break;
              
    case iCELLSxSTRAT:
    	g.drawString ("Number of Cells x Strategy Type", 120, 20);
    	oVVect = Game.oVCellsxStrat;
    	break;

    case iFREQxTYPE:
			g.drawString ("Frequency of Cell Types", 130, 20);
			oVVect = Game.oVFrecTypes;
			break;
  }

  iGenIni = Game.iNumGen - MainWindow.iLastNGen;
  if (iGenIni < 0)
    iGenIni = 0;
  int iGenSize = Game.iNumGen - iGenIni - 1;
  
  for (int j=0; j<oVVect.size(); j++) {
    oVSerie = (Vector) oVVect.elementAt (j);
    if (oVSerie.size() > 0) {
      int iX1, iY1, iX2, iY2;
      if (Game.iGameType == Game.iCOA_REPUTATION)
      	g.setColor(new Color(-1677215 * (-5 + j)));
      else switch (j) {
      	case 0: g.setColor (Color.black); break;
      	case 1: g.setColor (Color.green); break;
      	case 2: g.setColor (Color.red); break;
      	case 3: g.setColor (Color.blue);
      }

      iX1 = 50; iY1 = 175; iX2 = 50; iY2 = 175;
      for (int i=0; i<iGenSize; i++) {
        iX2 = 50 + (300 * (i+1)) / iGenSize;
        oInt = (Integer) oVSerie.elementAt(i);
        iY2 = 300 - (250 * oInt.intValue()) / iMax;	// Using iMax to normalize
        g.drawLine (iX1, iY1, iX2, iY2);
        iX1 = iX2;
        iY1 = iY2;
        }
      
      switch (iTipoGrafica) {
        case iCELLSxSTRAT:
        	if (Game.iGameType == Game.iCOA_IPD) switch (j) {
      			case 0: g.drawString ("pTFT", iX2+2, iY2-10); break;
      			case 1: g.drawString ("LA", iX2+2, iY2-10); break;
      			case 2: g.drawString ("Stats", iX2+2, iY2-10);
            }
        	else if (Game.iGameType == Game.iCOA_LIFE) switch (j) {
	    			case 0: g.drawString ("D", iX2+2, iY2-10); break;
	    			case 1: g.drawString ("C", iX2+2, iY2-10); break;
        		}
        	else switch (j) {
      			case 0: g.drawString ("BN", iX2+2, iY2-10); break;
      			case 1: g.drawString ("BS", iX2+2, iY2-10); break;
      			case 2: g.drawString ("PS", iX2+2, iY2-10); break;
      			case 3: g.drawString ("INF", iX2+2, iY2-10); break;
      			case 4: g.drawString ("RND", iX2+2, iY2-10); break;
      			case 5: g.drawString ("pBN", iX2+2, iY2-10); break;
      			case 6: g.drawString ("pBS", iX2+2, iY2-10); break;
      			case 7: g.drawString ("pPS", iX2+2, iY2-10); break;
      			case 8: g.drawString ("AS", iX2+2, iY2-10); break;
      			case 9: g.drawString ("LA", iX2+2, iY2-10); break;
      			case 10: g.drawString ("QL", iX2+2, iY2-10); break;
          	}
        	break;

        case iFREQxTYPE:
        	switch (j) {
        		case 0: g.drawString ("ID", iX2+2, iY2-10); break;
        		case 1: g.drawString ("CC", iX2+2, iY2-10); break;
        		case 2: g.drawString ("LD", iX2+2, iY2-10);
        	}
        	break;
        
        case iAVG_PROBS_YPQ:
        	switch (j) {
        		case 0: g.drawString ("p", iX2+2, iY2-10); break;
        		case 1: g.drawString ("q", iX2+2, iY2-10);
        	}
        	break;

        case iSTRATS_HISTOGRAM:
        	switch (j) {
        		case 0: g.drawString ("I", iX2+2, iY2-10); break;
        		case 1: g.drawString ("C", iX2+2, iY2-10);
        	}
        	break;
                  
        default:  g.drawString ((String) Game.oVTextAction.elementAt(j), iX2+2, iY2-10);
                  
        }
      
      }   // if (oVSerie.size() > 0)
    
    }   // for (int j=0; j<oVVect.size(); j++)
    
  	g.setColor (Color.black);
    g.drawString ("IniG = "+iGenIni, 50, 315);
    g.drawString ("EndG = "+Game.iNumGen, 310, 315);
    
  }   // public void paint (Graphics g)

}   // from the class






