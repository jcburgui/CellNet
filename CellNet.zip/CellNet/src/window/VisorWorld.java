package window;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.Vector;

import games.*;
import games.coaIPD.GameCoaIPD;
import games.coaLife.GameCoaLife;
import games.coaMetaNorms.GameCoaMetaNorms;
import games.coaOptimization.CellCoaOpt;
import games.coaOptimization.GameCoaOptimization;
import games.coaPrediction.CellCoaPred;
import games.coaPrediction.GameCoaPrediction;
import games.coaReputation.CellCoaRep;
import games.coaReputation.GameCoaReputation;


public class VisorWorld extends Visor {
  private boolean bMouseClicked = false;
  private Cell oCellClicked = null;
	
public VisorWorld(MainWindow oVentAux) {
  super(oVentAux);
  }


public void mouseClicked (MouseEvent oME) {
  Cell[][] oCellMatrix;
  Point oPoint = oME.getPoint();
  
  switch (Game.iGameType) {
  	case Game.iCOA_IPD:            	oCellMatrix = GameCoaIPD.oCellMatrix; break;
  	case Game.iCOA_REPUTATION:			oCellMatrix = GameCoaReputation.oCellMatrix; break;
  	case Game.iCOA_META_NORMS:			oCellMatrix = GameCoaMetaNorms.oCellMatrix; break;
  	case Game.iCOA_OPTIMIZATION:    oCellMatrix = GameCoaOptimization.oCellMatrix; break;
  	case Game.iCOA_PREDICTION:      oCellMatrix = GameCoaPrediction.oCellMatrix; break;
  	default:                        oCellMatrix = Game.oCellMatrix;
  }
  
  bMouseClicked = true;
  oCellClicked = oCellMatrix	[(int) (oPoint.getX() / (double) MainWindow.iCellSize)]
  														[(int) (oPoint.getY() / (double) MainWindow.iCellSize)];  
  MainWindow.oDlgInfoCell.vUpdate (oCellClicked);
  repaint();
}


public void paint (Graphics oGraphics)
 {update (oGraphics);}


public void update (Graphics oGraphics) {
	//Image offImage = createImage (MainWindow.iMapSize, MainWindow.iMapSize);
	Image offImage = createImage (oGraphics.getClipBounds().width, oGraphics.getClipBounds().height);
  Graphics offg = offImage.getGraphics();

  if (oWindow.oGame.iNewGame > 0) switch (Game.iGameType) {
  	case Game.iCOA_LIFE:            vDrawCells (offg, GameCoaLife.oCellMatrix); break;
    case Game.iCOA_IPD:            	vDrawCells (offg, GameCoaIPD.oCellMatrix); break;
    case Game.iCOA_REPUTATION:  		vDrawCells (offg, GameCoaReputation.oCellMatrix); break;
    case Game.iCOA_META_NORMS:  		vDrawCells (offg, GameCoaMetaNorms.oCellMatrix); break;
    case Game.iCOA_OPTIMIZATION:    vDrawCells (offg, GameCoaOptimization.oCellMatrix); break;
    case Game.iCOA_PREDICTION:      vDrawCells (offg, GameCoaPrediction.oCellMatrix); break;
    default:                        vDrawCells (offg, Game.oCellMatrix);
  }

  if ( (bMouseClicked) && (oCellClicked != null) )
    vDrawCellNeighborsCoalition (offg, oCellClicked);

  oGraphics.drawImage (offImage, 0, 0, this);
  
  bMouseClicked = false;
 
}




private void vDrawCells (Graphics offg, Cell[][] oCellMatrix) {
  Cell oCell;

  int xAux=0, yAux=0;
  for (int y=0; y<Game.iCellV; y++) {
    for (int x=0; x<Game.iCellH; x++) {
      oCell = oCellMatrix[x][y];

      if (oCell == null)                                     // Empty cell
        offg.setColor (Color.blue);
      
      else if (Game.iGameType == Game.iSAT_BALL)
      	switch (oCell.iGetCellType()) {
          case 0:   offg.setColor (Color.black); break;
          
          case 1:		if (oCell.iGetColor() == 0)
        	  		  		offg.setColor (Color.white);
		        	  		else if (oCell.iGetColor() == 1)   
		        	  		  offg.setColor (Color.yellow);
		          			else if (oCell.iGetColor() == 2)
		          			  offg.setColor (Color.green);
		          			else if (oCell.iGetColor() == 3)
		            		  offg.setColor (Color.cyan);
		          			break;
          			
          case 2:   offg.setColor (Color.red); break;
        }
      
      else switch (oCell.iGetAction()) {
          case 0:   offg.setColor (Color.black); break;
          case 1:   offg.setColor (Color.green); break;
          case 2:   offg.setColor (Color.red); break;
          case 3:   offg.setColor (Color.blue); break;
        }

      offg.fillRect (xAux, yAux, MainWindow.iCellSize, MainWindow.iCellSize);
      if (MainWindow.iCellSize > 2) {
	    offg.setColor (Color.green);
        offg.drawRect (xAux, yAux, MainWindow.iCellSize, MainWindow.iCellSize);
	    }

      xAux += MainWindow.iCellSize;
      }
    xAux=0;
    yAux += MainWindow.iCellSize;
    }

  }





private void vDrawCells (Graphics offg, CellCoa[][] oCellMatrix) {
	int xAux=0, yAux=0;
  CellCoa oCellCoa;
  CellCoaRep oCellRepNowak;
  CellCoaOpt oCellCoaOpt;
  CellCoaPred oCellCoaPred;

  for (int y=0; y<Game.iCellV; y++) {
    for (int x=0; x<Game.iCellH; x++) {
      oCellCoa = oCellMatrix[x][y];

      if (oCellCoa == null)                                    // Empty cell
        offg.setColor (Color.blue);

      else switch (Game.iVisorShow) {
             // Show cells (or coalitions if there are)
        case 0:
        	offg = vDrawColorCoaCell (offg, oCellCoa);
        	break;

           // Shows the payoff / Income
        case 1:
          offg.setColor (new Color ( (int) (16777215.0 * (oCellCoa.dGetPayoff() - Game.dMinIncome) / 
                                           (Game.dMaxIncome - Game.dMinIncome))));
          break;
          
          // Shows the incomes received by cell per generation
        case 2:
          offg.setColor (new Color((int) (16777215.0 * (oCellCoa.dGetPayoffGen() - Game.dCellIncomeGen))));
          break;
        
          // Shows the Strat (Nowak)
        case 3:
          oCellRepNowak = (CellCoaRep) oCellMatrix[x][y];
          offg.setColor (new Color(-1677215 * oCellRepNowak.iGetStrat()));
          break;
          
          // Shows the Score (Nowak)
        case 4:
          oCellRepNowak = (CellCoaRep) oCellMatrix[x][y];
          offg.setColor (new Color(-1677215 * oCellRepNowak.iGetScore()));
          break;
               
          // Shows the quality of the solution (Optimization)
        case 10:
          oCellCoaOpt = (CellCoaOpt) oCellMatrix[x][y];
          offg.setColor (new Color ( (int) (16777215.0 * (oCellCoaOpt.dGetValFun() - GameCoaOptimization.dMINValFun) / 
                                           (GameCoaOptimization.dMAXValFun - GameCoaOptimization.dMINValFun)) ) );
          break;
          
          // Shows the quality of the solution (Prediction)
        case 11:
          oCellCoaPred = (CellCoaPred) oCellMatrix[x][y];
          offg.setColor (new Color (16777215 * oCellCoaPred.iGetNumBMU()) );
          break;
                    
        }

      offg.fillRect (xAux, yAux, MainWindow.iCellSize, MainWindow.iCellSize);
      if (MainWindow.iCellSize > 2) {
        offg.setColor (Color.green);
        offg.drawRect (xAux, yAux, MainWindow.iCellSize, MainWindow.iCellSize);
      }

      xAux += MainWindow.iCellSize;
    }
    xAux=0;
    yAux += MainWindow.iCellSize;
  }

}


private void vDrawCellNeighborsCoalition (Graphics offg, Cell oCell) {
  int xAux=0, yAux=0;
  Cell oCellAux;
  CellCoa oCellCoa, oCoaLeader = null;
  Vector oVect = new Vector (1,1);
  
  offg.setColor (Color.red);										// Then we paint the cell in red
  xAux = oCell.iGetPosX() * MainWindow.iCellSize;
  yAux = oCell.iGetPosY() * MainWindow.iCellSize;
  offg.fillRect (xAux, yAux, MainWindow.iCellSize, MainWindow.iCellSize);  
  
  if (DlgInfoCell.bShowCoalition) {
  	oCellCoa = (CellCoa) oCell;
  	oCoaLeader = (CellCoa) oCellCoa.oRecGetLeader();
  	if (oCoaLeader != null)
  		oVect = oCoaLeader.oVGetHolonParts();
  }
  else
  	oVect = oCell.oVGetNeighbors();

  offg.setColor (Color.yellow);
  for (int i=0; i<oVect.size(); i++) {										// Painting the neighborhood/coalition members in yellow
    oCellAux = (Cell) oVect.elementAt (i);
    xAux = oCellAux.iGetPosX() * MainWindow.iCellSize;
    yAux = oCellAux.iGetPosY() * MainWindow.iCellSize;
   	offg.fillRect (xAux, yAux, MainWindow.iCellSize, MainWindow.iCellSize);
  }
  
  if (oCoaLeader != null) {
  	offg.setColor (Color.white);														// If showing coalitions -> painting the leader in white
  	xAux = oCoaLeader.iGetPosX() * MainWindow.iCellSize;
    yAux = oCoaLeader.iGetPosY() * MainWindow.iCellSize;
    offg.fillRect (xAux, yAux, MainWindow.iCellSize, MainWindow.iCellSize);
  }
}



private Graphics vDrawColorCoaCell (Graphics offg, CellCoa oCellCoa) {
	int iAux;
  boolean bLeader = oCellCoa.bIsLeader();
	CellCoa oLeader = oCellCoa.oRecGetLeader();

  if (oLeader != null) {              // If has or belongs to a coalition, take its color
    if (bLeader && Game.bShowLeaders)
      offg.setColor (Color.white);
    else {
      iAux = 1021 * (7 + oLeader.hashCode());
      while (iAux < 1021)           	// If it get close to black --> changes
        iAux = 1021 * (7+iAux);
      offg.setColor (new Color (iAux));
    }
  }
  else if ( (Game.iGameType == Game.iCOA_LIFE) && (oCellCoa.iGetAction() == 1) )
    offg.setColor (Color.green);			// Independent cells are green in CoaLife
  else
    offg.setColor (Color.black);      // Black by defect

  return offg;
}


}		// from the class VisorWorld






