package window;

import java.awt.*;

import games.Game;
import games.coaMetaNorms.GameCoaMetaNorms;


public class VisorStaticBV extends Visor
{
private int iMin = Integer.MAX_VALUE;
private int iMax = -Integer.MAX_VALUE;

public VisorStaticBV (MainWindow oVentAux) {
  super(oVentAux);
  }

public void paint (Graphics g) {
  int iX, iY;
  double dB, dV;
  
  g.setColor (Color.black);

  g.drawLine (50, 50, 50, 300);
  g.drawLine (50, 300, 350, 300);
  g.drawString ("V", 30, 50);
  g.drawLine (45, 50, 55, 50);
  g.drawString (".75", 25, 113);
  g.drawLine (45, 113, 55, 113);
  g.drawString (".5", 25, 175);
  g.drawLine (45, 175, 55, 175);
  g.drawString (".25", 25, 238);
  g.drawLine (45, 238, 55, 238);
  g.drawLine (125, 295, 125, 305);
  g.drawLine (200, 295, 200, 305);
  g.drawLine (275, 295, 275, 305);
  g.drawLine (350, 295, 350, 305);
  
  g.drawString ("Map of Boldness (B) and Vengefulness (V)", 130, 20);
  g.drawString ("0", 30, 315);
  g.drawString ("0.25", 115, 315);
  g.drawString ("0.5", 195, 315);
  g.drawString ("0.75", 270, 315);
  g.drawString ("B", 350, 315);

  g.setColor (Color.blue);
  
  for (int y=0; y<Game.iCellV; y++)
  for (int x=0; x<Game.iCellH; x++) {
	if (GameCoaMetaNorms.oCellMatrix[x][y] == null) continue;                                 // If it is an empty cell goes to next

	dB = GameCoaMetaNorms.oCellMatrix[x][y].dGetBoldness();
  	dV = GameCoaMetaNorms.oCellMatrix[x][y].dGetVengefulness();
  	iX = (int) (50.0 + (300.0 * dB));
  	iY = (int) (300 - (250 * dV));
  	g.fillOval (iX, iY, 5, 5);
  }  

}   // from paint (Graphics g)

}   // from class






