package games.iHawkDovePossessorTrader;

import javax.swing.*;

import window.MainWindow;

import java.awt.*;
import java.awt.event.*;

import games.*;



/**
* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class DlgParamIPD extends JDialog implements ActionListener, GameCons
{
private Label oLabel;
private JTextField  oTdProbDefector;
private MainWindow oMainWindow;
private Choice oChImitateBest;

/**
 * This is the Dialog constructor
 *
 * @param	oPadre 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 */
public DlgParamIPD (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);

  oMainWindow = (MainWindow) oParent;
  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(3,2));

  oLabel = new Label (" Imitate Best:", Label.LEFT);
  add (oLabel);
  oChImitateBest = new Choice();
  oChImitateBest.add ("no");
  oChImitateBest.add ("yes");
  if (GameHDPT.bImitateBEST)
  	oChImitateBest.select ("yes");
  add (oChImitateBest);
  
  oLabel = new Label (" Defector Prob. [0,1]:", Label.LEFT);
  add (oLabel);
  oTdProbDefector = new JTextField(String.valueOf(GameHDPT.dProbDefector), 7);
  add (oTdProbDefector);
  
  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(500,200));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {
    GameHDPT.dProbDefector = Double.parseDouble (oTdProbDefector.getText());
    
    if ("yes".equals (oChImitateBest.getSelectedItem()))
    	GameHDPT.bImitateBEST = true;
    else
    	GameHDPT.bImitateBEST = false;

  }

  dispose();
}

}	// from the class
