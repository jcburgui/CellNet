package games.iHawkDovePossessorTrader;

import games.Cell;
import games.Game;

import java.util.Vector;

import window.DlGraphics;
import window.MainWindow;
import window.WindowCons;



/**
  * This class implements the Iterated Prisoner's Dilemma and the Hawk-Dove-Possessor-Trade Games:
  *		- Cooperator (C)
  *		- Defector (D)
  *		- Possessor (P)
  *		- Trader (T)
  *
  * @author  Juan C. Burguillo Rial
  * @version 4.0
  */
public class GameHDPT extends Game implements WindowCons
{
public static double dProbDefector = 0.5;	      // Probability of initially having a hawk (defector)
public static boolean bImitateBEST = true;			// To decide the change in the actions/strategies
	
//------------------------------- JUEGO iHAWK_DOVE_POSS_TRADER ------------------------------------------
						// iHAWK_DOVE_POSS_TRADER use these values to determine v < x < V
public static double dMaxPropVal = 5.0;				// Max. value of a resource = V
public static double dMinPropVal = 1.0;				// Min. value of a resource = v
public static double dCostPropVal = 1.0;			// Cost value of a resource = h
//--------------------------------------------------------------------------------------------------


/**
 * This is the class constructor
 *
 */
public GameHDPT () {
	super();
	 
	if (iGameType == iHAWK_DOVE_POSS_TRADER) {
		iNumActions = 4;
		dPayMatrix[0][0][0] = (dMaxPropVal + dMinPropVal) / 4 - dCostPropVal;		// -2.5 to 0.5
		dPayMatrix[0][1][0] = (dMaxPropVal + dMinPropVal) / 2;									// 3.00
		dPayMatrix[1][0][0] = 0;																								// 0.00
		dPayMatrix[1][1][0] = (dMaxPropVal + dMinPropVal) / 4;									// 1.50
	}
	else {
		iNumActions = 2;				// IPD Game: payoff matrix with two restrictions: T>R>P>S and 2R>(S+T)
		dPayMatrix[0][0][0] = 0.5;	// dP
		dPayMatrix[0][1][0] = 3.5;	// dT
		dPayMatrix[1][0][0] = 0;		// dS
		dPayMatrix[1][1][0] = 3;		// dR
	}

  GameHDPT.dPayMatrix[0][0][1] = GameHDPT.dPayMatrix[0][0][0];
  GameHDPT.dPayMatrix[0][1][1] = GameHDPT.dPayMatrix[1][0][0];
  GameHDPT.dPayMatrix[1][0][1] = GameHDPT.dPayMatrix[0][1][0];
  GameHDPT.dPayMatrix[1][1][1] = GameHDPT.dPayMatrix[1][1][0];
	
	dProbRewiring = 0;
	 
	iTotPosMatrix = 1600;					// Initial number of cells in the matrix
}



/**
  * This is the class constructor
  *
  */
public GameHDPT (MainWindow oVentAux) {
  this();
  oMainWindow = oVentAux;
}





/**
  * This method is started when we press "New" button
  *
  */
public void vNewGame() {
  super.vNewGame();

  String sId;
  int iTipoCell = 0;
  int iAction;

	if (iGameType == iHAWK_DOVE_POSS_TRADER) {
		dPayMatrix[0][0][0] = (dMaxPropVal + dMinPropVal) / 4 - dCostPropVal;		// -2.5 to 1.5
		dPayMatrix[0][1][0] = (dMaxPropVal + dMinPropVal) / 2;									// 3.00
		dPayMatrix[1][0][0] = 0;																								// 0.00
		dPayMatrix[1][1][0] = (dMaxPropVal + dMinPropVal) / 4;									// 1.50
		
	  GameHDPT.dPayMatrix[0][0][1] = GameHDPT.dPayMatrix[0][0][0];
	  GameHDPT.dPayMatrix[0][1][1] = GameHDPT.dPayMatrix[1][0][0];
	  GameHDPT.dPayMatrix[1][0][1] = GameHDPT.dPayMatrix[0][1][0];
	  GameHDPT.dPayMatrix[1][1][1] = GameHDPT.dPayMatrix[1][1][0];
	}
  
  oVTextAction = new Vector<String> (1,1);
  oVTextAction.add ("D");									// D == 0, Defectors
  oVTextAction.add ("C");									// C == 1, Cooperators
  if (iNumActions > 2)
    oVTextAction.add ("P");									// P == 2, Possessors
  if (iNumActions > 3)
    oVTextAction.add ("T");             					// T == 3, Traders

  for (int x=0; x<iCellH; x++)						// Initializing the cell matrix depending on the games and actions
  for (int y=0; y<iCellV; y++) {
    if (dProbEmpty > 0.0)
    	if (dProbEmpty > Math.random()) {
    		oCellMatrix[x][y] = null;					// If empty cells are allowed, setting them with null
    		continue;
    	}

	  sId = new String (""+x+","+y);

  	if (Math.random() < dProbDefector)
  		iAction = iHAWK;
  	else
  		iAction = (int) ((double) (iNumActions - 1) * Math.random() + 1);
	
	  imCellsType[0]++;
	  imCellsAction[iAction]++;
	  iTotNumCells++;
	  oCellMatrix[x][y] = new Cell (sId, iTipoCell, iAction);
	}  	

  oVectorCells = ovCells2Vector (oCellMatrix);		// Creates a line vector to simplify random access

  switch (iNetType) {
  	case 0:   vSetNeighborsSpatialRadio (oCellMatrix); break;
  	case 1:   vSetNeighborsSmallWorld (oCellMatrix); break;
  	case 2:   vSetNeighborsScaleFree (oCellMatrix); break;
  	case 3:   vSetNeighborsRandomNetwork (oCellMatrix); break;
  }
  

  if ( (iNewGame == 0) && (MainWindow.iBatchMode < 2) ) {
  
  	MainWindow.oMIPayMatrix.setEnabled (true);  

		MainWindow.oMIWindow[iFREQxACTION].setEnabled (true);
		MainWindow.oMIWindow[iCHANGESxGEN].setEnabled (true);
		MainWindow.oMIWindow[iGLOBAL_PROFIT].setEnabled (true);
		MainWindow.oMIWindow[iPROFITxACTION].setEnabled (true);
  
    if (MainWindow.iBatchMode == 0) {
      MainWindow.omDlGraf[iFREQxACTION] = new DlGraphics (oMainWindow, " CellNet: Frequency per Action", false, iFREQxACTION);
		  MainWindow.omDlGraf[iFREQxACTION].setVisible(true);
		  MainWindow.omDlGraf[iCHANGESxGEN] = new DlGraphics (oMainWindow, " CellNet: Action Changes", false, iCHANGESxGEN);
		  MainWindow.omDlGraf[iCHANGESxGEN].setVisible(true);
		  MainWindow.omDlGraf[iGLOBAL_PROFIT] = new DlGraphics (oMainWindow, " CellNet: Global Profit", false, iGLOBAL_PROFIT);
		  MainWindow.omDlGraf[iGLOBAL_PROFIT].setVisible(true);
		  MainWindow.omDlGraf[iPROFITxACTION] = new DlGraphics (oMainWindow, " CellNet: Profit per Action", false, iPROFITxACTION);
		  MainWindow.omDlGraf[iPROFITxACTION].setVisible(true);
    }
  }
  
  iNewGame++;
}




/**
  * This method contains the code executed in parallel
  */
public void vRunLoop() {
	double dProbChangeActvsRewire = 1.0 / (1.0 + dNumGen2ChangeAction / dNumGen2Rewire);
	
  iNumGen++;                              						// Increasing the number of generations (games iterations)
  iNumChanges = 0;
	
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
      continue;																				// If it is an empty cell, then moves to next
    else
      oCellMatrix[x][y].vResetPayoff ();							// Put new income to zero

	for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)												// Every cell plays a prisoner's dilemma with its neighbors
    if (oCellMatrix[x][y] == null)
      continue;
    else
    	vCalcPayoffs (oCellMatrix[x][y]);			    			// Calculates the payoff for the interacting cells
  
  imCellsAction = new int [iNumActions];	// Reset
  imMovAction = new int [iNumActions];		// Reset
  
	for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)												// Every cell plays a prisoner's dilemma with its neighbors
    if (oCellMatrix[x][y] == null)
      continue;
    else
    	oCellMatrix[x][y].vUpdateBufferPayoff();			  // Update synchronously the buffer payoffs for all the cells

  Vector<Cell> oVectorCellsAux = (Vector) oVectorCells.clone();  	
  while (oVectorCellsAux.size() > 0) {
    int iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
    Cell oCell = (Cell) oVectorCellsAux.elementAt (iAux);
    oVectorCellsAux.removeElementAt(iAux);
    
    if (bUseNowaksW) {																// Change action or rewire
      if (Math.random() < dProbChangeActvsRewire)
      	vChangeAction (oCell);                       	// Change strategies in a "non-sequential" way
      else
        vRewire (oCell);                            	// Change the neighbors of cells in a "non-sequential" way
    }
    else {																						// Change action, and rewire?
    	vChangeAction (oCell);
      if (Math.random() < dProbRewiring)
        vRewire (oCell);
    }
    imCellsAction[oCell.iGetNewAction()]++;
  }
  
  dGlobalProfit = 0;
  dmProfitAction = new double [iNumActions];
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
    	continue;
    else {
      dmProfitAction[oCellMatrix[x][y].iGetAction()] += oCellMatrix[x][y].dGetPayoff();
  	  dGlobalProfit += oCellMatrix[x][y].dGetPayoff();
  	  oCellMatrix[x][y].vUpdateAction ();						// Updates synchronously the new actions
  	}
  
  
  if (MainWindow.iBatchMode < 2)
  	vSetGraphicValues();
  
  sTextStateBar = "NGen: "+iNumGen +"  D: "+imCellsAction[0] +"  C: "+imCellsAction[1];
  if (iNumActions > 2)
  	sTextStateBar += "  P: "+imCellsAction[2];
  if (iNumActions > 3)
  	sTextStateBar += "  T: "+imCellsAction[3];
  sTextStateBar += "   Cells: "+iTotNumCells +"   N: "+iTotPosMatrix +"   Links: " + (iTotNumLinks / 2) ;
}		// from vRunLoop()






/**
  * This method updates the income of a cell playing with one of its neighbors.
	*
	*	@param oCell	This is the cell to calculate the payoff
  */
private void vCalcPayoffs (Cell oCell) {
  int iCellAction = oCell.iGetAction();
  int iMateAction=0;
  double dValueProp, dx, dValueIntr;
  Cell oMate;
  Vector ovNeighbors = oCell.oVGetNeighbors();
  
  //oCell.vCheckNewResource();												// Every cell determines in each round if it is a proprietary or not
  
  for (int i=0; i<ovNeighbors.size(); i++) {
  	
  	oCell.vCheckNewResource();												// Every cell determines in each round if it is a proprietary or not
  	
	  oMate = (Cell) ovNeighbors.elementAt (i);
	  iMateAction = oMate.iGetAction();
	  
	//----------------------------- INI: HAWKDOVEPOSTRADE  --------------------------------------

	  if (iGameType == iHAWK_DOVE_POSS_TRADER) {	
	    if ( oCell.bOwnsResource() && (iCellAction == iTRADE) && (iMateAction == iTRADE) ) {// Both are Traders and the cell must have properties to sell
	      dValueProp = dMinPropVal + (dMaxPropVal - dMinPropVal) * Math.random();
	      dValueIntr = dMinPropVal + (dMaxPropVal - dMinPropVal) * Math.random();
	
	      if (dValueIntr > dValueProp) {                                          	// If this condition holds, then we have trading
	        dx = dValueProp + (dValueIntr - dValueProp) * Math.random();
	        if (dx > dPayMatrix[0][0][0]) {
		        oCell.vAddPayoffs (dx, dValueIntr - dx);                  							// The owner wins dx
		        oMate.vAddPayoffs (dValueIntr - dx, dx);                            		// The intruder wins the rest
		        continue;
	        }
	      }	      
	    }
	//----------------------------- END: HAWKDOVEPOSTRADE  --------------------------------------
	
	    if (iCellAction >= iPOSSESS) {
	      if (oCell.bOwnsResource())				// This cell owns resources
	        iCellAction = iHAWK;
	      else
	        iCellAction = iDOVE;
	      }
	
	    if (iMateAction >= iPOSSESS)
	      iMateAction = iDOVE;			// Neighbors are always intruders, never owners, so they cooperate
	  }
  
                   // We adjust payment for both, in the IPD games this means a double payment
	  oCell.vAddPayoffs (dPayMatrix[iCellAction][iMateAction][0], dPayMatrix[iMateAction][iCellAction][0]);
	  oMate.vAddPayoffs (dPayMatrix[iMateAction][iCellAction][0], dPayMatrix[iCellAction][iMateAction][0]);
  
  }					// for (int i=0; i<ovNeighbors.size(); i++) {

}







/**
  * This method updates the action taken by a cell in these games and has support for movement
  *		- Prissoner's Dilemma
  *		- HawkDovePossesorTrade
  *
  *	@param oCell  This is the cell that is going to change its action
  */
private void vChangeAction (Cell oCell) {
  int iActionBestNeighbor = iNULL, iActionWorstNeighbor = iNULL;
  int iNumNeighbors = 0;
  double dPayoffAux, dNumOtros = 2.0, dMediaAux = 0;
  double dCellPayoff = oCell.dGetAvgPayoff();
  //double dCellPayoff = oCell.dGetAvgPayoffBuffer();	// OJO
  double dPayoffBestNeighbor = -Double.MAX_VALUE;                         // Initialize the best neighbor
  double dPayoffWorstNeighbor = Double.MAX_VALUE;                         // Initialize the worst neighbor
  Cell oNeighbor;
  Vector<Cell> ovNeighbors = oCell.oVGetNeighbors();

  if (ovNeighbors.size() == 0) return;
  
  
  for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (Cell) ovNeighbors.elementAt(i);
    dPayoffAux = oNeighbor.dGetAvgPayoff();
    //dPayoffAux = oNeighbor.dGetAvgPayoffBuffer();	// OJO

    if (dPayoffAux > dPayoffBestNeighbor) {
		  dNumOtros = 2.0;																	// This is the first doing this
		  dPayoffBestNeighbor = dPayoffAux;
		  iActionBestNeighbor = oNeighbor.iGetAction();
		}
		else if (dPayoffAux == dPayoffBestNeighbor)							// If it is equal the change is done at random
		  if (Math.random() < 1/dNumOtros) {
		    iActionBestNeighbor = oNeighbor.iGetAction();
		    dNumOtros += 1.0;																// The next has less probability
		  }
	
	  if (dPayoffAux < dPayoffWorstNeighbor) {
	    dPayoffWorstNeighbor = dPayoffAux;
	    iActionWorstNeighbor = oNeighbor.iGetAction();
	  }
	
	  dMediaAux += dPayoffAux;
  }	// del for i


  dMediaAux = dMediaAux / ((double) iNumNeighbors);		// Average income for the neighbors

  switch (iChangeType) {                     // If the neighbor has more payoff -> cells changes the action
    case iIMITATION:						if (bImitateBEST) {															// IF (Not the BEST) THEN Imitate the BEST;           	
    															if (dPayoffBestNeighbor > dCellPayoff)
    																oCell.vSetNewAction (iActionBestNeighbor);
    														}
    														else if (dPayoffWorstNeighbor >= dCellPayoff)		// ELSE IF (The Worst) THEN Imitate the BEST;
  																oCell.vSetNewAction (iActionBestNeighbor);
                                
    														break;
                                
                                                                
    case iLEARNING:    					oCell.vGenerateStats();					// Cell generates its statistics
														    if ( (iActionBestNeighbor != iNULL) && (dCellPayoff >= dPayoffBestNeighbor) )
														    	oCell.vGetNewActionSimpleAutomata (true);		// Learning Automata being the best action
														    else
														    	oCell.vGetNewActionSimpleAutomata (false);	// Learning Automata not being the best action
                                break;

  }

            // Mutation, action change
  if (Math.random() < dProbMut) oCell.vSetNewAction ((int) (iNumActions * Math.random()));
						  // We compute action changes
  if (oCell.iGetNewAction() != oCell.iGetAction()) iNumChanges++;
  }







/**
  * This method rewires cells to avoid defectors
  * 
  *	@param oCell  It is the cell that will rewire
  */
protected void vRewire (Cell oCell) {
	Cell oNeighbor, oMateMate, oCellJoin=null, oCellRemove=null;
  Vector<Cell> ovMatesMate, ovNeighbors = oCell.oVGetNeighbors();
  
  //if (oCell.iGetAction() == iHAWK) return;											// Hawks are not accepted to join, so they don't rewire
  if (oCell.iGetAction() != iTRADE) return;												// Only traders rewire
  
  int iSize = ovNeighbors.size();
  if ( (iSize==0) || (iSize == iTotNumCells-1) ) return;          // If it has no neighbors or all are neighbors, then exiting
  
  for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (Cell) ovNeighbors.elementAt(i);
    if ( (oNeighbor.iGetAction() == iHAWK) && (oNeighbor.oVGetNeighbors().size() > 1) ) {					// We remove hawks (the 1st we find with 2 or more links)
    	oCellRemove=oNeighbor;
    	break;
    }
  }
  
  if (oCellRemove == null) return;			     					// If there is no defector or I am its unique neighbor then we cannot remove it


  if (Math.random() <= dProbRewireRandom) do {
	  int iAux = (int) (Math.random() * (double) iTotNumCells);           	// Rewires at random
	  oCellJoin = (Cell) oVectorCells.elementAt (iAux);
	} while ( (oCellJoin == oCell) || oCell.bIsNeighbor (oCellJoin) );

  else for (int i=0; i<ovNeighbors.size(); i++) {													// Rewires to a trader (neighbor of a neighbor)
    oNeighbor = (Cell) ovNeighbors.elementAt(i);
    ovMatesMate = oNeighbor.oVGetNeighbors();
    for (int j=0; j<ovMatesMate.size(); j++) {
    	oMateMate = (Cell) ovMatesMate.elementAt(j);
    	if ( (oMateMate.iGetAction() == iTRADE) && (oMateMate != oCell) || (!oCell.bIsNeighbor (oMateMate)) ) {
    		oCellJoin = oMateMate;
    		break;
    	}
    }
  }
  
  if (oCellJoin == null) return;
  
	ovNeighbors.add (oCellJoin);                                          	// Adding that neighbor
	ovMatesMate = oCellJoin.oVGetNeighbors();
  ovMatesMate.add (oCell);                                                 // Adding myself to the neighbor
  ovNeighbors.remove (oCellRemove);                                    		// Removing the worst
  ovMatesMate = oCellRemove.oVGetNeighbors();
  ovMatesMate.remove (oCell);                                              // The worst removes me
  
  iNumChanges++;
	}


}	// from the class


