package games.coaReputation;

import javax.swing.*;

import window.JPanelMainWindow;
import window.MainWindow;

import java.awt.*;
import java.awt.event.*;

import games.*;



/**
* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class DlgParamRep extends JDialog implements ActionListener, GameCons
{
private Label oLabel;
private JTextField  oTdDonate,
                    oTdCost,
                    oTdAvgInterxCell,
                    oTdKNoise,
                    oTdProb_D;
private Choice oChbCoalitions, oChbUseNowaksW;
private MainWindow oMainWindow;



/**
 * This is the Dialog constructor
 *
 * @param	oPadre 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 */
public DlgParamRep (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);

  oMainWindow = (MainWindow) oParent;
  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(8,2));

  oLabel = new Label (" Use Coalitions:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oChbCoalitions = new Choice();
  oChbCoalitions.add ("no");
  oChbCoalitions.add ("yes");
  if (Game.bCoalitions)
	oChbCoalitions.select ("yes");
  add (oChbCoalitions);
  
  oLabel = new Label (" Use (Action vs. Rewire):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oChbUseNowaksW = new Choice();
  oChbUseNowaksW.add ("no");
  oChbUseNowaksW.add ("yes");
  if (Game.bUseNowaksW)
	  oChbUseNowaksW.select ("yes");
  add (oChbUseNowaksW);

  
  oLabel = new Label (" Donation (b):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdDonate = new JTextField(String.valueOf(GameCoaReputation.dDonate), 7);
  add (oTdDonate);

  oLabel = new Label (" Cost (c):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdCost = new JTextField(String.valueOf(GameCoaReputation.dCost), 7);
  add (oTdCost);

  oLabel = new Label (" Times a cell behaves as Donor (Avg.):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdAvgInterxCell = new JTextField(String.valueOf(Game.dAvgInterxCell), 7);
  add (oTdAvgInterxCell);

  oLabel = new Label (" Noise Probability [0,1]:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdKNoise = new JTextField(String.valueOf(GameCoaReputation.dProbNoise), 7);
  add (oTdKNoise);

  oLabel = new Label (" Prob. of Pure defector [0,1]:", Label.LEFT);
  oLabel.setForeground (Color.red);
  add (oLabel);
  oTdProb_D = new JTextField(String.valueOf(GameCoaReputation.dProbDefector), 7);
  add (oTdProb_D);

  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(500,450));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {

		if ("yes".equals (oChbCoalitions.getSelectedItem())) {
		  Game.bCoalitions = true;
		  Game.iVisorShow = 0;							// Showing the cells & coalitions
		  JPanelMainWindow.vActivateButtons();
		}
		else {
		  Game.bCoalitions = false;
		  Game.iVisorShow = 3;							// Showing the strats
		  JPanelMainWindow.vActivateButtons();
		}
		
		if ("yes".equals (oChbUseNowaksW.getSelectedItem()))
		  Game.bUseNowaksW = true;
		else
		  Game.bUseNowaksW = false;
		  
    GameCoaReputation.dDonate = Double.parseDouble (oTdDonate.getText());
    GameCoaReputation.dCost = Double.parseDouble (oTdCost.getText());
    Game.dAvgInterxCell = Double.parseDouble (oTdAvgInterxCell.getText());
    GameCoaReputation.dProbNoise = Double.parseDouble (oTdKNoise.getText());
    GameCoaReputation.dProbDefector = Double.parseDouble (oTdProb_D.getText());
  }

  dispose();
}

}	// from the class
