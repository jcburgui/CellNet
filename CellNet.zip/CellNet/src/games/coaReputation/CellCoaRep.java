package games.coaReputation;

import games.CellCoa;
import games.Game;
import games.coaMetaNorms.GameCoaMetaNorms;

import java.text.DecimalFormat;
import java.util.Random;
import java.util.Vector;

import problems.Function;


public class CellCoaRep extends CellCoa
{
protected CellCoaRep oLeaderRep;        	  	  // if Leader or independent --> null, with Leader --> ref. to Cell
protected int iStrat = 0;                         // Strategy K in [-5, +6]: -5 is a C, while +6 are D
protected int iNewStrat = 0;                      // Stragegy K in [-5, +6]: -5 is a C, while +6 are D
protected int iScore = 0;                         // Reputation (Score) S in [-5, +5]
protected double dScoreLider=0;

protected int[] iNumTimesMetaStrat  = new int [Game.iMaxStrategies];  		// Number of times a MetaStrat has been selected
protected double[] dPayoffMetaStrat = new double [Game.iMaxStrategies];  	// Incomes obtained by this MetaStrat
protected double[] dProbMetaStrat = new double [Game.iMaxStrategies]; 	 	// Prob. of choosing a MetaStrat
protected Vector<Vector<?>> oVBufStatxMetaStrat = new Vector<Vector<?>> (1,1);        	// Store incomes per Strat type


//#################### These values are used by the Meta-norms games ##################
protected boolean bDefectSeen;		// Tells if this cell has seen a defection or not
protected boolean bOtherPunished;	// Tells if this cell has punished or not
protected double dB;				// Boldness (B) probability
protected double dV;				// Vengefulness (V) probability
private double dNewB;				// New value for dB to update synchronously
private double dNewV;				// New value for dV to update synchronously
//#################### These values are used by the Meta-norms games ##################



public CellCoaRep (int x, int y, int iCellTypeAux, int iActionAux) {
  super (x, y, iCellTypeAux, iActionAux);

  oLeaderRep = null;            // Initially cells have no leader
  iStrat = iActionAux - (Game.iNumActions/2 - 1);		// We want the graphic with centered strategies
  dEpsilon = Game.depsGreedy;
  
  int iAux = (int) (8.0 * Math.random());
  dB = ((double) iAux) / 7.0;
  iAux = (int) (8.0 * Math.random());
  dV = ((double) iAux) / 7.0;
  
  if (Game.iChangeType == Game.iMETA_STRAT)
  	iStrategyType = (int) (Math.random() * (double) Game.iMaxStrategies);
  else if (Math.random() < GameCoaReputation.dProbDefector) {	// This fixes some percentage of pure defectors within the population
    iStrat = +6;
    iStrategyType = Game.iALL_D;
  }

  for (int i=0; i<(Game.iMaxStrategies); i++) {
		iNumTimesMetaStrat[i] = 0;
		dPayoffMetaStrat[i] = 0;
		dProbMetaStrat[i] = 1.0 / ((double) Game.iMaxStrategies);
		oVBufStatxMetaStrat.addElement (new Vector<Object>(1,1));
	}

}


//************************ INI: This part is specific for the Meta-norms games ******************************

public double dGetBoldness()
  {return dB;}

public double dGetVengefulness()
  {return dV;}

public void vSetDefectSeen (boolean bAux)
  {bDefectSeen = bAux;}

public boolean bGetDefectSeen ()
  {return bDefectSeen;}

public void vSetOtherPunished (boolean bAux)
  {bOtherPunished = bAux;}

public boolean bGetOtherPunished ()
  {return bOtherPunished;}

public void vSetNewBV (double dBoldness, double dVengefulness) {
  dNewB = dBoldness;
  dNewV = dVengefulness;
}
Random agentsValuesGenerator = new Random();
public void vGenNewRandomBV () {
  /*int iAux = (int) (8.0 * Math.random());
  dNewB = ((double) iAux) / 7.0;
  iAux = (int) (8.0 * Math.random());
  dNewV = ((double) iAux) / 7.0;*/
	//System.out.println("explore");
  dNewB=(double)agentsValuesGenerator.nextInt(8)/7.0;
  dNewV=(double)agentsValuesGenerator.nextInt(8)/7.0;
}

public void vUpdateBV() {
  dB=dNewB;
  dV=dNewV;
}

public void vSetAxelrodPayoffs (double dPayoffAux, double dPayoffNeighborsAux) {
  dPayoff += dPayoffAux;
  for (int i=0; i<ovNeighbors.size(); i++) {
	CellCoaRep oCell = (CellCoaRep) ovNeighbors.elementAt (i);
	oCell.vAddPayoffs (dPayoffNeighborsAux, 0);
  }
}


//############################## INI: This part was included by Samhar ##############################

double dMaxEC=0.0;
double dMaxMP=0.0;
double dMaxDS=0.0;
double dMinDS=0.0;
double dMaxVDifHistory=0.0;
double dMaxBHistory=0.0;
double dMinBHistory=0.0;
public double dDefectionScore=0.0;
public double dPunishingScore=0.0;
public double dNotPunishingScore=0.0;


public boolean dExplore () {
	Random explorationGenerator=new Random();
	if(explorationGenerator.nextDouble() < GameCoaMetaNorms.dExplorationRate)
	  return true;
	else
	  return false;
}


double dRoundTwoDecimals (double d) {
	DecimalFormat twoDForm = new DecimalFormat("#.####");
	return Double.valueOf(twoDForm.format(d));
}


public void vGenNewBVLearning () {
	double factorB=1.0/7.0;
	double factorV=1.0/7.0;
	double stepV=1.0/7.0;
	double stepB=1.0/7.0;
	boolean useHistory=true;
	boolean useDynamicChange=false;
	//if(!explore(GameCoaMetaNorms.dExplorationRate))
	//{	
	
		// updating boldness
	if (dDefectionScore > 0) {
		if (useDynamicChange) {						
			if (!useHistory)
				factorB = dDefectionScore/dMaxDS;
			else {
				if ((dMaxBHistory==0.0)||(dMaxBHistory<dDefectionScore))
					dMaxBHistory = Math.abs(dDefectionScore);

				factorB = Math.abs(dDefectionScore)/dMaxBHistory;
			}
			factorB = dRoundTwoDecimals(factorB*stepB);
		}
		
		if ((dNewB+factorB) > 1.0)
			dNewB = 1.0;
		else
			dNewB = dNewB + Math.abs (factorB);
	}
	
	else if(dDefectionScore < 0) {
		if (useDynamicChange) {
			if (!useHistory)
				factorB=Math.abs(dDefectionScore)/Math.abs(dMinDS);

			else {
				if ((dMinBHistory==0.0)||(dMinBHistory<Math.abs(dDefectionScore)))
					dMinBHistory=Math.abs(dDefectionScore);

				factorB=Math.abs(dDefectionScore)/dMinBHistory;
			}
			
			factorB=dRoundTwoDecimals(factorB*stepB);
		}
		
		if((dNewB-factorB)<0.0)
			dNewB=0.0;
		else
			dNewB=dNewB-Math.abs(factorB);
	}
	
	// updating vengefulness
	if ( Math.abs(dPunishingScore) < Math.abs(dNotPunishingScore) ) {
		if (useDynamicChange)
			{			
			double differV = Math.abs ( Math.abs(dPunishingScore) - Math.abs(dNotPunishingScore) );

			if (!useHistory)
				factorV = differV / dMaxMP;
			else {
				if( (dMaxVDifHistory==0.0) || (dMaxVDifHistory<differV))
					dMaxVDifHistory = differV;

				factorV = Math.abs(differV) / dMaxVDifHistory;
				
			}

			factorV = dRoundTwoDecimals(factorV*stepV); 
		}
		
		if( (dNewV + factorV) > 1.0)
			dNewV = 1.0;
		else
			dNewV = dNewV+Math.abs(factorV);
	}
	else if(Math.abs(dPunishingScore) > Math.abs(dNotPunishingScore)) {
		if(useDynamicChange) {
			double differV = Math.abs ( Math.abs(dPunishingScore) - Math.abs(dNotPunishingScore) );
			if (!useHistory)
				factorV = differV/dMaxEC;
			
			else {
				if ( (dMaxVDifHistory==0.0) || (dMaxVDifHistory<differV) )
					dMaxVDifHistory = differV;

				factorV = Math.abs(differV) / dMaxVDifHistory;
			}

			factorV=dRoundTwoDecimals(factorV*stepV);
		}					

		if ( (dNewV-factorV) < 0.0)
			dNewV = 0.0;
		else
			dNewV = dNewV-Math.abs(factorV);
	}

	//}
	//else
	//{
		//vGenNewRandomBV ();
	//}
	//System.out.println(dB+" B "+dNewB);
	//System.out.println(dV+" V "+dNewV);

}


//############################## END: This part was included by Samhar ##############################


// ************************ END: This part is specific for the Meta-norms games ******************************



public CellCoaRep oGetLeader ()
  {return oLeaderRep;}

    // This method is an extension of the previous one to return a pointer to itself if it is the leader
public CellCoaRep oRecGetLeader () {
  if (oVHolonParts.size() > 0)      // If it is the leader
    return this;
  else
    return oLeaderRep;
  }

public void vNewLeader (CellCoaRep oHolon)
  {oLeaderRep = oHolon;}

public void vNewHolonPart (CellCoaRep oHolonPart)
  {oVHolonParts.addElement(oHolonPart);}

public void vRemoveHolonPart (CellCoaRep oHolonPart) {
  for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoaRep oHolon = (CellCoaRep) oVHolonParts.elementAt(i);
    if (oHolon == oHolonPart) {
      oVHolonParts.removeElementAt (i);
      return;
      }
    }
  }

public void vAddPayoffs (double dBotin, double dBotinVec) {
  if ( (oLeaderRep == null) || (dBotin < 0) )
    dPayoff += dBotin;
  else {
    dPayoff += dBotin * (1 - oLeaderRep.dGetTax());
    oLeaderRep.vAddPayoffs (dBotin * oLeaderRep.dGetTax(), 0);
    }
  dPayoffNeighbors += dBotinVec;
  }

public boolean bChangeLeaderOK (CellCoaRep oLeaderOther, CellCoaRep oCellMax) {
  if (this == oLeaderOther)
     return false;
  else for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoaRep oHolon = (CellCoaRep) oVHolonParts.elementAt(i);
    if (oCellMax == oHolon)
      return false;
    }

  return true;
  }


public void vReset() {
  vResetPayoff();
  iScore = 0;             	// The reputation is restarted in every generation
  iNewStrat = iStrat;     	// To keep it, just in case we did not change it
  dNewB = dB;				// To keep it, just in case we did not change it
  dNewV = dV;				// To keep it, just in case we did not change it

  //########### Samhar's code ############
  dDefectionScore = 0.0;
  dPunishingScore = 0.0;
  dNotPunishingScore = 0.0;
}

public int iGetScore()
  {return iScore;}

public void vChangeScore (int iVar) {
  iScore += iVar;
  if (iScore < -5) iScore = -5;
  if (iScore > 5) iScore = 5;
}

public double dGetScoreLeader() {
  if (oVHolonParts.size() > 0)      	// If it is the leader
    return dScoreLider;
  else if (oLeaderRep != null)     	// If it has leader
    return oLeaderRep.dGetScoreLeader();
  else
    return -Double.MAX_VALUE;       	// Security line just in case it is independent
}



public void vCalculateScoreLeader (int x, int y) {
  int iTamHolon = 1 + oVHolonParts.size();
  double dSumScoreLider = iScore;
  CellCoaRep oCell;

  for (int i=0; i<oVHolonParts.size(); i++) {               // iDameTamHolon (includes also the leader)
    oCell = (CellCoaRep) oVHolonParts.elementAt (i);
    dSumScoreLider += (double) oCell.iGetScore ();
  }

  dScoreLider = Math.log ((double) iTamHolon) * dSumScoreLider / (double) iTamHolon;
  //dScoreLider = dSumScoreLider / (double) iTamHolon;
}


public CellCoaRep oGetBestProfitCoaCell () {
  double dProfitAux, dMaxProfit = -Double.MAX_VALUE;
  CellCoaRep oCell, oCellMax = null;
  
  for (int i=0; i<oVHolonParts.size(); i++) {               // iDameTamHolon (includes also the leader)
    oCell = (CellCoaRep) oVHolonParts.elementAt (i);
    dProfitAux = (double) oCell.dGetPayoff ();
    if (dProfitAux > dMaxProfit)
      oCellMax = oCell;
  }
  
  return oCellMax;
}

public int iGetStrat()
  {return iStrat;}

public void vSetNewStrat (int iAux)
  {iNewStrat = iAux;}

public int iGetNewStrat()
  {return iNewStrat;}

public void vUpdateStrat()
  {iStrat = iNewStrat;}



/**
 * This method uses Learning Automata (LA) to select a new action depending on the
 * past experiences. The algorithm works as: store, adjust and generate.
 */
public void vGetNewStratStats () {
  vGetNewActionStats();
  iNewStrat = iNewAction - (Game.iNumActions/2-1);
  iAction = iNewAction;					// This is necessary for LA to work correctly
  }

/**
 * This method uses Learning Automata (LA) to select a new action depending on the
 * past experiences. The algorithm works as: store, adjust and generate.
 */
public void vGenNewStratAutomata () {
  vGetNewActionAutomata();
  iNewStrat = iNewAction - (Game.iNumActions/2-1);
  iAction = iNewAction;					// This is necessary for LA to work correctly
  }



/**
 * This method uses Learning Automata (LA) to select a new action depending on the
 * past experiences. The algorithm works as: store, adjust and generate.
 */
public void vGenNewMetaStratAutomata () {
	int iBest=-1, iNumBest=1;
	double dAux;
	double[] dAvgPayoffMetaStrat = new double [Game.iMaxStrategies];

                 // Check that all MetaStrats have been already tried
	if (!bAllActions) {
	  bAllActions = true;
	  for (int i=0; i<Game.iMaxStrategies; i++)
		if (iNumTimesMetaStrat[i] == 0) {
		  bAllActions = false;
		  break;
		}
	}
	
	else {   // If all MetaStrats have been tried, adjust the probabilities of the automata
      for (int i=0; i<Game.iMaxStrategies; i++)						// Determine the average benefits    
		dAvgPayoffMetaStrat[i] = dPayoffMetaStrat[i] / iNumTimesMetaStrat[i];

		dAux = -Double.MAX_VALUE;
		for (int i=0; i<Game.iMaxStrategies; i++)
		  if (dAux < dAvgPayoffMetaStrat[i]) {
			iBest = i;
			iNumBest=1;
			dAux = dAvgPayoffMetaStrat[i];
		  }
		  else if (dAux == dAvgPayoffMetaStrat[i]) {
		    iNumBest++;
		    if (Math.random() < 1.0 / (double) iNumBest) {				// Select randomly with reducing probabilities
	    	  iBest = i;
	    	  dAux = dAvgPayoffMetaStrat[i];
		    }
		  }

		
		
	if (dAvgPayoffMetaStrat[iStrategyType] == dAvgPayoffMetaStrat[iBest])	// If the action is among the best ones, it is reinforced
	  for (int i=0; i<Game.iMaxStrategies; i++)
		if (i == iStrategyType)
		  dProbMetaStrat[i] = dProbMetaStrat[i] + Game.dLearnRate * (1.0 - dProbMetaStrat[i]);	// Reinforce this
		else
		  dProbMetaStrat[i] = (1.0 - Game.dLearnRate) * dProbMetaStrat[i];						// The rest are weakened

	}
	

/*
  if ( (iBest > -1) && (Math.random() > dEpsilon) )	// Use e-greedy policy to select the best or randomly any from the others
	iNewMetaStrat = iBest;
  else do {
	iNewMetaStrat = (int) (Math.random() * (double) Game.iMaxStrategies);
  } while (iNewMetaStrat == iBest);
*/
  
  double dValAcc = 0;
  double dValRandom = Math.random();
  for (int i=0; i<Game.iMaxStrategies; i++) {
		dValAcc += dProbMetaStrat[i];
		if (dValRandom < dValAcc) {
		  iStrategyType = i;
		  break;
		}
  }
  
  dLearnRate *= Game.dDecFactor;		// Reducing the learning rate
  if (dLearnRate < Game.dMINLearnRate)
  	dLearnRate = Game.dMINLearnRate;
  
  dEpsilon *= Game.dDecFactor;			// Reducing the value of epsilon
  if (dEpsilon < Game.dMINepsGreedy)
  	dEpsilon = Game.dMINepsGreedy;		// Keeping a minimum value to allow exploration

}





/**
  * This method generate statistics for every cell.
  * It is called at the end of every generation and delays about 50% the simulation.
  */
public void vGenerateStats() {
  double dAux;
  Double oDouble;
  Vector<Double> oVect;

  super.vGenerateStats();

  iNumTimesMetaStrat  = new int [Game.iMaxStrategies];
  dPayoffMetaStrat = new double [Game.iMaxStrategies];		// Avg. of values with this MetaStrat
  for (int i=0; i<oVBufStatxMetaStrat.size(); i++) {
    oVect = (Vector<Double>) oVBufStatxMetaStrat.elementAt (i);
    iNumTimesMetaStrat[i] = oVect.size();
    for (int j=0; j<oVect.size(); j++) {
      oDouble = (Double) oVect.elementAt (j);
      dAux = (double) oDouble.doubleValue();
      dPayoffMetaStrat[i] += dAux;
      }
    }
  
  
  }





}	// from the class CellCoaRep


