package games.coaReputation;

import games.Cell;
import games.Game;

import java.util.Vector;
import java.util.Random;

import window.DlGraphics;
import window.MainWindow;
import window.WindowCons;


/**
 * This class implements the Nowak's reputation games with coalitions.
 *
 * @author  Juan C. Burguillo Rial
 * @version 1.0
 */
public class GameCoaReputation extends Game implements WindowCons {

protected int iAvgScore = 0;                   	// Average reputation
protected int iStoredScore=0;					// Accumulated reputation
//protected double dDistNoiseMax = 0.5 * Math.sqrt (iCellH*iCellH + iCellV*iCellV); // The maximum noise is generate by the far away cells in the toroidal world

// #################### These values are accessed from the windows ##################
public static CellCoaRep[][] oCellMatrix = new CellCoaRep [iCellH][iCellV];
public static int[] iMFrecScore = new int [11];   // Reputation in 11 intervals [-5, +5]
public static int[] iMFrecStrat = new int [12];   // Strategies in 12 intervals [-5, +6]
	
public static double dDonate = 1;                 // Donation value (b in Nowak's article)
public static double dCost = 0.1;                 // Cost value (c in Nowak's article)
public static double dProbNoise = 0;              // Noise constant affecting the reputation
public static double dProbDefector = 0;           // Probability of having a pure defector (D)
// #################### These values are accessed from the windows ##################



/**
  * This is the class constructor
  *
  */
public GameCoaReputation () {
  super ();
  bMovement = false;
  iVisorShow = 3;               // By defect we show the Strats
  iNumActions = 12;							// These are the 12 possible strategies, but simulate actions for simplifying graphs
  iNumTypes = 3;								// 3 options: Independent (IC), Coalition (CC) or Leader (LC)
  iMaxStrategies = 4;						// Number of MetaStrats for the games. From iIMITATION to INF
  dProbMut = 0.0;								// Mutation probability (changes the strat)
  iTotPosMatrix = 1600;					// Initial number of cells in the matrix
}

	
/**
  * This is the class constructor
  *
  */
public GameCoaReputation (MainWindow oVentAux) {  
  this();

  oMainWindow = oVentAux;
}



/**
  * This method sets up the games when "New" is pressed
	*
  */
public void vNewGame() {
  super.vNewGame();

  int iCellType = 0;
  int iStrat;
  
  Game.oCellMatrix = null;
  oCellMatrix = new CellCoaRep [iCellH][iCellV];

  ovAvgTaxCoaCell = new Vector (1,1);              	// Vector with the average tax per cell in a coalition
  
  dmProfitAction = new double [iNumActions];				// Reset
  imCellsAction = new int [iNumActions];						// Reset

  oVTextAction = new Vector (1,1);
  for (int i=0; i<iNumActions; i++)
  	oVTextAction.add (""+(i-(iNumActions/2-1)));
	  
  for (int x=0; x<iCellH; x++)                     	// Initializing the matrix of cells
    for (int y=0; y<iCellV; y++) {
      if (Math.random() < dProbEmpty) {
        oCellMatrix[x][y] = null;                  	// If there can be empty cells, setting up one with null
        continue;
      }

      iStrat = (int) ((double) iNumActions * Math.random());
      if (Math.random() < dProbDefector)
      	iStrat += 6;
      if (iStrat > (iNumActions-1)) iStrat = iNumActions - 1;
            
      oCellMatrix[x][y] = new CellCoaRep (x, y, iCellType, iStrat);
      imCellsType[0]++;								// Initially all are independent								
      imCellsAction[iStrat]++;
      iTotNumCells++;
    }
  
  Game.oCellMatrix = oCellMatrix;									// Setup the Game matrix for this games
  oVectorCells = ovCells2Vector (oCellMatrix);		// Creates a line vector to simplify random access
  
  switch (iNetType) {								// Selects the type of complex network to be created
    case 0:   vSetNeighborsSpatialRadio (oCellMatrix); break;
    case 1:   vSetNeighborsSmallWorld (oCellMatrix); break;
    case 2:   vSetNeighborsScaleFree (oCellMatrix); break;
    case 3:   vSetNeighborsRandomNetwork (oCellMatrix); break;
  }
  

  if ( (iNewGame == 0) && (MainWindow.iBatchMode < 2) ) {
	
    MainWindow.oMIWindow[iFREQxACTION].setEnabled (true);
    MainWindow.oMIWindow[iCHANGESxGEN].setEnabled (true);
    MainWindow.oMIWindow[iCELLSxSTRAT].setEnabled (true);
    MainWindow.oMIWindow[iFREQxTYPE].setEnabled (true);
    MainWindow.oMIWindow[iGLOBAL_PROFIT].setEnabled (true);
    MainWindow.oMIWindow[iPROFITxACTION].setEnabled (true);
    MainWindow.oMIWindow[iSTRATS_HISTOGRAM].setEnabled (true);
    MainWindow.oMIWindow[iSCORES_HISTOGRAM].setEnabled (true);
 
    if (MainWindow.iBatchMode == 0) {
      MainWindow.omDlGraf[iNODE_DEGREE_DIST] = new DlGraphics (oMainWindow, " CellNet: Node Degree Distribution", false, iNODE_DEGREE_DIST);
      MainWindow.omDlGraf[iNODE_DEGREE_DIST].setVisible(true);
      MainWindow.omDlGraf[iFREQxACTION] = new DlGraphics (oMainWindow, " CellNet: Frequency x Action", false, iFREQxACTION);
      MainWindow.omDlGraf[iFREQxACTION].setVisible(true);
      MainWindow.omDlGraf[iFREQxTYPE] = new DlGraphics (oMainWindow, " CellNet: Frequency x Type", false, iFREQxTYPE);
      MainWindow.omDlGraf[iFREQxTYPE].setVisible(true);
      MainWindow.omDlGraf[iSTRATS_HISTOGRAM] = new DlGraphics (oMainWindow, " CellNet: Strats Histogram", false, iSTRATS_HISTOGRAM);
      MainWindow.omDlGraf[iSTRATS_HISTOGRAM].setVisible(true);
      MainWindow.omDlGraf[iSCORES_HISTOGRAM] = new DlGraphics (oMainWindow, " CellNet: Scores Histogram", false, iSCORES_HISTOGRAM);
      MainWindow.omDlGraf[iSCORES_HISTOGRAM].setVisible(true);
    }
  }
  
  iNewGame++;
}




/**
  * This method contains the sequence of actions per cycle
  */
public void vRunLoop() {
  int iAux;
  double dProbChangeActvsRewire = 1 / (1 + dNumGen2ChangeAction/dNumGen2Rewire);
  Vector<Cell> oVectorCellsAux;

  iNumGen++;                                    // Increasing the number of generations (games iterations)
  iNumChanges = 0;
  
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)			                
    if (oCellMatrix[x][y] == null)
      continue;					                        // If the cell is empty jumps to next
    else
      oCellMatrix[x][y].vReset();               // Sets Payoff and Score to zero

  int iNumCelSelect = (int) (dAvgInterxCell * (double) iTotPosMatrix);
  for (int i=0; i<iNumCelSelect; i++) {					// Choosing iNumCelSelect cells randomly for playing
    int x = (int) (Math.random() * (double) iCellH);
    int y = (int) (Math.random() * (double) iCellV);
    if (oCellMatrix[x][y] == null)
      continue;
    else
      vCalcPayoffs (oCellMatrix[x][y]);			    // Calculates the payoff for the interacting cells
  }
  
  oVectorCellsAux = (Vector) oVectorCells.clone();  	
  while (oVectorCellsAux.size() > 0) {
    iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
    CellCoaRep oCell = (CellCoaRep) oVectorCellsAux.elementAt (iAux);
    oVectorCellsAux.removeElementAt(iAux);
    if (bUseNowaksW) {
      if (Math.random() < dProbChangeActvsRewire)
        vChangeStrat (oCell);                       	// Change strategies in a "non-sequential" way
      else
        vRewire (oCell);                            	// Change the neighbors of cells in a "non-sequential" way
    }
    else {
      vChangeStrat (oCell);
      if (Math.random() < dProbRewiring)
        vRewire (oCell);
    }
  }


//****************************** BEGIN: This is the code related with coalition formation ******************************

  if (bCoalitions) {
	for (int y=0; y<iCellV; y++)
	for (int x=0; x<iCellH; x++)                        // Updating the reputation for the leaders
	  if (oCellMatrix[x][y] == null)
	    continue;
	  else if (oCellMatrix[x][y].bIsLeader())   				// If it is a leader
	    oCellMatrix[x][y].vCalculateScoreLeader (x,y);  // Calculates the Score from every leader (coalition)
	
	oVectorCellsAux = (Vector) oVectorCells.clone();
	while (oVectorCellsAux.size() > 0) {				// Join/Change coalition or independence in a "non-sequential" way
	  iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
	  CellCoaRep oCell = (CellCoaRep) oVectorCellsAux.elementAt (iAux);
	  oVectorCellsAux.removeElementAt(iAux);
	  if (! oCell.bIsLeader())               			// If it is not a leader
	    vChangeCoa (oCell); 
	}
  }

//****************************** END: This is the code related with coalition formation ******************************


  
  vSetStatsGameCoaReputation();                	// Must be before updating Strats

  if (iNumGen >= iNGenIncubation) {
    for (int y=0; y<iCellV; y++)
    for (int x=0; x<iCellH; x++)
      if (oCellMatrix[x][y] == null)
        continue;
      else
        oCellMatrix[x][y].vUpdateStrat ();      // Updates synchronously the new strategies
  }


  if (MainWindow.iBatchMode < 2)
  	vSetGraphicValues();                         	// There are problems if it goes before updating Strats
  sTextStateBar = "NGen: "+iNumGen+"     Ind: "+imCellsType[0]+"  Coa: "+imCellsType[1]+" ("+imCellsType[2]+")"
             +"     Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
}		// from vRunLoop()






/**
  * Calculates the payoff for a cell in an interaction
  *
  *	@param x  oCell  Cell where we are playing
  */
protected void vCalcPayoffs (CellCoaRep oCell) {
  CellCoaRep oLeaderCell = oCell.oRecGetLeader();	// Leader of this cell
  CellCoaRep oOther;
  CellCoaRep oLeaderOpo=null;                		// Leader of neighbor's cell
  int iOther, iScoreOther;
  int iStrat = oCell.iGetStrat();
  boolean bEqualCoa = false, bIsNeighbor = false;
  Vector ovNeighbors = oCell.oVGetNeighbors();
  Random oRandom = new Random();

  do {
    iOther = (int) (Math.random() * (double) oVectorCells.size());
    oOther = (CellCoaRep) oVectorCells.elementAt(iOther);
  } while (oOther == oCell);

  if (ovNeighbors.size() > 0)
  	bIsNeighbor = oCell.bIsNeighbor (oOther);
  
  oLeaderOpo = oOther.oRecGetLeader();
  if ( (oLeaderCell == oLeaderOpo) && (oLeaderCell != null) )
    bEqualCoa = true;

  iScoreOther = oOther.iGetScore();
  if ( (!bEqualCoa) && (!bIsNeighbor) )			// If he is not in the same coa and not a neighbor, then the reputation is unknown
  	iScoreOther = 0;

  if (dProbNoise > 0) {
	  double dProbNoiseAux = dProbNoise;
	  if (bIsNeighbor)
	  	dProbNoiseAux *= 0.5;
	  if (bEqualCoa)
	  	dProbNoiseAux *= 0.75;
	  
	  if (Math.random() < dProbNoiseAux) {	
	  	iScoreOther = iScoreOther + (int) (5.0 * oRandom.nextGaussian());
		  if (iScoreOther < -5) iScoreOther = -5;
		  if (iScoreOther > 5) iScoreOther = 5;
	  }
  }

  
  if (iScoreOther >= iStrat) {
    oCell.vAddPayoffs (-dCost, dDonate);
    oOther.vAddPayoffs (dDonate, -dCost);
    oCell.vChangeScore (+1);                  // Reputation changes to +1
  }
  else
    oCell.vChangeScore (-1);                  // Reputation changes to -1
}




/**
  * Updates the coalition where this cell belongs. Leaders do not use this method.
  * 
  *	@param oCell  Cell to evaluate its coalition state or independence
  */
protected void vChangeCoa (CellCoaRep oCell) {
  CellCoaRep oLeaderCell = oCell.oGetLeader();
  CellCoaRep oNeighbor, oNeighborLeader;
  CellCoaRep oCellScoreMax = null, oLeaderCellScoreMax = null;
  boolean bCoaNear = false;
  double dPayoffAux, dScoreAux;
  double dPayoffMin = Double.MAX_VALUE;		// Worst payoff for neighbors
  double dScoreMax = -Double.MAX_VALUE;     // Initializing the best reputation
  double dPayoff = oCell.dGetPayoff();
  Vector ovNeighbors =  oCell.oVGetNeighbors();


  if (ovNeighbors.size() == 0) return;

          // Setting what is the minimum payoff, and who has the maximum payoff and reputation
  for (int i=0; i<ovNeighbors.size(); i++)  {
    oNeighbor = (CellCoaRep) ovNeighbors.elementAt(i);
    dPayoffAux = oNeighbor.dGetPayoff();

    if (dPayoffAux < dPayoffMin)
      dPayoffMin = dPayoffAux;

    oNeighborLeader = oNeighbor.oRecGetLeader();
    if ( (oLeaderCell != null) && (oLeaderCell == oNeighborLeader) )
      bCoaNear = true;

    dScoreAux = (double) oNeighbor.iGetScore();                    	// Neighbor's Reputation
    if (oNeighborLeader != null)
      dScoreAux = oNeighbor.dGetScoreLeader();                     	// Leader's Reputation

    if (dScoreAux > dScoreMax) {
      dScoreMax = dScoreAux;
      oCellScoreMax = oNeighbor;
      oLeaderCellScoreMax = oNeighborLeader;
      }

    }


  // *************************************** INI: Changing Coalition ************************************
	// If it is in a coalition that is not close to it --> independence
  if ( (oLeaderCell != null) && (!bCoaNear) ) {
    oLeaderCell.vRemoveHolonPart (oCell);
    oCell.vNewLeader (null);
  }

  else if (dPayoff <= dPayoffMin) {                 	// If it is the worst
	  if (oLeaderCell != null)													// If it has leader
	  	oLeaderCell.vRemoveHolonPart (oCell);        		// Leaving my former coalition
	
	  if (oLeaderCellScoreMax == null) {               	// If oCellScoreMax is not in a coalition
	    oCell.vNewLeader (oCellScoreMax);
	    oCellScoreMax.vNewHolonPart (oCell);
	  } else {
	    oCell.vNewLeader (oLeaderCellScoreMax);
	    oLeaderCellScoreMax.vNewHolonPart (oCell);
	  }
  }
// *************************************** END: Changing Coalition ************************************
}




/**
  * This method updates the Strat followed by this cell
  *
  *	@param oCell  It is the cell
  */
protected void vChangeStrat (CellCoaRep oCell) {
  Vector oVNeighbors = oCell.oVGetNeighbors();
  int iBestVecStrat = -Integer.MAX_VALUE;
  int iStratAux, iCellStrat = oCell.iGetStrat();
  int[] imPopStrat = new int[iMFrecStrat.length];
  double[] dmProfitStrat = new double[iMFrecStrat.length];
  double dMaxProfit = -Double.MAX_VALUE;
  double dProfitAux, dCellProfit = oCell.dGetPayoff();
  double dAux, dAuxTot, dTotalPayoffNeighbors;
  double[] dmProb = new double[iMFrecStrat.length];
  CellCoaRep oNeighbor;
  
//  if (oVNeighbors.size() == 0) return;


// *************************************** INI: Changing Strat ************************************
  
/*  oLeader = oCell.oRecGetLeader();						// This part is for sharing the Strats in the coalitions (not used in the paper)
  if (oLeader != null) {			// If it is in a coalition
		oNeighbor = oLeader.oGetBestProfitCoaCell();
    iStratAux = oNeighbor.iGetStrat();
		dProfitAux = oNeighbor.dGetPayoff();
		if (dProfitAux > dMaxProfit) {
	  	dMaxProfit = dProfitAux;
	  	iBestVecStrat = iStratAux;
		}
  }
*/
  
  dTotalPayoffNeighbors = 0;
  for (int i=0; i< oVNeighbors.size(); i++) {				// This part is for sharing the Strats in the neighborhoods
    oNeighbor = (CellCoaRep) oVNeighbors.elementAt(i);
    iStratAux = oNeighbor.iGetStrat();
    dProfitAux = oNeighbor.dGetPayoff();
    dTotalPayoffNeighbors += dProfitAux;
    imPopStrat [iStratAux + iNumActions/2 - 1]++;               		   // We add 5 because they start in -5
    dmProfitStrat [iStratAux + iNumActions/2 - 1] += dProfitAux;
    if (dProfitAux > dMaxProfit) {
      dMaxProfit = dProfitAux;
      iBestVecStrat = iStratAux;
    }
  }
  
  for (int i=0; i<dmProfitStrat.length; i++)				// We calculate the average for the strategies of dmProfitStrat
	if (imPopStrat[i] > 0)
	  dmProfitStrat[i] /= (double) imPopStrat[i];
  
  if (Game.iChangeType == Game.iMETA_STRAT)
  	oCell.vGenNewMetaStratAutomata();   			// Learning Automata for MetaStrats
  
  int iCellStrategy = oCell.iGetStrategyType();
  switch (iCellStrategy) {
  
    case iALL_D:
      oCell.vSetNewStrat (+6);						// This is the maximal defector strategy
      break;
      
    case iALL_C:
      oCell.vSetNewStrat (-5);						// This is the maximal cooperator strategy
      break;
          
    case iIMITATE_BEST_NEIGHTBOR:
      if ( (Math.random() > dProbImita) || (dCellProfit >= dMaxProfit) ) break;
      	oCell.vSetNewStrat (iBestVecStrat);
      break;

    case iIMITATE_BEST_STRAT:
      if ( (Math.random() > dProbImita) || (dCellProfit >= dMaxProfit) ) break;
      int iBestStrat = 0;
      double dMaxAux = dmProfitStrat[0];
      for (int i=1; i<dmProfitStrat.length; i++)
        if (dmProfitStrat[i] > dMaxAux) {
          dMaxAux = dmProfitStrat[i];
          iBestStrat = i - (iNumActions/2-1);                       // Subtracting to start in the lowest
        }
      oCell.vSetNewStrat (iBestStrat);           	// Imitates the strategy with the best results
      break;

    case iIMITATE_POP_STRAT:
      if ( (Math.random() > dProbImita) || (dCellProfit >= dMaxProfit) ) break;
      int iPopStrat = 0;
      int iMaxAux = imPopStrat[0];
      for (int i=1; i<dmProfitStrat.length; i++)
        if (imPopStrat[i] > iMaxAux) {
          iMaxAux = imPopStrat[i];
          iPopStrat = i - (iNumActions/2-1);                        // Subtracting to start in the lowest
        }
      oCell.vSetNewStrat (iPopStrat);            	// Imitates the most popular strategy
      break;

    case iIMITATE_PROB_BEST_NEIGHTBOR:
      if ( (Math.random() > dProbImita) || (dCellProfit >= dMaxProfit) ) break;
      int iAux;
      dAuxTot=0;
      Vector ovNeighborsAux = (Vector) oVNeighbors.clone();
      dAux = Math.random() * dTotalPayoffNeighbors;
      while (ovNeighborsAux.size() > 0) {
        iAux = (int) (Math.random () * (double) ovNeighborsAux.size());
        oNeighbor = (CellCoaRep) ovNeighborsAux.elementAt (iAux);
        dAuxTot += oNeighbor.dGetPayoff();        
        if (dAux < dAuxTot) {
          oCell.vSetNewStrat (oNeighbor.iGetStrat());    // Choosing this strategy
          break;
          }
        ovNeighborsAux.removeElementAt(iAux);
      }
      break;
      


    case iIMITATE_PROB_BEST_STRAT:
    case iIMITATE_PROB_POP_STRAT:
      if ( (Math.random() > dProbImita) || (dCellProfit >= dMaxProfit) ) break;
      dAuxTot = 0;
      if (iCellStrategy == iIMITATE_PROB_BEST_STRAT)
        for (int i=0; i<dmProfitStrat.length;i++) {
          dmProb[i] = dmProfitStrat[i];
          dAuxTot += dmProb[i];
        }
      else if (iCellStrategy == iIMITATE_PROB_POP_STRAT)
        for (int i=0; i<imPopStrat.length;i++) {
          dmProb[i] = (double) imPopStrat[i];
          dAuxTot += dmProb[i];
        }

      for (int i=0; i<dmProb.length; i++)   		// Normalizing probabilities
        dmProb[i] = dmProb[i] / dAuxTot;

      dAuxTot = dmProb[0];
      dAux = Math.random();
      for (int i=0; i<dmProb.length-1; i++) {
        if (dAux < dAuxTot) {
          oCell.vSetNewStrat (i - (iNumActions/2-1));    			// Choosing this Strat
          break;
          }
        dAuxTot += dmProb[i+1];
        }
      break;
      
      
      			// Non imitation models
      
    case iRANDOM:
    case iPREDICTION:				// In this games this works as random
      iStratAux = -(iNumActions/2-1) + (int) ((double) iNumActions * Math.random());		// Random values in [-5, +6]
      oCell.vSetNewStrat (iStratAux);
      break;
      
   case iINFECTION:        					// If this cell is the best, infects independent neighbors with dProbInf probability
     if (dCellProfit > dMaxProfit)
       for (int i=0; i<oVNeighbors.size(); i++) {
         oNeighbor = (CellCoaRep) oVNeighbors.elementAt(i);
//         if (oNeighbor.oRecGetLeader() == null)           // It is not in coalition
           if (Math.random() < dProbInf)
             oNeighbor.vSetNewStrat (iCellStrat);
       }
     break;
     
   case iSTATISTICS:
  	 oCell.vGenerateStats();                		// Cell generates its own statistics
     oCell.vGetNewStratStats();
     break;
     
   case iLEARNING:
  	 oCell.vGenerateStats();                		// Cell generates its own statistics
     oCell.vGenNewStratAutomata();            	// Learning Automata
     break;
      
  }


            // If there is mutation -> new strategy [-5, +6]
  if (Math.random() < dProbMut)
    oCell.vSetNewStrat (-(iNumActions/2-1) + (int) ((double) iNumActions * Math.random()));  
  
            // If it changed the strategy
  if (oCell.iGetNewStrat() != oCell.iGetStrat())
    iNumChanges++;
  
// *************************************** END: Changing Strat ************************************
}






/**
  * This method rewires cells depending on the neighborhood reputation
  * 
  *	@param oCell  It is the cell that will rewire
  */
protected void vRewire (CellCoaRep oCell) {
  int iAux, iSize, iScoreMin=6, iScoreMax=-1;
  double dAvgScore = 0;
  CellCoaRep oNeighbor, oMateMate, oMateScoreMin=null, oMateScoreMax=null;
  Vector ovMatesMate, ovNeighbors = oCell.oVGetNeighbors();
  
  iSize = ovNeighbors.size();
  if ( (iSize==0) || (iSize == iTotNumCells-1) ) return;                  // If it has no neighbors or all are neighbors, then exiting
  
  for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (CellCoaRep) ovNeighbors.elementAt(i);
    iAux = oNeighbor.iGetScore();
    dAvgScore += (double) iAux + 5.0;								 											// Adding 5 to Score to have positive values [0, 10] 
    if (iAux < iScoreMin) {
      iScoreMin = iAux;
      oMateScoreMin = oNeighbor;
    }
    ovMatesMate = oNeighbor.oVGetNeighbors();
    for (int j=0; j<ovMatesMate.size(); j++) {
      oMateMate = (CellCoaRep) ovMatesMate.elementAt (j);
      iAux = oMateMate.iGetScore();
      if (iAux > iScoreMax) {
        if ( (oMateMate == oCell) || oCell.bIsNeighbor (oMateMate) )        	// We do not consider it if it is the Cell or a neighbor
          continue;
        iScoreMax = iAux;
        oMateScoreMax = oMateMate;
      }
    }
  }
  
  dAvgScore /= (double) ovNeighbors.size();
  
  if (oMateScoreMin.oVGetNeighbors().size() == 1) return;			     					// If I am his unique neighbor, we can not remove it
   
  if (Math.random() < (10.0 - dAvgScore) / 10.0) {						 							// if 10 --> dProbRewire = 0;  if 0 --> dProbRewire = 1;
  	if ( (oMateScoreMax != null) && (Math.random() > dProbRewireRandom) ) 		// With probability (1-dProbRewireRandom) choose the best neighbor to rewire
  	  oNeighbor = oMateScoreMax;
  	else do {
  	  iAux = (int) (Math.random() * (double) iTotNumCells);               	// Otherwise rewires at random
  	  oNeighbor = (CellCoaRep) oVectorCells.elementAt (iAux);
  	} while ( (oNeighbor == oCell) || oCell.bIsNeighbor (oNeighbor) );    
	  
  	ovNeighbors.add (oNeighbor);                                            // Adding that neighbor
	  ovMatesMate = oNeighbor.oVGetNeighbors();
	  ovMatesMate.add (oCell);                                                // Adding myself to the neighbor
	  ovNeighbors.remove (oMateScoreMin);                                    	// Removing the worst
	  ovMatesMate = oMateScoreMin.oVGetNeighbors();
	  ovMatesMate.remove (oCell);                                             // The worst removes me
	}
  
}




/**
  * This method updates the statistics of the games and cells
  */
protected void vSetStatsGameCoaReputation() {
  int iStrat;
  double dPayoffCell;

  dGlobalProfit = 0;
  dMaxIncome = 0;
  dMinIncome = Double.MAX_VALUE;
  
  dmProfitAction = new double [iNumActions];		// Reset
  imCellsAction = new int [iNumActions];			// Reset
  imCellsType = new int [iNumTypes];
  
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
      continue;
    else {
      dPayoffCell = oCellMatrix[x][y].dGetPayoff();
      if (oCellMatrix[x][y].iGetHolonSize() > 1) {                	// If it is a leader
        dmProfitType[2] += dPayoffCell;								// Payoff LC: type 2
        imCellsType[2]++;
      } 
      else if (oCellMatrix[x][y].oGetLeader() != null) {				// If it has a leader
        dmProfitType[1] += dPayoffCell;								// Payoff CC: type 1
        imCellsType[1]++;
      }
      else {															// It is not in a coalition --> independent
        dmProfitType[0] += dPayoffCell;								// Payoff IC: type 0
        imCellsType[0]++;										
      }
    
	    iStrat = oCellMatrix[x][y].iGetStrat() + iNumActions/2 - 1;
	    dmProfitAction[iStrat] += dPayoffCell;
	    imCellsAction[iStrat]++;
	    
	    dGlobalProfit += dPayoffCell;
	    if (dMaxIncome < dPayoffCell) dMaxIncome = dPayoffCell;
	    if (dMinIncome > dPayoffCell) dMinIncome = dPayoffCell;
	
	    iStoredScore += oCellMatrix[x][y].iGetScore();
	    
		  iNumCellStrat [oCellMatrix[x][y].iGetStrategyType()]++;
	  }

  iAvgScore = iStoredScore / iTotNumCells;
  iStoredScore = 0;                                          // Reset
}


/**
  * This method updates the graphical values
  */
protected void vSetGraphicValues() {
  int iAux, iNumTax=0;
  double dAux, dMediaTax=0;
  CellCoaRep oCell;
  Vector oVectAux;

  super.vSetGraphicValues();
  
  if (Game.iChangeType == Game.iMETA_STRAT) {
    iAux=0;
		for (int i=0; i<Game.iMaxStrategies; i++)
		  iAux += iNumCellStrat[i];
		
		if (iAux > 0) for (int i=0; i<Game.iMaxStrategies; i++) {
		  oVectAux = (Vector) oVCellsxStrat.elementAt(i);
		  oVectAux.add (new Integer (100 * iNumCellStrat[i] / iAux));
		  while (oVectAux.size() > MainWindow.iLastNGen)
		    oVectAux.removeElementAt (0);
		}
  }

  iMFrecTax = new int [10];
  iMFrecScore = new int [iMFrecScore.length];
  iMFrecStrat = new int [iMFrecStrat.length];
  for (int y=0; y<iCellV; y++)
    for (int x=0; x<iCellH; x++)
      if (oCellMatrix[x][y] == null)
        continue;                                 // If it is an empty cell goes to next
      else {
        oCell = oCellMatrix[x][y];
        iAux = oCell.iGetScore();
        iMFrecScore [iAux+5]++;
        iAux = oCell.iGetStrat();
        iMFrecStrat [iAux+5]++;

        if (oCell.iGetHolonSize () > 1) {         // If it is a leader
          dAux = oCell.dGetTax();
          iAux = (int) Math.floor(dAux*10);
          iMFrecTax [iAux]++;
          }
        else if (oCell.oGetLeader() != null) {    // If it is the member of a coalition
          dMediaTax += oCell.oGetLeader().dGetTax();
          iNumTax++;
          }
        }

  dMediaTax = dMediaTax / iNumTax;
  ovAvgTaxCoaCell.add (new Integer ((int) (100.0 * dMediaTax)));
  while (ovAvgTaxCoaCell.size() > MainWindow.iLastNGen)
  	ovAvgTaxCoaCell.removeElementAt (0);
 
  for (int i=0; i<iNumTypes; i++) {
		oVectAux = (Vector) oVProfitType.elementAt(i);
		if (imCellsType[i] > 0)
		  oVectAux.add (new Double (dmProfitType[i] /= (double) imCellsType[i]));
		else
		  oVectAux.add (new Double (0));
		
		while (oVectAux.size() > MainWindow.iLastNGen)
		  oVectAux.removeElementAt (0);
  }
}




}	// from class GameCoaReputation

