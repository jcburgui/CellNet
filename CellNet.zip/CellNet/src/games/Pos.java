package games;

/**
	* Esta clase se usa para meter en un Vector posiciones de la matriz.
	*
	* @author  Juan C. Burguillo Rial
	* @version 1.0
	*/
public class Pos
{
public int x;
public int y;

public Pos (int xAux, int yAux)
	{
	x = xAux;
	y = yAux;
	}
}

