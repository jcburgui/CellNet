package games.coaMetaNorms;

import games.coaReputation.CellCoaRep;
import games.coaReputation.GameCoaReputation;

import java.util.Vector;

import window.DlGraphics;
import window.MainWindow;
import window.WindowCons;


/**
 * This class implements the Meta-Norms games with coalitions.
 *
 * @author  Juan C. Burguillo Rial
 * @version 1.0
 */
public class GameCoaMetaNorms extends GameCoaReputation implements WindowCons {

	//#################### These values are accessed from the windows ##################
public static Vector ovAvgBV = new Vector (1,1);              	// Avg. values for B and V per generation
public static double dExplorationRate = 0.01;										// Samhar's code
	//#################### These values are accessed from the windows ##################



/**
  * This is the class constructor
  *
  */
public GameCoaMetaNorms () {
  super ();
  bMovement = false;
  iVisorShow = 3;                           // By defect we show the Strats
  iNumActions = 2;             							// These are the 12 possible strategies, but simulate actions for simplifying graphs
  iMaxStrategies = 1;
  iTotPosMatrix = 1600;											// Initial number of cells in the matrix
}

  
/**
  * This is the class constructor
  *
  */
public GameCoaMetaNorms (MainWindow oVentAux) {  
  this();

  oMainWindow = oVentAux;
  
}



/**
 * This method sets up the games when "New" is pressed
	*
 */
public void vNewGame() {
  super.vNewGame();

  ovAvgBV = new Vector (1,1);
  ovAvgBV.add (new Vector (1,1));
  ovAvgBV.add (new Vector (1,1));
  

  if ( (iNewGame <= 1) && (MainWindow.iBatchMode < 2) ) {	// Note that super.vNewGame() increases iNewGame by one each time and is called above
    
    MainWindow.oMIWindow[iDYNAMIC_BV].setEnabled (true);
    MainWindow.oMIWindow[iSTATIC_BV].setEnabled (true);
     
    if (MainWindow.iBatchMode == 0) {
      MainWindow.omDlGraf[iDYNAMIC_BV] = new DlGraphics (oMainWindow, " CellNet: B & V Evolution", false, iDYNAMIC_BV);
      MainWindow.omDlGraf[iDYNAMIC_BV].setVisible(true);
      MainWindow.omDlGraf[iSTATIC_BV] = new DlGraphics (oMainWindow, " CellNet: B & V Map", false, iSTATIC_BV);
      MainWindow.omDlGraf[iSTATIC_BV].setVisible(true);
    }
  }
}



/**
  * This method contains the sequence of actions per cycle
  */
public void vRunLoop() {
  int iAux;
  double dProbChangeActvsRewire = 1 / (1 + dNumGen2ChangeAction/dNumGen2Rewire);
  Vector oVectorCellsAux;
  
  iNumGen++;                                    // Increasing the number of generations (games iterations)
  
  iNumChanges = 0;
  
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)			                
    if (oCellMatrix[x][y] == null)
      continue;					                        // If the cell is empty jumps to next
    else
      oCellMatrix[x][y].vReset();                  		// Sets Payoff and Score to zero

  
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)			                
    if (oCellMatrix[x][y] == null)
      continue;					                        			// If the cell is empty jumps to next
    else for (int i=0; i<4; i++)									// Four tries to defect
      vCalcPayoffs (oCellMatrix[x][y]);			                  	// Calculates the payoff and reputation with the interacting cells

  
//****************************** BEGIN: This is the code related with coalition formation ******************************

  if (bCoalitions) {
		for (int y=0; y<iCellV; y++)
		for (int x=0; x<iCellH; x++)                        // Updating the reputation for the leaders
		  if (oCellMatrix[x][y] == null)
		    continue;
		  else if (oCellMatrix[x][y].iGetHolonSize() > 1)   // If it is a leader
		    oCellMatrix[x][y].vCalculateScoreLeader (x,y);  // Calculates the Score from every leader (coalition)
		
		oVectorCellsAux = (Vector) oVectorCells.clone();
		while (oVectorCellsAux.size() > 0) {
		  iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
		  CellCoaRep oCell = (CellCoaRep) oVectorCellsAux.elementAt (iAux);
		  oVectorCellsAux.removeElementAt(iAux);
		  if (oCell.iGetHolonSize() == 1)               	// If it is not a leader
		    vChangeCoa (oCell);                       		// Change coalitions or independence in a "non-sequential" way 
		}
  }

//****************************** END: This is the code related with coalition formation ******************************

  oVectorCellsAux = (Vector) oVectorCells.clone();
  while (oVectorCellsAux.size() > 0) {
    iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
    CellCoaRep oCell = (CellCoaRep) oVectorCellsAux.elementAt (iAux);
    oVectorCellsAux.removeElementAt(iAux);
    if (bUseNowaksW) {
      if (Math.random() < dProbChangeActvsRewire)
        vChangeBV (oCell);                       		// Change strategies in a "non-sequential" way
      else
        vRewire (oCell);                            	// Change the neighbors of cells in a "non-sequential" way
    }
    else {
      vChangeBV (oCell);
      if (Math.random() < dProbRewiring)
        vRewire (oCell);
    }
  }


  vSetStatsGameCoaReputation();                		  	// Must be before updating Strats
  
  if (iNumGen >= iNGenIncubation) {
    for (int y=0; y<iCellV; y++)
    for (int x=0; x<iCellH; x++)
      if (oCellMatrix[x][y] == null)
        continue;
      else {
        oCellMatrix[x][y].vUpdateStrat ();      // Updates synchronously the new strats
        oCellMatrix[x][y].vUpdateBV ();      	// Updates synchronously the new B and V values
      }
  }



  if (MainWindow.iBatchMode < 2)
  	vSetGraphicValues();                         	// There are problems if it goes before updating Strats
  sTextStateBar = "NGen: "+iNumGen+"     Ind: "+imCellsType[0]+"  Coa: "+imCellsType[1]+" ("+imCellsType[2]+")"
             +"     Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
}		// from vRunLoop()




/**
  * Calculates the payoff for a cell in an interaction
  *
  *	@param oCell  Cell where we are playing
  */
protected void vCalcPayoffs (CellCoaRep oCell) {
  int iAux, iStrat, iChangeScore=0;
  double dSeen = Math.random();
  CellCoaRep oOtherSees, oOtherMetaSees;	// Leader of neighbor's cell
  Vector ovMatesMate, ovNeighbors = oCell.oVGetNeighbors();
  
  iStrat = iCOOPERATE;								// No payoff when cooperating
  if (oCell.dGetBoldness() > dSeen) {
	iStrat = iDEFECT;
	oCell.vSetAxelrodPayoffs (3, -1);				// +3 for him and -1 for all as payoff when defecting
	oCell.dDefectionScore+=3;						// Samhar's code
  }
  
  //===================== Punishment Section ------------------------------------
  for (int i=0; i<ovNeighbors.size(); i++) {			// All the neighbors check out (or not) the operation
	oOtherSees = (CellCoaRep) ovNeighbors.elementAt(i);
	oOtherSees.vSetDefectSeen(false);				// Reseting what they see and what they punish
	oOtherSees.vSetOtherPunished(false);
	if (Math.random() >= dSeen) continue;			// This one does not see nothing
	if (iStrat == iCOOPERATE) {						// If cooperating, sets a +1 in score for the cell
	  iChangeScore = 1;								// Cell reputation changes by +1
	  break;										// This is to check out somebody sees the cooperation and increases the score of the cell
	} else {	
	  oOtherSees.vSetDefectSeen(true);				// The neighbor sees the defection of the cell
	  if (Math.random() < oOtherSees.dGetVengefulness()) {
	    oOtherSees.vSetOtherPunished(true);			// The neighbor is going to punish the cell
	    oCell.vSetAxelrodPayoffs (-9, 0);			// Punishment for the cell
	    oCell.dDefectionScore-=9;					// Samhar's code
	    oOtherSees.vSetAxelrodPayoffs (-2, 0);		// Cost for the neighbor
	    oOtherSees.dPunishingScore-=2;				// Samhar's code
	    iChangeScore = -1;		                  	// The reputation of the cell (score) will change by -1
	  }
	}
  }
  
  //===================== Meta-punishment Section ------------------------------------
  if (iStrat == iDEFECT)							// If the cell cooperates, then meta-punishment has no sense
	for (int i=0; i<ovNeighbors.size(); i++) {
	  oOtherSees = (CellCoaRep) ovNeighbors.elementAt(i);
	  
	  		// If (this cell did not see the defection OR if it punished) then get next
	  if ( (!oOtherSees.bGetDefectSeen()) || (oOtherSees.bGetOtherPunished()) ) continue;
	  
	  ovMatesMate = oOtherSees.oVGetNeighbors();		// Second neighbors
	  
      for (int j=0; j<ovMatesMate.size(); j++) {
	    if (Math.random() >= dSeen) continue;		// If this cell does not see the avoided punishment goes to the next
	    oOtherMetaSees = (CellCoaRep) ovMatesMate.elementAt(j);
	    if (oOtherMetaSees == oCell) continue;		// If the second neighbor is the cell itself then get next
	    
	    if (Math.random() < oOtherMetaSees.dGetVengefulness()) {
	      oOtherSees.vSetAxelrodPayoffs (-9, 0);				// Punishment for the neighbor that did not punish
	      oOtherSees.dNotPunishingScore-=9;						// Samhar's code
   	  	  oOtherMetaSees.vSetAxelrodPayoffs (-2, 0);			// Cost of meta-punishment
   	      oOtherMetaSees.dPunishingScore-=2;						// Samhar's code
	    }
      }
	}
  
  oCell.vSetNewStrat (iStrat);									// Prepares the new Strat for synchronous change
  oCell.vChangeScore (iChangeScore);							// iChangeScore can be -1, 0, +1
}





/**
  * This method updates the Strat, i.e., a combination of B and V, followed by this cell
  *
  *	@param oCell  It is the cell
  */
protected void vChangeBV (final CellCoaRep oCell) {
  Vector ovNeighbors = oCell.oVGetNeighbors(), ovCoaMates = new Vector();
  double dMaxCoaPayoff = -Double.MAX_VALUE;
  double dMaxPayoff = -Double.MAX_VALUE;
  double dMinPayoff = Double.MAX_VALUE;
  double dAvgPayoff = 0;
  double dVar = 0, dStandardDeviation = 0;
  double dPayoffAux, dCellPayoff = oCell.dGetPayoff();
  CellCoaRep oNeighbor, oLeader, oCoaMate, oBestMate=null;

  for (int i=0; i< ovNeighbors.size(); i++) {				// This part is for sharing the Strats in the neighborhoods
    oNeighbor = (CellCoaRep) ovNeighbors.elementAt(i);
    dPayoffAux = oNeighbor.dGetPayoff();
    dAvgPayoff += dPayoffAux;
    if (dPayoffAux > dMaxPayoff)
      dMaxPayoff = dPayoffAux;
    else if (dPayoffAux < dMinPayoff)
      dMinPayoff = dPayoffAux;
  }
  
  dAvgPayoff /= ovNeighbors.size();
  
  for (int i=0; i< ovNeighbors.size(); i++) {				// This part is for sharing the Strats in the neighborhoods
    oNeighbor = (CellCoaRep) ovNeighbors.elementAt(i);
    dPayoffAux = oNeighbor.dGetPayoff();
    dVar += (dAvgPayoff - dPayoffAux) * (dAvgPayoff - dPayoffAux);
  }
  dVar /= ovNeighbors.size();
  dStandardDeviation = Math.sqrt (dVar);
  
  
  int iCellStrategy = oCell.iGetStrategyType();
  switch (iCellStrategy) {
          
    case iIMITATE_BEST_NEIGHTBOR:
    	
  	  //if ( (Math.random() > dProbImita) || (dCellPayoff >= dMaxPayoff) ) break;
  	  //if ( (Math.random() > dProbImita) || (dCellPayoff > dMinPayoff) ) break;
  	  if ( (Math.random() > dProbImita) || (dCellPayoff > dAvgPayoff) ) break;
    	
      oLeader = oCell.oRecGetLeader();
      if (oLeader != null) { 
		    ovCoaMates = (Vector) oLeader.oVGetHolonParts().clone();
		    ovCoaMates.add (oLeader);
		    
		    int iIndex = 0;
		    while (ovCoaMates.size() > iIndex) {							// We search for the best member of its coalition
			 	  oCoaMate = (CellCoaRep) ovCoaMates.elementAt (iIndex);
			 	  dPayoffAux = oCoaMate.dGetPayoff();
			 	  if ( (dPayoffAux < dAvgPayoff) || (oCoaMate == oCell) ) {
				 		ovCoaMates.remove (iIndex);
				 		continue;
			 	  }
			 	  
			 	  if (dPayoffAux > dMaxCoaPayoff) {
				    dMaxCoaPayoff = dPayoffAux;
				    oBestMate = oCoaMate;
			 	  }
			 	  
			 	  iIndex++;
		    }
      }
      
      if (ovCoaMates.size() > 0) {
        int iAux = (int) (Math.random() * (double) ovCoaMates.size());
        oCoaMate = (CellCoaRep) ovCoaMates.elementAt (iAux);  
        oCell.vSetNewBV (oCoaMate.dGetBoldness(), oCoaMate.dGetVengefulness());
      }
      else
    	//oCell.vGenNewRandomBV();
    	if ( !oCell.dExplore () ) {
        if (dCellPayoff <= (dAvgPayoff-dStandardDeviation))
        	oCell.vGenNewBVLearning();            	// Learning method done by Samhar codified in CellCoaRep.java
    	}
    	else
    	  oCell.vGenNewRandomBV ();
      
      break;
      
      			// Non imitation models
    case iRANDOM:
      oCell.vGenNewRandomBV();
      break;
      
    case iINFECTION:        					// If this cell is the best, infects independent neighbors with dProbInf probability
      if (dCellPayoff > dMaxPayoff)
        for (int i=0; i<ovNeighbors.size(); i++) {
          oNeighbor = (CellCoaRep) ovNeighbors.elementAt(i);
          if (Math.random() < dProbInf)
            oNeighbor.vSetNewBV (oCell.dGetBoldness(), oCell.dGetVengefulness());
        }
      break;
        
    case iLEARNING:
      oCell.vGenerateStats();                // Cell generates its own statistics
    	if ( !oCell.dExplore () ) {
    	  if (dCellPayoff <= (dAvgPayoff-dStandardDeviation))
    		oCell.vGenNewBVLearning();            	// Learning method done by Samhar codified in CellCoaRep.java
    	}
    	else
    	  oCell.vGenNewRandomBV ();      
  }

            // If there is mutation -> new strategy [-5, +6]
  if (Math.random() < dProbMut)
  	oCell.vGenNewRandomBV();
	 
            // If it changed the strategy
  if (oCell.iGetNewStrat() != oCell.iGetStrat())
    iNumChanges++;
 
}





/**
  * Updates the coalition where this cell belongs. Leaders do not use this method.
  * 
  *	@param oCell  Cell to evaluate its coalition state or independence
  */
protected void vChangeCoa (CellCoaRep oCell) {
  CellCoaRep oLeaderCell = oCell.oGetLeader();
  CellCoaRep oNeighbor, oNeighborLeader;
  CellCoaRep oCellScoreMax = null, oLeaderCellScoreMax = null;
  boolean bCoaNear = false;
  double dProbRebAux;                       // Probability for having a rebellion
  double dPayoffAux, dScoreAux;
  double dPayoffMin = Double.MAX_VALUE;		// Worst payoff for neighbors
  double dScoreMax = -Double.MAX_VALUE;     // Initializing the best reputation
  double dPayoff = oCell.dGetPayoff();
  Vector ovNeighbors = oCell.oVGetNeighbors();


  if (ovNeighbors.size() == 0) return;

          // Setting what is the minimum payoff, and who has the maximum payoff and reputation
  for (int i=0; i<ovNeighbors.size(); i++)  {
    oNeighbor = (CellCoaRep) ovNeighbors.elementAt(i);
    dPayoffAux = oNeighbor.dGetPayoff();

    if (dPayoffAux < dPayoffMin)
      dPayoffMin = dPayoffAux;

    oNeighborLeader = oNeighbor.oRecGetLeader();
    if ( (oLeaderCell != null) && (oLeaderCell == oNeighborLeader) )
      bCoaNear = true;

    dScoreAux = (double) oNeighbor.iGetScore();                    	// Neighbor's Reputation
    if (oNeighborLeader != null)
      dScoreAux = oNeighbor.dGetScoreLeader();                     	// Leader's Reputation

    if (dScoreAux > dScoreMax) {
      dScoreMax = dScoreAux;
      oCellScoreMax = oNeighbor;
      oLeaderCellScoreMax = oNeighborLeader;
      }

    }


  // *************************************** INI: Changing Coalition ************************************
	// If it is in a coalition that is not close to it --> independence
  if ( (oLeaderCell != null) && (!bCoaNear) ) {
    oLeaderCell.vRemoveHolonPart (oCell);
    oCell.vNewLeader (null);
    return;
  }

  if (dPayoff > dPayoffMin) return;                 // If it is better than the worst returns
  if (oLeaderCellScoreMax != null)					// We limit the size of a coalition in the first generations, to avoid over-exploiting
	if (oLeaderCellScoreMax.oVGetHolonParts().size() > (iNumGen/10)) return;
  
            // If it has leader
  if (oLeaderCell != null)
	oLeaderCell.vRemoveHolonPart (oCell);        	// Leaving my former coalition

  if (oLeaderCellScoreMax == null) {               	// If oCellScoreMax is not in a coalition
    oCell.vNewLeader (oCellScoreMax);
    oCellScoreMax.vNewHolonPart (oCell);
  } else {
    oCell.vNewLeader (oLeaderCellScoreMax);
    oLeaderCellScoreMax.vNewHolonPart (oCell);
  }
// *************************************** END: Changing Coalition ************************************
}





/**
  * This method rewires cells depending on the neighborhood reputation
  * 
  *	@param oCell  It is the cell that will rewire
  */
protected void vRewire (CellCoaRep oCell) {
  int iAux, iSize, iScoreMin=6, iScoreMax=-1;
  double dAvgScore = 0;
  CellCoaRep oNeighbor, oLeader, oCoaMate, oMateScoreMin=null, oMateScoreMax=null;
  Vector ovCoaMates, ovNeighbors = oCell.oVGetNeighbors();
  
  iSize = ovNeighbors.size();
  if ( (iSize==0) || (iSize == iTotNumCells) ) return;                      // If it has no neighbors or all are neighbors, then exiting
  
  for (int i=0; i<ovNeighbors.size(); i++) {							// We identify the worst neighbor
    oNeighbor = (CellCoaRep) ovNeighbors.elementAt(i);
    iAux = oNeighbor.iGetScore();
    dAvgScore += (double) iAux + 5.0;								 	// Adding 5 to Score to have positive values [0, 10] 
    if (iAux < iScoreMin) {
      iScoreMin = iAux;
      oMateScoreMin = oNeighbor;
    }
    if (iAux > iScoreMax) {
	  iScoreMax = iAux;
	  oMateScoreMax = oNeighbor;
    }
  }
  
  dAvgScore /= (double) ovNeighbors.size();
  
  oLeader = oCell.oRecGetLeader();
  if (oLeader != null) {
    ovCoaMates = oLeader.oVGetHolonParts();								// We search for the best member of its coalition
	for (int j=0; j<ovCoaMates.size(); j++) {
	  oCoaMate = (CellCoaRep) ovCoaMates.elementAt (j);
	  if ( (oCoaMate == oCell) || oCell.bIsNeighbor (oCoaMate) )        // We do not consider it if it is the Cell or a neighbor
		continue;
	  iAux = oCoaMate.iGetScore();
	  if (iAux > iScoreMax) {
		iScoreMax = iAux;
	    oMateScoreMax = oCoaMate;
	  }
	}
	
	if (oLeader != oCell) {												// If it is not a leader
	  iAux = oLeader.iGetScore();
	  if (iAux > iScoreMax) {
	    iScoreMax = iAux;
	    oMateScoreMax = oLeader;
	  }
	}
  }
  
  if (oMateScoreMin.oVGetNeighbors().size() == 1) return;			     						// If I am his unique neighbor, we can not remove it
   
  if (Math.random() < (10.0 - dAvgScore) / 10.0) {						 							 	// if 10 --> dProbRewire = 0;  if 0 --> dProbRewire = 1; 
  	if ( (oMateScoreMax != null) && (Math.random() > dProbRewireRandom) ) 		// With probability (1-dProbRewireRandom) choose the best neighbor to rewire
  	  oNeighbor = oMateScoreMax;
  	else do {
  	  iAux = (int) (Math.random() * (double) iTotNumCells);               	// Otherwise rewires at random
  	  oNeighbor = (CellCoaRep) oVectorCells.elementAt (iAux);
  	} while ( (oNeighbor == oCell) || oCell.bIsNeighbor (oNeighbor) );    
	  
  	ovNeighbors.add (oNeighbor);                                            // Adding that neighbor
  	ovCoaMates = oNeighbor.oVGetNeighbors();
	  ovCoaMates.add (oCell);                                                 // Adding myself to the neighbor
	  ovNeighbors.remove (oMateScoreMin);                                     // Removing the worst
	  ovCoaMates = oMateScoreMin.oVGetNeighbors();
	  ovCoaMates.remove (oCell);                                              // The worst removes me
  }

}




/**
  * This method updates the graphical values
  */
protected void vSetGraphicValues() {
  double dTotB, dTotV, dAvgB, dAvgV;
  Vector<Double> oVectAux;

  super.vSetGraphicValues();
  
  dTotB=0; dTotV=0;
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
	if (oCellMatrix[x][y] == null)
	  continue;                                 // If it is an empty cell goes to next
	else {
	  dTotB += oCellMatrix[x][y].dGetBoldness();
	  dTotV += oCellMatrix[x][y].dGetVengefulness();
	}
  
  dAvgB = dTotB / iTotPosMatrix;
  dAvgV = dTotV / iTotPosMatrix;
  
  
  oVectAux = (Vector<Double>) ovAvgBV.elementAt(0);
  oVectAux.add (new Double (dAvgB));
  while (oVectAux.size() > MainWindow.iLastNGen)
	oVectAux.removeElementAt (0);
  oVectAux = (Vector) ovAvgBV.elementAt(1);
  oVectAux.add (new Double (dAvgV));
  while (oVectAux.size() > MainWindow.iLastNGen)
	oVectAux.removeElementAt (0);
}



}	// from class GameCoaReputation

