package games.coaMetaNorms;

import javax.swing.*;

import window.JPanelMainWindow;
import window.MainWindow;

import java.awt.*;
import java.awt.event.*;

import games.*;
import games.coaReputation.GameCoaReputation;



/**
* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class DlgParamNorms extends JDialog implements ActionListener, GameCons
{
private Label oLabel;
private JTextField  oTdExplorationRate,
                    oTdKNoise;
private Choice oChbCoalitions, oChbUseNowaksW;
private MainWindow oMainWindow;



/**
 * This is the Dialog constructor
 *
 * @param	oPadre 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 */
public DlgParamNorms (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);

  oMainWindow = (MainWindow) oParent;
  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(5,2));

  oLabel = new Label (" Use Coalitions:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oChbCoalitions = new Choice();
  oChbCoalitions.add ("no");
  oChbCoalitions.add ("yes");
  if (Game.bCoalitions)
	oChbCoalitions.select ("yes");
  add (oChbCoalitions);
  
  
  oLabel = new Label (" Use Nowak's W (Action vs. Rewiring):", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oChbUseNowaksW = new Choice();
  oChbUseNowaksW.add ("no");
  oChbUseNowaksW.add ("yes");
  if (GameCoaReputation.bUseNowaksW)
	  oChbUseNowaksW.select ("yes");
  add (oChbUseNowaksW);

  oLabel = new Label (" Exploration Rate [0,1]:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdExplorationRate = new JTextField(String.valueOf(GameCoaMetaNorms.dExplorationRate), 7);
  add (oTdExplorationRate);
  
  oLabel = new Label (" Noise Constant [0,1]:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdKNoise = new JTextField(String.valueOf(GameCoaMetaNorms.dProbNoise), 7);
  add (oTdKNoise);

  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(500,400));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {

	if ("yes".equals (oChbCoalitions.getSelectedItem())) {
	  Game.bCoalitions = true;
	  Game.iVisorShow = 0;							// Showing the cells & coalitions
	  JPanelMainWindow.vActivateButtons();
	}
	else {
	  Game.bCoalitions = false;
	  Game.iVisorShow = 3;							// Showing the strats
	  JPanelMainWindow.vActivateButtons();
	}
	
	if ("yes".equals (oChbUseNowaksW.getSelectedItem()))
	  GameCoaReputation.bUseNowaksW = true;
	else
	  GameCoaReputation.bUseNowaksW = false;

	GameCoaReputation.dProbNoise = Double.parseDouble (oTdKNoise.getText());
	GameCoaMetaNorms.dExplorationRate = Double.parseDouble (oTdExplorationRate.getText());
    }

  dispose();
}

}	// from the class
