package games;

/**
  * Contains constant definitions for Game
  *
  * @author  Juan C. Burguillo Rial
  * @version 1.0
  */
public interface GameCons
{
final int iNULL = -13;				// Value used for comparisons

final int iDEFECT = 0;
final int iCOOPERATE = 1;

final int iHAWK = 0;
final int iDOVE = 1;
final int iPOSSESS = 2;
final int iTRADE = 3;

      // Game types
final int iSOCIALGROUPS = 0;
final int iCOA_LIFE = 1;
final int iSAT_BALL = 2;
final int iPRISONERs_DILEMMA = 3;
final int iHAWK_DOVE_POSS_TRADER = 4;
final int iCOA_IPD = 5;
final int iCOA_REPUTATION = 6;
final int iCOA_META_NORMS = 7;
final int iCOA_OPTIMIZATION = 8;
final int iCOA_PREDICTION = 9;

      // Strategy types
final int iIMITATION = 0;                   // Using basic memetics with the best neighbor
final int iIMITATE_BEST_NEIGHTBOR = 0;      // Alias for the previous strategy
final int iIMITATE_BEST_STRAT = 1;          // Imitate the most successful strategy
final int iIMITATE_POP_STRAT = 2;           // Imitating the most popular strategy
final int iINFECTION = 3;                   // Infecting neighbors using JAR's model
final int iPREDICTION = 4;									// Predicting the best chance
final int iIMITATE_PROB_BEST_NEIGHTBOR = 5; // Choosing the strategy randomly depending on the success
final int iIMITATE_PROB_BEST_STRAT = 6;     // Choosing the strategy randomly depending on the success
final int iIMITATE_PROB_POP_STRAT = 7;      // Choosing the strategy randomly depending on the success
final int iSTATISTICS = 8;              		// Using basic statistics
final int iLEARNING = 9;           					// Using Learning (Learning Automata)
final int iQ_LEARNING = 10;									// Q Learning
final int iALL_D = 11;
final int iALL_C = 12;
final int iMETA_STRAT = 13;                 // Using all the available strategies to do meta-imitation
final int iRANDOM = 14;											// Pure random strategy

final int icGA = 0;
final int iEACO = 1;

final int iSOM = 0;
final int iCASOM = 1;
final int iCASOMjoin = 2;

final int iOUTPUT_VERBOSE = 0;
final int iOUTPUT_PYTHON = 1;

final int iPURE_DECISSION=0;              // Not using probs. for deciding strategies
final int iPROB_DECISSION=1;              // Using probs. for deciding strategies

final int iIMITATE=0;
final int iCROSSOVER=1;

final int iINDEPENDENT=0;
final int iCOALITION=1;

final String sGAME_TYPE[] =	{	"0. Social Groups",
							 								"1. LIFE & Coalition LIFE",
							 								"2. Sat Ball",
							 								"3. Iterated Prisioner's Dilema (IPD)",
							 								"4. Hawk-Dove-Possessor-Trader",
							 								"5. Coalition IPD",
							 								"6. Coalition Indirect Reputation",
							 								"7. Coalition Meta-norms",
							 								"8. Function Optimization",
							 								"9. Function Prediction"
                             };

final String sCHANGE_TYPE[] = { "0. Imitate Best Neightbor",
        					 	"1. Imitate Best Strategy",						// Memetics with best strategy
        					 	"2. Imitate Pop. Strategy",						// Memetics with the most popular strategy
        					 	"3. Infection",												// Infection is active while memetics is passive
        					 	"4. Prediction",											// Prediction strategy
        					 	"5. Imitate Prob. Best Neightbor",		// Memetics with neighbors
        					 	"6. Imitate Prob. Best Strategy",			// Using wpTFT as a function of best strategies
        					 	"7. Imitate Prob. Pop. Strategy",			// Using pTFT as a function of popular strategies
        					 	"8. Statistics",
        					 	"9. Learning",
        					 	"10. Q Learning",
        					 	"11. ALL D",
        					 	"12. ALL C",
        					 	"13. META STRAT",
        					 	"14. Random",													// Pure random strategy                    
										};

final String sALGOR_OPTIM[] = {"0. cGA",
                               "1. EACO"};

final String sALGOR_PRED[] = {"0. SOM",
							  							"1. CASOM",
							  							"2. CASOMjoin"};

final String sMEMEvsGEN[] = {"0. Imitation",
                             "1. Crossover"};

final String sCOMPLEX_NET[] = {"0. Spatial Net",
                               "1. Small World Net",
                               "2. Scale Free Net",
                               "3. Random Net"};

final String sSHORT_COMPLEX_NET[] = {"0. SP",
                                     "1. SW",
                                     "2. SF",
                                     "3. RM"};

final String sPROBLEM_OPTIM_I[] = {	"0. ECC",
								 										"1. MAXCUT100",
								 										"2. MAXCUT20_01",
								 										"3. MAXCUT20_09",
								 										"4. MMDP",
								 										"5. MTTP100",
								 										"6. MTTP200",
		                         				"7. PEAK"};

final String sPROBLEM_PRED[] =   {"0. External files",
								  								"1. Sin",
								  								"2. SinCos",
								  								"3. SinCosSin"};
}

