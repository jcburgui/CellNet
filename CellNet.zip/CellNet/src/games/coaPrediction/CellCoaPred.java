package games.coaPrediction;

import problems.Function;
import games.CellCoa;
import games.Game;

import java.util.Vector;

/**
 * This class implements cells for this simulation
 * @author  Juan C. Burguillo Rial
 * @version 1.0
 */
public class CellCoaPred extends CellCoa {
protected boolean bUpdated = false;

protected int iNumBMU=0;                          	// Number of times this cell has been the BMU (closest cell)
protected double dValuationCoa;                     // It is the valuation of a coalition
protected double dValuation;                    		// It is the valuation of any cell

protected double[] dmPoint;                         // Input stored in this cell
protected double dValPred;                          // Value predicted by this cell

private CellCoaPred oLeaderPred;
private Function oFunction;




public CellCoaPred (int x, int y, int iTipoCellAux, int iActionAux, Function oFunctionAux) {
  super (x, y, iTipoCellAux, iActionAux);
  oLeaderPred = null;            					// Initially cells have no leader
  oFunction = oFunctionAux;
  dmPoint = oFunction.dmSetInput ();
  dValPred = oFunction.dSetOutput ();
  }


public boolean bIsIndependent() {
  if ( (iGetHolonSize() == 1) && (oLeaderPred == null) ) return true;
  else return false;
}

public boolean bIsCoaMember() {
  if (oLeaderPred != null) return true;
  else return false;
  }


public CellCoaPred oGetLeader ()
  {return oLeaderPred;}


// This method is an extension of the previous one to return a pointer to itself if it is the leader
public CellCoaPred oRecGetLeader () {
	if (oVHolonParts.size() > 0)      // If it is the leader
		return this;
	else
		return oLeaderPred;
}

public void vNewLeader (CellCoaPred oLiderHolonAux)
  {oLeaderPred = oLiderHolonAux;}

public void vNewHolonPart (CellCoaPred oHolonPart)
  {oVHolonParts.addElement(oHolonPart);}

public void vRemoveHolonPart (CellCoaPred oHolonPart) {
  for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoaPred oCellCoaPred = (CellCoaPred) oVHolonParts.elementAt(i);
    if (oCellCoaPred == oHolonPart) {
      oVHolonParts.removeElementAt (i);
      return;
      }
    }
  }

public boolean bChangeLeaderOK (CellCoaPred oLeaderOther, CellCoaPred oCellMax) {
  if (this == oLeaderOther)
     return false;
  else for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoaPred oCellCoaPred = (CellCoaPred) oVHolonParts.elementAt(i);
    if (oCellMax == oCellCoaPred)
      return false;
    }
  return true;
  }


public double[] dmGetPoint () {
  return dmPoint;
}

public double dGetPred () {
  return dValPred;
}
  
public int iGetNumBMU() {
  return iNumBMU;
}

public void vResetUpdated() {
  bUpdated = false;
}

public void vResetBMUs() {
  iNumBMU = 0;
}

public double dGetOutput4ExternalTool () {
  return (double) iNumBMU;
}


public double dCalcDistance2Input (double[] dmInOut) {
  double dNorma = 0;
  for (int i=0; i<oFunction.iGetNumberOfVariables(); i++)
    dNorma += (dmPoint[i] - dmInOut[i]) * (dmPoint[i] - dmInOut[i]);
  return dNorma;
}





//**************************************************** INI: UPDATING WEIGHTS **************************************************

/**
 * This method is used by a cells to update the values in its coalition and/or its neighborhood
 * 
 *  @param	dmInOut 		input/output vector
 *  @param	iNumInputVar	is the number of input dimensions
 */
public int iUpdateCellsbyBMU (double[] dmInOut, int iNumInputVar) {
  int iNumChangesAux=1;			// At least this cell (BMU)
  
  iNumBMU++;
  GameCoaPrediction.ovUpdatedCellsTMP = new Vector (1,1);
  
  bUpdated = true;
  GameCoaPrediction.ovUpdatedCellsTMP.add (this);
  for (int j=0; j<iNumInputVar; j++)																	// The BMU has a bigger update
    dmPoint[j] += Game.dLearnRate * (dmInOut[j] - dmPoint[j]);   			// Adjusting the inputs in this cell (BMU)
  dValPred += Game.dLearnRate * (dmInOut[iNumInputVar] - dValPred);   // Adjusting the output of this cell (BMU)

  
  if (GameCoaPrediction.iAlgorithm == GameCoaPrediction.iSOM)
  	iNumChangesAux += iUpdateNeighbors (dmInOut, iNumInputVar);					// BMU updates its neighbors in SOM
  
  else {
    if (iGetHolonSize() > 1)   													// If it is a leader -> updates its coalition
    	iNumChangesAux += iUpdateCoalitionCells (this, dmInOut, iNumInputVar);
    else if (oLeaderPred != null)												// If it belongs to a coalition -> the leader updates the coalition
    	iNumChangesAux += oLeaderPred.iUpdateCoalitionCells (this, dmInOut, iNumInputVar);
	}

  
  for (int i=0; i<GameCoaPrediction.ovUpdatedCellsTMP.size(); i++) {
  	CellCoaPred oCellCoaPred = (CellCoaPred) GameCoaPrediction.ovUpdatedCellsTMP.elementAt (i);
  	oCellCoaPred.bUpdated = false;
  }
  
  return iNumChangesAux;
}



/**
 * This method is used by a cell to update the values in its neighborhood
 * 
 *  @param	dmInOut 		input/output vector
 *  @param	iNumInputVar	is the number of input dimensions
 */
public int iUpdateNeighbors (double[] dmInOut, int iNumInputVar) {
  int iNumChangesAux=0;
  double dFactor = 2;
  CellCoaPred oCellCoaPred;

  for (int i=0; i<ovNeighbors.size(); i++) {
		oCellCoaPred = (CellCoaPred) ovNeighbors.elementAt (i);	
		if (Math.random() > GameCoaPrediction.dProbUpdateCell) continue;			// If do not update, then go to next
	
		oCellCoaPred.bUpdated = true;
	  GameCoaPrediction.ovUpdatedCellsTMP.add (oCellCoaPred);

		for (int j=0; j<iNumInputVar; j++)
		  oCellCoaPred.dmPoint[j] += Game.dLearnRate * (dmInOut[j] - oCellCoaPred.dmPoint[j]) / dFactor;
		oCellCoaPred.dValPred += Game.dLearnRate * (dmInOut[iNumInputVar] - oCellCoaPred.dValPred) / dFactor;
		
		iNumChangesAux++;
  }
  
  return iNumChangesAux;
}


/**
 * This method is used by a leader to update the values in its coalition
 * 
 *  @param	oBMU 			is the Best Matching Unit
 *  @param	dmInOut 		input/output vector
 *  @param	iNumInputVar	is the number of input dimensions
 */
public int iUpdateCoalitionCells (CellCoaPred oBMU, double[] dmInOut, int iNumInputVar) {
	int iNumChangesAux=0;			// The coalition leader is always updated
	double dFactor = 1;

	if (!bUpdated) {					// The leader could be already updated as a neighbor or BMU
	  for (int j=0; j<iNumInputVar; j++)
	    dmPoint[j] += Game.dLearnRate * (dmInOut[j] - dmPoint[j]) / dFactor;   			// Adjusting the inputs in the leader
	  dValPred += Game.dLearnRate * (dmInOut[iNumInputVar] - dValPred) / dFactor;
	  iNumChangesAux++;
	}

  for (int i=0; i<oVHolonParts.size();i++) {
		CellCoaPred oCellCoaPred = (CellCoaPred) oVHolonParts.elementAt (i);
		if (oCellCoaPred.bUpdated) continue;																					// It could be already updated as a neighbor or BMU
		
		for (int j=0; j<iNumInputVar; j++)
		  oCellCoaPred.dmPoint[j] += Game.dLearnRate * (dmInOut[j] - oCellCoaPred.dmPoint[j]) / dFactor;
		oCellCoaPred.dValPred += Game.dLearnRate * (dmInOut[iNumInputVar] - oCellCoaPred.dValPred) / dFactor;
		
		iNumChangesAux++;
  }
  
  return iNumChangesAux;
}



//**************************************************** END: UPDATING WEIGHTS **************************************************






//**************************************************** INI: INFECTION **************************************************

/**
* This method join cells around the BMU's, with lower valuation and with ProbInfection, to its own coalition (infection)
*  - If it is independent creates its own coalition.
*  - If it belongs a coalition, creates its new one (implicit rebellion).
*  - If it is a leader, then expands its coalition.
*/
public void vInfectCells () {
  CellCoaPred oCoaCell;
 
		// If it is independent, then infect neighbors
  if (bIsIndependent()) {
  	vInfectNeighbors (this);
  }
	  	// If it is in a coalition, gets independence and infect neighbors
  else if (bIsCoaMember()) {
    oLeaderPred.vRemoveHolonPart (this);
    vNewLeader (null);
    vInfectNeighbors (this);
  }
		// If it is already a leader, infects first my independent neighbors and also my coalition cells' neighbors
  else if (bIsLeader()) {
		vInfectNeighbors (this);
		Vector oVHolonPartsCopy = (Vector) oVHolonParts.clone();
		for (int i=0; i<oVHolonPartsCopy.size(); i++) {
		  oCoaCell = (CellCoaPred) oVHolonPartsCopy.elementAt (i);
		  oCoaCell.vInfectNeighbors(this);
		}
  }
}


/**
 * This method joins cells to a coalition (infects neighbor cells) and it is used by the previous one
 * 
 * 	 @param	oBMU 		is the Best Matching Unit
 */
public void vInfectNeighbors (CellCoaPred oBMU) {
  CellCoaPred oNeighbor;
  
  for (int i=0; i<ovNeighbors.size(); i++) {
		oNeighbor = (CellCoaPred) ovNeighbors.elementAt(i);
							// If he is a leader, this BMU is its leader or got several BMUs then continue
		if (oNeighbor.bIsLeader() || (oNeighbor.oGetLeader() == oBMU) || (oNeighbor.iGetNumBMU() > 0) )
			continue;
				   
    if (Math.random() < Game.dLearnRate*Game.dProbInf) {
    	if (oNeighbor.bIsCoaMember()) 								// If it belongs to a coalition
      	oNeighbor.oLeaderPred.vRemoveHolonPart (oNeighbor);

      oNeighbor.vNewLeader (oBMU);
      oBMU.vNewHolonPart(oNeighbor);
      Game.iNumChanges++;
    }
  }

}


//**************************************************** END: INFECTION **************************************************





/**
 * This method is used by BMU cells to rewire randomly to 'possibly' better neighbors
 */
public void vRewireRandom () {
  int iAux;
  double dAux, dDist, dDistMax=-1;
  CellCoaPred oNeighbor, oNeighborDistMax=null, oCellSel;
  Vector ovVecCellSel, ovVecNeighborDistMax;
  
  for (int i=0; i<ovNeighbors.size(); i++) {							// Finding the faraway neighbor
    oNeighbor = (CellCoaPred) ovNeighbors.elementAt(i);
    dDist = 0;
    for (int j=0; j<dmPoint.length; j++) {
      dAux = dmPoint[j] - oNeighbor.dmPoint[j];
      dDist += dAux*dAux;
    }
    
    if (dDist > dDistMax) {
      dDistMax = dDist;
      oNeighborDistMax = oNeighbor;
    }
  }
  
  ovVecNeighborDistMax = oNeighborDistMax.oVGetNeighbors();
  if (ovVecNeighborDistMax.size() == 1) return; 							// I can not leave a neighbor only connected to me
  else for (int i=0; i<Game.iMaxRandomAttempts; i++) {							// We try to rewire a certain number of times
		iAux = (int) (Math.random() * (double) Game.oVectorCells.size());	
		oCellSel = (CellCoaPred) Game.oVectorCells.elementAt (iAux);
		
		dDist = 0;
    for (int j=0; j<dmPoint.length; j++) {
      dAux = dmPoint[j] - oCellSel.dmPoint[j];
      dDist += dAux*dAux;
    }
	    
		if ( (oCellSel == this) || (bIsNeighbor (oCellSel)) || (dDist > dDistMax) ) continue;
		else {																																	// Rewiring
		  ovVecCellSel = oCellSel.oVGetNeighbors();
		  ovVecCellSel.add (this);                                              // Adding myself to the neighbor
		  ovNeighbors.add (oCellSel);                                           // Adding that neighbor
		  ovNeighbors.remove (oNeighborDistMax);                                		// Removing the worst
		  ovVecNeighborDistMax.remove (this);                                       // The most far away removes me
		  break;
		}
  }
  
}




/**
 * This method is used by BMU cells to rewire to the best neighbors of my neighbors
 */
public void vRewire2BestMate () {
  double dAux, dDist, dDistMax = -1;
  CellCoaPred oNeighbor, oNeighborDistMax=null, oCellSel=null, oCellAux;
  Vector ovMatesCellSel, ovMatesMateDistMax, ovMatesMate;
  
  for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (CellCoaPred) ovNeighbors.elementAt(i);
    dDist = 0;
    for (int j=0; j<dmPoint.length; j++) {
      dAux= dmPoint[j] - oNeighbor.dmPoint[j];
      dDist += dAux*dAux;
    }
    
    if (dDist > dDistMax) {
      dDistMax = dDist;
      oNeighborDistMax = oNeighbor;
    }
  }
	  
  ovMatesMateDistMax = oNeighborDistMax.oVGetNeighbors();
  if (ovMatesMateDistMax.size() == 1) return; 							// I can not leave a neighbor only connected to me
  else for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (CellCoaPred) ovNeighbors.elementAt(i);
    ovMatesMate = oNeighbor.oVGetNeighbors();
    
    for (int k=0; k<ovMatesMate.size(); k++) {
      oCellAux = (CellCoaPred) ovMatesMate.elementAt(k);
      
      dDist = 0;
      for (int j=0; j<dmPoint.length; j++) {
        dAux = dmPoint[j] - oCellAux.dmPoint[j];
        dDist += dAux*dAux;
      }
      
      if ( (oCellAux == this) || (bIsNeighbor (oCellAux)) || (dDist > dDistMax) ) continue;
      else {
	    	oCellSel = oCellAux;
	    	dDistMax = dDist;
      }
    }
  }

  if (oCellSel != null) {
    ovMatesCellSel = oCellSel.oVGetNeighbors();
		ovMatesCellSel.add (this);                                              // Adding myself to the neighbor
    ovNeighbors.add (oCellSel);                                           // Adding that neighbor
		ovNeighbors.remove (oNeighborDistMax);                                // Removing the worst
		ovMatesMateDistMax.remove (this);                                       // The most far away removes me
  }
  
}







//**************************************************** VALUATIONS ************************************************** 

/**
 * This method provides the valuation of a coalition
 */
public void vCalcValuationCoa () {
  double dAux;
  double dNumCells = 1.0 + oVHolonParts.size();
  double dVar=0;
  double dAvg=0, dSumBMUs=0;
  CellCoaPred oCellCoaPred;

  dSumBMUs += (double) iNumBMU;
  for (int i=0; i<oVHolonParts.size(); i++) {
    oCellCoaPred = (CellCoaPred) oVHolonParts.elementAt (i);
    dSumBMUs += oCellCoaPred.iGetNumBMU();
  }
  dAvg = dSumBMUs / dNumCells;

  dAux = ((double) iNumBMU) - dAvg;
  dVar = dAux * dAux;
  for (int i=0; i<oVHolonParts.size(); i++) {
    oCellCoaPred = (CellCoaPred) oVHolonParts.elementAt (i);
    dAux = ((double) oCellCoaPred.iGetNumBMU()) - dAvg;
    dVar += dAux * dAux;
  }
  dVar = dVar / dNumCells;

  dValuationCoa = dAvg;
}

/**
 * This method provides the valuation of a cell
 */
public void vCalcValuation () {
  if (oVHolonParts.size() > 0)						// If it is a leader				
	dValuation = GameCoaPrediction.dBeta *(double) iNumBMU + GameCoaPrediction.dGamma * dValuationCoa;
  else if (oLeaderPred != null)                    // If it has a leader
	dValuation = GameCoaPrediction.dBeta *(double) iNumBMU + GameCoaPrediction.dGamma * oLeaderPred.dGetValuationCoa(); 
  else												// If it is independent
	dValuation = (double) iNumBMU;
}

/**
 * This method returns the valuation of a coalition or an independent cell
 */
public double dGetValuationCoa () {
  return dValuationCoa;
}


/**
 * This method returns the valuation of a coalition or an independent cell
 */
public double dGetValuation () {
  return dValuation;
}






//**************************************************** BEGIN: JOIN COALITIONS ************************************************** 

/**
 * This method is used by independent cells or coalition members to join a coalition or get independence (respectively)
 */
public void vJoinCoalitions () {
  boolean bCoaCerca = false;
  double dAux, dAvgAux = 0;
  double dNumMaxOtros = 2.0;                          // Used to get random cells when there is a draw
  double dValuationCellMax = -Double.MAX_VALUE;      // Set the best
  double dValuationCellMin = Double.MAX_VALUE;       // Set the worst
  CellCoaPred oNeighbor, oCellMax = null, oLeaderHolonMax = null;
  
  dValuation = dGetValuation();
  
  for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (CellCoaPred) ovNeighbors.elementAt(i);
    dAux = oNeighbor.dGetValuation();
    
    if (oLeaderPred != null)
      if ( (oLeaderPred == oNeighbor) || (oLeaderPred == oNeighbor.oGetLeader()) ) {
        bCoaCerca = true;
        continue;                                     // If both have the same leader, then jump to the next neighbor
      }
    
    if (dAux > dValuationCellMax) {
      dNumMaxOtros = 2.0;         					  // If it is the first one, then resets
      dValuationCellMax = dAux;
      oCellMax = oNeighbor;
      oLeaderHolonMax = oCellMax.oGetLeader ();
    }
    else if (dAux == dValuationCellMax)       		  // If it has equal value, then we use a random choice
      if (Math.random() < 1.0/dNumMaxOtros) {
        dNumMaxOtros += 1.0;
        oCellMax = oNeighbor;
        oLeaderHolonMax = oCellMax.oGetLeader ();
      }

    if (dAux < dValuationCellMin)
      dValuationCellMin = dAux;

    dAvgAux += dAux;
  } // for i

  dAvgAux = dAvgAux / ((double) ovNeighbors.size());    // Valuation average

  if (oCellMax == null) return;                           // If it has not found a better neighbor then it keeps state and returns


  // *************************************** INI: Coalition change ************************************
  
  		// If it is independent
  if ( (oLeaderPred == null) && (oVHolonParts.size() == 0) ) {
    if ( (dValuation <= dValuationCellMin) && (Math.random() < (Game.dProbJoinCoa * Game.dLearnRate)) ) {  // If it is the worst or equal to -> join the best
	  Game.iNumChanges++;
      if (oLeaderHolonMax == null) {              // If CellMax has no leader
        vNewLeader (oCellMax);
        oCellMax.vNewHolonPart(this);
      } else {
        vNewLeader (oLeaderHolonMax);
        oLeaderHolonMax.vNewHolonPart(this);
      }
    }
  }

  		// If it belongs to a coalition
  else if (oLeaderPred != null) {

         // a) Isolated from the coalition or rebellion -> independence
    if ( (!bCoaCerca) || (Math.random() < Game.dProbReb) ){
      Game.iNumChanges++;
      oLeaderPred.vRemoveHolonPart (this);
      vNewLeader (null);
    }

         // b) If the valuation is even worse than the worst -> It moves to the best's coalition
    else if (dValuation < dValuationCellMin) {
      Game.iNumChanges++;
      oLeaderPred.vRemoveHolonPart (this);
      if (oLeaderHolonMax == null) {              // If CellMax has no leader
        vNewLeader (oCellMax);
        oCellMax.vNewHolonPart(this);
      } else {
        vNewLeader (oLeaderHolonMax);
        oLeaderHolonMax.vNewHolonPart(this);
      }
    }
  }		// from else if (oLeaderPred != null)

//**************************************************** END: JOIN COALITIONS **************************************************
	
}

}	// from the class CellCoaPred

