package games.coaPrediction;

import javax.swing.*;

import window.DialogOK;
import window.JPanelMainWindow;
import window.MainWindow;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import games.*;
import file.IOFile;


/**
  * This Dialog provides an interface to set the Prediction parameters
  *
  * @author  Juan C. Burguillo Rial
  * @version 1.0
  */
public class DlgParamPred extends JDialog implements ActionListener, GameCons
{
private MainWindow oMainWindow;
	
private Label oLabel, oLabelTrain, oLabelTest;
private JTextField  oTdProbUpdateCell,
                    oTiErrorBuffer,
                    oTdIniLearnRate,
                    oTiTrainSteps,
                    oTiNumInputVar,
                    oTiNumSamples,
                    oTdInitSample,
                    oTdAlfa,
                    oTdBeta;                   ;
private Choice oChTipoAlgoritmo, oChTipoProblema;

private Vector ovSamples = null;




/**
  * This is the dialog constructor.
  *
  * @param	oParent Pointer to the father of this dialog
  * @param	sTit   Title
  * @param	bBool  Describes if it is a modal window (true) or not.
  */
public DlgParamPred (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);

  oMainWindow = (MainWindow) oParent;
  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(15,2));
  
  oLabelTrain = new Label (" Train File: "+GameCoaPrediction.sTrainFile, Label.LEFT);
  add (oLabelTrain);
  JButton oBut = new JButton ("Change Train File");
  oBut.addActionListener (this);
  add (oBut);
  
  oLabelTest = new Label (" Test File: "+GameCoaPrediction.sTestFile, Label.LEFT);
  add (oLabelTest);
  oBut = new JButton ("Change Test File");
  oBut.addActionListener (this);
  add (oBut);

  oLabel = new Label (" Problem:", Label.LEFT);
  add (oLabel);
  oChTipoProblema = new Choice();
  for (int i=0; i<sPROBLEM_PRED.length; i++)
    oChTipoProblema.add (sPROBLEM_PRED[i]);
  oChTipoProblema.select (GameCoaPrediction.iFunctionType);
  add (oChTipoProblema);
  
  oLabel = new Label (" Algorithm:", Label.LEFT);
  add (oLabel);
  oChTipoAlgoritmo = new Choice();
  for (int i=0; i<sALGOR_PRED.length; i++)
    oChTipoAlgoritmo.add (sALGOR_PRED[i]);
  oChTipoAlgoritmo.select (Game.iAlgorithm);
  add (oChTipoAlgoritmo);
 
  oLabel = new Label (" Prob. of updating a cell:", Label.LEFT);
  add (oLabel);
  oTdProbUpdateCell = new JTextField(String.valueOf (GameCoaPrediction.dProbUpdateCell), 7);
  add (oTdProbUpdateCell);
  
  oLabel = new Label (" Error buffer size:", Label.LEFT);
  add (oLabel);
  oTiErrorBuffer = new JTextField(String.valueOf (GameCoaPrediction.iErrorBufferSize), 7);
  //oTiErrorBuffer.setEditable (false);
  add (oTiErrorBuffer);

  oLabel = new Label (" Initial Learn Rate:", Label.LEFT);
  add (oLabel);
  oTdIniLearnRate = new JTextField(String.valueOf (Game.dIniLearnRate), 7);
  add (oTdIniLearnRate);

  oLabel = new Label (" Number of train steps:", Label.LEFT);
  add (oLabel);
  oTiTrainSteps = new JTextField(String.valueOf (GameCoaPrediction.iTrainEpochs), 7);
  add (oTiTrainSteps);
    
  oLabel = new Label (" Number of samples:", Label.LEFT);
  add (oLabel);
  oTiNumSamples = new JTextField(String.valueOf (GameCoaPrediction.iNumSamples), 7);
  add (oTiNumSamples);

  oLabel = new Label (" Initial sample at:", Label.LEFT);
  add (oLabel);
  oTdInitSample = new JTextField(String.valueOf (GameCoaPrediction.dInitSample), 7);
  add (oTdInitSample);

  oLabel = new Label (" Number of Input Variables:", Label.LEFT);
  add (oLabel);
  oTiNumInputVar = new JTextField(String.valueOf (GameCoaPrediction.iNumInputVar), 7);
  add (oTiNumInputVar);

  oLabel = new Label (" Beta * NumBMU (CASOM):", Label.LEFT);
  add (oLabel);
  oTdAlfa = new JTextField(String.valueOf (GameCoaPrediction.dBeta), 7);
  add (oTdAlfa);
  
  oLabel = new Label (" Gamma * AvgBMUCoa (CASOM):", Label.LEFT);
  add (oLabel);
  oTdBeta = new JTextField(String.valueOf (GameCoaPrediction.dGamma), 7);
  add (oTdBeta);
  

  
  oLabel = new Label ("");
  add (oLabel);
  oLabel = new Label ("");
  add (oLabel);
  
  oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(500,700));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }





/**
  * This methods receives and process all the events in this class
  *
  *	@param evt In this parameter we receive the generated event
  */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {
    Game.iAlgorithm = oChTipoAlgoritmo.getSelectedIndex();

    int iTipoFun = oChTipoProblema.getSelectedIndex();
    if ( (GameCoaPrediction.iFunctionType == 0) && ((GameCoaPrediction.ovTrainSamples == null) || (GameCoaPrediction.ovTestSamples == null)) ) {
      String sAux[] ={"Wrong selection !", "With external data you must select", "the train and test files."};
      new DialogOK (oMainWindow, "Error !!!", true, sAux);
      return;
    }
    
    GameCoaPrediction.iFunctionType = iTipoFun;
    JPanelMainWindow.oJLabelInfo.setText ("Problem: "+GameCoaPrediction.iFunctionType);
    JPanelMainWindow.vActivateButtons();

    if (Game.iAlgorithm == Game.iSOM) {
      oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (SOM)");
      Game.iVisorShow = 11;
    } else {
      oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (CASOM)");
      Game.iVisorShow = 0;
    }

    GameCoaPrediction.dProbUpdateCell = Double.parseDouble (oTdProbUpdateCell.getText());
    GameCoaPrediction.iErrorBufferSize = Integer.parseInt (oTiErrorBuffer.getText());
    GameCoaPrediction.dIniLearnRate = Double.parseDouble (oTdIniLearnRate.getText());
    GameCoaPrediction.iTrainEpochs = Integer.parseInt (oTiTrainSteps.getText());
    GameCoaPrediction.iNumInputVar = Integer.parseInt (oTiNumInputVar.getText());
    GameCoaPrediction.iNumSamples = Integer.parseInt (oTiNumSamples.getText());
    GameCoaPrediction.dIncSample = Math.PI / GameCoaPrediction.iNumSamples;
    GameCoaPrediction.dInitSample = Double.parseDouble (oTdInitSample.getText());
    GameCoaPrediction.dBeta = Double.parseDouble (oTdAlfa.getText());
    GameCoaPrediction.dGamma = Double.parseDouble (oTdBeta.getText());
    oMainWindow.vSetupThread();
    dispose();
  }
  
  else if ("Cancel".equals (evt.getActionCommand()))
  	dispose();
  
  else if ("Change Train File".equals (evt.getActionCommand())) {
		ovSamples = new Vector<Float> (1,1);
		String sAux = IOFile.sReadDataFile (oMainWindow, ovSamples);
		if (sAux != null) {
		  GameCoaPrediction.sTrainFile = sAux; 
	      oLabelTrain.setText ("Train File: "+sAux);
		  GameCoaPrediction.ovTrainSamples = ovSamples;
	      repaint();
		}
  }

  else if ("Change Test File".equals (evt.getActionCommand())) {
		ovSamples = new Vector<Float> (1,1);
		String sAux = IOFile.sReadDataFile (oMainWindow, ovSamples);
		if (sAux != null) {
		  GameCoaPrediction.sTestFile = sAux;
		  oLabelTest.setText ("Test File: "+sAux);
		  GameCoaPrediction.ovTestSamples = ovSamples;
		  repaint();
		}
  }

}

}	// from class DlgParamPred
