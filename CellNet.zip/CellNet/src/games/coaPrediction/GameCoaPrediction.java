package games.coaPrediction;

import problems.Function;
import problems.prediction.*;
import window.DlGraphics;
import window.JPanelMainWindow;
import window.MainWindow;
import window.WindowCons;
import games.Game;

import java.util.Vector;


/**
  * This class implements the CASOM algorithm for prediction
  *
  * @author  Juan C. Burguillo Rial
  * @version 1.0
  * 
  * General Comments:
  *
  * Behavior:
  *   
  */


public class GameCoaPrediction extends Game implements WindowCons
{
private double dValFun = 0;                 							// Stores the function value
private double dValPred = 0;  											// Stores the predicted value
private double dPredError = 0;										    // dPredError = Math.Abs (dValFun - dValPred);
private double dPredError2 = 0;										    // dPredError2 = dPredError * dPredError
//private double dSumPredError = 0;										// Sum of dPredError (over iErrorBufferSize)
private double dSumPredError2 = 0;										// Sum of dPredError2 (over iErrorBufferSize)
public static double dAvgPredError = 0;									// Avg. value from dSumPredError or dSumPredError2

//************************************ INI: VALUES ACCESED FROM DlgParamPred.java *********************************************
public static int iFunctionType = 3;									// Type of function to predict
public static double dProbUpdateCell = 0.1;							// Probability of updating a neighbor or coalition cell
public static int iErrorBufferSize = 1000; 								// Number of error values stored in the buffer
public static int iTrainEpochs = 10;									// Number of train epochs, it affects the dDecLearnRate in ExternalData
public static int iNumSamples = 1000;             						// Number of samples in periodic functions
public static double dInitSample = 0.0;      							// Initial point to sample
public static int iNumInputVar = 2;               						// Input Variables
public static double dBeta = 1.0;      									// Weight of the number of cells in coalition
public static double dGamma = 1.0;      								// Weight of the variance in coalition
//public static double dErrorValue2Stop = 0.001;						// Error Value to stop
//************************************ END: VALUES ACCESED FROM DlgParamPred.java *********************************************

public static boolean bTraining = true;									// First we train, then we test

public static CellCoaPred[][] oCellMatrix = new CellCoaPred [iCellH][iCellV];	// This is the cell matrix, which is accessed by VisorWorld
public static int iNumTrainSamples;              						// Number of training samples
public static int iNumTestSamples;		         						// Number of testing samples
public static double dIncSample = Math.PI / iNumSamples;  				// Distance between successive samples (determined by number of samples)
public static double dDecLearnRate;										// Error rate decrement per iteration
public static int iNumTotalTrainSamples;		         				// Total number of training samples

public static String sTrainFile="None";									// File for training
public static String sTestFile="None";									// File for testing
public static Vector ovTrainSamples = null;								// Contains the samples from the train file
public static Vector ovTestSamples = null;								// Contains the samples from the test file

static Vector ovUpdatedCellsTMP;										// Temporal list of updates cells by the BMU

public static Function oFunction;

//private Vector<Double> oVErrorBuffer;									// Buffer with the absolute error
private Vector<Double> oVErrorBuffer2;									// Buffer with the square error
public static Vector<Double> oVGraphErrorBuffer;	    				// Graphical buffer with the absolute error
public static Vector<Vector> oVValuesFPEL;								// Contains the functional, predicted, error and LearningRate values




/**
  * This is the class constructor
  *
  */
public GameCoaPrediction () {
  super();
  
  iNumActions = 3;                              	// 3 options: Independent (IC), Coalition (CC) or Leader (LC)
  iVisorShow = 11;

}


/**
  * This is the class constructor
  *
  */
public GameCoaPrediction (MainWindow oVentAux) {
  this();
  
  oMainWindow = oVentAux;

}



/**
  * This method setup the games every time "New" is pressed.
  *
  */
public void vNewGame() {
  super.vNewGame();

  bTraining = true;
  if (iFunctionType == 0) {
	oFunction = new ExternalData (iNumInputVar);
    iNumTrainSamples = ovTrainSamples.size();
    iNumTestSamples = ovTestSamples.size();
  }
  else {
    switch (iFunctionType) {
      case 1:  oFunction = new Sin (iNumInputVar, dIncSample, dInitSample); break;
      case 2:  oFunction = new SinCos (iNumInputVar, dIncSample, dInitSample); break;
      case 3:  oFunction = new SinCosSin (iNumInputVar, dIncSample, dInitSample); break;
    }
    iNumTrainSamples = iNumSamples;											// To stop after iterating over all samples a number of train steps
    iNumTestSamples = iNumSamples;
  }

  oFunction.vSetTraining();
  
  MainWindow.iGenStop = iNumTrainSamples * iTrainEpochs + iNumTestSamples;					// To stop after training + testing
  //dDecLearnRate = Game.dIniLearnRate / (double) (iNumTrainSamples * iTrainEpochs);			// OJO: decreasing every train sample (see below)
  dDecLearnRate = Game.dIniLearnRate / (double) iTrainEpochs;								// OJO: decreasing every train epoch: works better (see above)
  iNumTotalTrainSamples = iNumTrainSamples * iTrainEpochs;

  int iNumCells = (int) (5.0 * Math.sqrt ((double) iNumTrainSamples));		// We set automatically the number of neurons per map
  MainWindow.iCellSize = (int) (MainWindow.iMapSize / Math.sqrt(iNumCells));
  iCellH = MainWindow.iMapSize / MainWindow.iCellSize;
  iCellV = MainWindow.iMapSize / MainWindow.iCellSize;
  iTotPosMatrix = iCellH * iCellV;
  
  dLearnRate = dIniLearnRate;
  Game.oCellMatrix = null;
  oCellMatrix = new CellCoaPred [Game.iCellH][Game.iCellV];

  int iTipoCell = 0;
  int iAction = 0;
  oVTextAction = new Vector<String> (1,1);
  oVTextAction.add ("IC");           // IC == 0, Independent Cells
  oVTextAction.add ("CC");           // CC == 1, Coalition Cells
  oVTextAction.add ("CN");           // NC == 2, Coalition Number
  
  oVValuesFPEL = new Vector<Vector> (1,1);
  for (int i=0; i<4; i++)
    oVValuesFPEL.add (new Vector (1,1));

  dSumPredError2 = 0;
  oVErrorBuffer2 = new Vector<Double> ();
  oVGraphErrorBuffer = new Vector<Double> ();
  
  for (int x=0; x<iCellH; x++)
    for (int y=0; y<iCellV; y++) {
      if (dProbEmpty > 0.0)
        if (dProbEmpty > Math.random()) {
          oCellMatrix[x][y] = null;        // If there are empty cells, and one is chosen, put it to null
          continue;
          }

      iAction = 0;                        // Initially, all cells are independent
      imCellsAction[iAction]++;
      iTotNumCells++;
      oCellMatrix[x][y] = new CellCoaPred (x, y, iTipoCell, iAction, oFunction);
      }

  Game.oCellMatrix = oCellMatrix;
  oVectorCells = ovCells2Vector (oCellMatrix);

  switch (iNetType) {
    case 0:   vSetNeighborsSpatialRadio (oCellMatrix); break;
    case 1:   vSetNeighborsSmallWorld (oCellMatrix); break;
    case 2:   vSetNeighborsScaleFree (oCellMatrix); break;
    case 3:   vSetNeighborsRandomNetwork (oCellMatrix); break;
  }
  

  if ( (iNewGame == 0) && (MainWindow.iBatchMode < 2) ) {

    MainWindow.oMIWindow[iFREQxACTION].setEnabled (true);
    MainWindow.oMIWindow[iCHANGESxGEN].setEnabled (true);
    MainWindow.oMIWindow[iFUN_VALUES].setEnabled (true);
    MainWindow.oMIWindow[iERR_VALUES].setEnabled (true);
  
    JPanelMainWindow.oJLabelInfo.setText ("Problem: "+GameCoaPrediction.iFunctionType);

    if (Game.iAlgorithm == Game.iSOM) {
      oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (SOM)");
      Game.iVisorShow = 11;
    } else {
      oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (CASOM)");
      Game.iVisorShow = 0;
    }
    
    JPanelMainWindow.vActivateButtons();

    if (MainWindow.iBatchMode == 0) {

  	  MainWindow.omDlGraf[iFREQxACTION] = new DlGraphics (oMainWindow, " CellNet: Frequency per Action", false, iFREQxACTION);
  	  MainWindow.omDlGraf[iFREQxACTION].setVisible(true);
  	  MainWindow.omDlGraf[iCHANGESxGEN] = new DlGraphics (oMainWindow, " CellNet: Action Changes", false, iCHANGESxGEN);
  	  MainWindow.omDlGraf[iCHANGESxGEN].setVisible(true);
  	  MainWindow.omDlGraf[iFUN_VALUES] = new DlGraphics (oMainWindow, " CellNet: Functional Values", false, iFUN_VALUES);
  	  MainWindow.omDlGraf[iFUN_VALUES].setVisible(true);
  	  MainWindow.omDlGraf[iERR_VALUES] = new DlGraphics (oMainWindow, " CellNet: Error Values", false, iERR_VALUES);
	  MainWindow.omDlGraf[iERR_VALUES].setVisible(true);	  
    }
  }
  
  iNewGame++;
  
}




/**
  * This method contains the sequence of actions to do per cycle
  */
public void vRunLoop() {
  double dAux;
  double dDistBMU = Integer.MAX_VALUE;
  double[] dmInOut;
  CellCoaPred oCellBMU=null;
 
  iNumGen++;                                    // Increasing the number of generations
  dmInOut = oFunction.dmEvaluate();

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++) {								// Every cells determines its distance to the input sample
    dAux = oCellMatrix[x][y].dCalcDistance2Input (dmInOut);
    if (dAux < dDistBMU) {
      dDistBMU = dAux;
      oCellBMU = oCellMatrix[x][y];
    }
  }
  
  dValFun = dmInOut[iNumInputVar];
  dValPred = oCellBMU.dGetPred();
  
  
  // ***************************************** BEGIN: TRAINING **************************************************
  if (bTraining) {
    
    if (Math.random() < dProbRewiring) {
        if (Math.random() < dProbRewireRandom)				// Avoid far away neighbors to connect to closest ones and save training time
        	oCellBMU.vRewireRandom ();
        else
        	oCellBMU.vRewire2BestMate ();
      }

    //iNumChanges = oCellBMU.iUpdateCellsbyBMU (dmInOut, iNumInputVar);
    
    if (iAlgorithm == iCASOM)								// Coalitions are only used in CASOM, SOM does not enter here
      oCellBMU.vInfectCells ();								// The BMU "infects" closer cells, joining them to its coalition

    else if (iAlgorithm == iCASOMjoin) {		// Only for CASOMjoin (not used by CASOMinf)
      for (int y=0; y<iCellV; y++)
      for (int x=0; x<iCellH; x++) {
        if (oCellMatrix[x][y].iGetHolonSize() > 1)    		// If it is a leader determines the valuation of its coalition
      	  oCellMatrix[x][y].vCalcValuationCoa ();
      }
    
      for (int y=0; y<iCellV; y++)							// Every cell calculates its own valuation
      for (int x=0; x<iCellH; x++)
        oCellMatrix[x][y].vCalcValuation ();

      for (int y=0; y<iCellV; y++)							// Instead of infection, cells can join coalitions
      for (int x=0; x<iCellH; x++)
        if (oCellMatrix[x][y].iGetHolonSize() == 1)        	// If it is not a leader: independent or coalition member
          oCellMatrix[x][y].vJoinCoalitions ();          	// Consider to join a coalition or get independence
    }      
     
    
    					// Depending on if it is independent or coalition member updates weights
    iNumChanges = oCellBMU.iUpdateCellsbyBMU (dmInOut, iNumInputVar);
    
    if (dLearnRate > 0) {
      //dLearnRate -= dDecLearnRate;							// OJO: decreasing every train sample (see above)
      if (iNumGen % iNumTrainSamples == 0) {
        dLearnRate -= dDecLearnRate;						// OJO: decreasing every epoch: works better (see above)
        //vREM ();											// After every epoch, do a REM phase for all cells 
        for (int y=0; y<iCellV; y++)
        for (int x=0; x<iCellH; x++)
          oCellMatrix[x][y].vResetBMUs();
      }
    }
      
    if (dLearnRate < 0) {
      dLearnRate = 0;
      bTraining = false;
      oFunction.vSetTesting ();
    }														// If dLearnRate == 0, then it does not enter into any of those if-else
    
  }		// from if (bTraining)
  
  
  // ***************************************** END: TRAINING ****************************************************

  
  
  vSetStatsGamePrediction();
  if (MainWindow.iBatchMode < 2)
		vSetGraphicValues ();
	sTextStateBar = "NGen: "+iNumGen+"          Ind: "+imCellsAction[0]+"  Coa: "+imCellsAction[1]+" ("+imCellsAction[2]+")"
	                      +"          Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
  
//  if (dMediaError < dErrorValue2Stop) MainWindow.iGenStopTMP = iNumGen + 1;     // If error average decreases -> Stop the simulation
  }		// from vEjecutaCiclo()



private void vREM () {
  for (int y=0; y<iCellV; y++)						// Here we do the REM phase as an oniric similarity
  for (int x=0; x<iCellH; x++) {
	if (Math.random() < dProbRewireRandom)
	  oCellMatrix[x][y].vRewireRandom ();
	else
	  oCellMatrix[x][y].vRewire2BestMate ();
  }
}



/**
  * This method updates the statistics of the stored values
  */
protected void vSetStatsGamePrediction() {
  Double oDouble;
	
  imCellsAction = new int [iNumActions];		  		  	// Reset
  //imCellsType = new int [iNumTypes];		  				// Reset

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++) {
    if (oCellMatrix[x][y].bIsLeader()) {		       	// If it is a leader
      imCellsAction[2]++;
      oCellMatrix[x][y].vSetAction(2);
    }
    else if (oCellMatrix[x][y].bIsCoaMember()) { 		// If it belongs to a coalition
      imCellsAction[1]++;
      oCellMatrix[x][y].vSetAction(1);
    }
    else {                                            	// If it is independent
      imCellsAction[0]++;
      oCellMatrix[x][y].vSetAction(0);
    }
  }

  dPredError = Math.abs (dValFun - dValPred);
  dPredError2 = dPredError * dPredError;
  //oVErrorBuffer.add (new Double (dPredError));
  oVErrorBuffer2.add (new Double (dPredError2));
  //dSumPredError += dPredError;
  dSumPredError2 += dPredError2;
  while (oVErrorBuffer2.size() > iErrorBufferSize) {
		oDouble = (Double) oVErrorBuffer2.firstElement();
		dSumPredError2 -= oDouble.doubleValue();;
		oVErrorBuffer2.removeElementAt (0);
  }
  dAvgPredError = Math.sqrt (dSumPredError2 / oVErrorBuffer2.size());		// Average RMSE
  //dAvgPredError = dSumPredError / oVErrorBuffer.size();					// Average absolute mean Error
}


/**
  * This method updates the frequency in the graphics concerning movement or action change
  */
protected void vSetGraphicValues () {
  Vector<Integer> oVectI;
  Vector<Double> oVectD;

  super.vSetGraphicValues();
  
  oVGraphErrorBuffer.add (new Double (dPredError));
  while (oVGraphErrorBuffer.size() > MainWindow.iLastNGen)
	oVGraphErrorBuffer.removeElementAt (0);
  
  for (int i=0; i<oVValuesFPEL.size(); i++) {
    oVectD = (Vector) oVValuesFPEL.elementAt (i);
    switch (i) {
      case 0: oVectD.add (new Double (dValFun)); break;
      case 1: oVectD.add (new Double (dValPred)); break;
      case 2: oVectD.add (new Double (dPredError)); break;
      case 3: oVectD.add (new Double (dLearnRate));
    }
    while (oVectD.size() > MainWindow.iLastNGen)
    	oVectD.removeElementAt (0); 
  }
  
}


}	// from the class GamePrediction

