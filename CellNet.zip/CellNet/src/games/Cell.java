package games;

import java.util.Vector;
import java.util.HashMap;
import java.util.Map;


/**
  * This is the basic class to model a cell
  *
  * @author  Juan C. Burguillo Rial
  * @version 3.0
  */
public class Cell
{
protected String sIdCell;										// String identifier of the Cell
protected boolean bOwnsResource = false;		// Indicate if this cell owns any abstract resource	
protected int iPosX;											  // X cell's position on the grid
protected int iPosY;											  // Y cell's position on the grid
protected int iAction;                                            // Present action (defect, cooperate, etc.) to be used
protected int iNewAction;                                         // New Action
protected int iCellType;                                          // Cell type (independent, coa member, leader, etc.)
protected int iNewCellType;                                       // New Cell type
protected int iStrategy;                                      		// Strategy (defector, cooperator, etc.) used by this cell
protected int iNewStrategy;                                      	// New Strategy
protected int iStrategyType;                                      // Strategy (imitation, learning, etc.) used by this cell
protected int iAliveNeighbors;																		// Used in LIFE games
protected int iColor;																							// Used in Sat Ball games
protected double dPayoff;                                         // Instant income per generation
protected double dPayoffNeighbors;                                // Instant neighbors income per generation
protected double dPayoffBuffer;                                   // Sum of the buffer incomes
protected double dTotPayoff;                                      // Total income over all generations
protected double dPayoffGen=Game.dCellIncomeGen;                  // Income per generation
protected double dCostGen=Game.dCellCostGen;                      // Costs per generation
protected int iNumDefectors;                                      // Number of defectors in the last generation
protected Vector<Cell> ovNeighbors = new Vector<Cell> (1,1);      // Neighbors of this cell

protected double dGlobalValMax = -Double.MAX_VALUE;
protected double dGlobalValMin = Double.MAX_VALUE;
protected double dAllGlobalValMax = -Double.MAX_VALUE;
protected double dAllGlobalValMin = Double.MAX_VALUE;

protected Vector<Vector<?>> ovBufStatxAcc = new Vector<Vector<?>> (1,1);        // Store incomes per action type
protected Vector<Double> ovBufPayoff = new Vector<Double> (1,1);                // Stores the last iStatsBufferSize incomes

// BEGIN ------------------- Complex Networks ------------------------------
protected int iIdPajek = 0;                                       // Identifier to exchange data with Pajek
protected double dMaxPayoff = 0;                                  // It is the maximum payoff per cell, used for rewiring
protected Cell oCellMinPayoff=null;								  							// Cell with the minimum payoff
// END --------------------- Complex Networks ------------------------------


protected double[] dProbAction = new double [Game.iNumActions];   // Prob. of choosing this action

// BEGIN ------------------ Learning (Q-Learning or LA) ----------------------
private 	Map<String,StateAction> oMapStateActions = new HashMap<String,StateAction>();
protected Vector<StateAction> oVBufferStateActions = new Vector<StateAction>(1,1);		// Buffer to remember the last states and actions taken
protected Vector<Integer> oVBufferActions = new Vector<Integer>(1,1);
protected StateAction oLastStateAction=null, oPresentStateAction=null;      // Last and present states
protected int[] iNumTimesAction  = new int [Game.iNumActions];      				// Number of times an action has been selected
protected double[] dPayoffAction = new double [Game.iNumActions];   				// Incomes obtained by this action
protected boolean bAllActions = false;										// Needed here to avoid checking it at all times
protected double dGamma = 0.9;
protected double dLearnRate = Game.dLearnRate;						// Every cell has its own learning rate
protected double dEpsilon = Game.depsGreedy;							// Every cell has its own epsilon
protected double dLastFunEval;														// Last value of Function evaluation (used for rewards)
// END -------------------- Learning (Q-Learning or LA) ----------------------



public Cell (int x, int y, int iCellTypeAux, int iActionAux) {
  this (""+x+","+y, iCellTypeAux, iActionAux);
  iPosX = x;
  iPosY = y;
}


public Cell (String sIdAux, int iCellTypeAux, int iActionAux) {
  sIdCell = new String (sIdAux);
  iCellType = iCellTypeAux;
  iNewCellType = iCellTypeAux;
  iAction = iActionAux;
  iNewAction = iActionAux;
  iAliveNeighbors = 0;
  iColor = -1;

  for (int i=0; i<(Game.iNumActions); i++) {
    iNumTimesAction[i] = 0;
    dPayoffAction[i] = 0;
    dProbAction[i] = 1.0 / ((double) Game.iNumActions);
    ovBufStatxAcc.addElement (new Vector<Object>(1,1));
    }

  iStrategyType = Game.iChangeType;

  dPayoff = 0;
  dPayoffBuffer = 0;
  dTotPayoff = 0;
  dPayoffNeighbors = 0;
  for (int i=0; i<Game.iStatsBufferSize; i++)
    ovBufPayoff.addElement (new Double (dPayoff));
  }

public String sGetID ()
  {return sIdCell;}
  
public int iGetPosX ()
  {return iPosX;}

public int iGetPosY ()
  {return iPosY;}

public void vSetNewPos (int x, int y) {
  iPosX = x;
  iPosY = y;
}

public int iGetStringPosX () {
  int iIndex = sIdCell.indexOf (",");
  String sAux = sIdCell.substring (0, iIndex);					// Taking the initial substring
  return Integer.parseInt (sAux);
  }

public int iGetStringPosY () {
  int iIndex = sIdCell.indexOf (",");
  String sAux = sIdCell.substring (iIndex+1);					// Taking the final substring
  return Integer.parseInt (sAux);
  }

public int iGetCellType ()
  {return iCellType;}

public int iGetNewCellType ()
  {return iNewCellType;}

public void vSetCellType (int iAux)
  {iCellType = iAux;}

public void vSetNewCellType (int iAux)
  {iNewCellType = iAux;}

public void vUpdateCellType ()
  {iCellType = iNewCellType;}

public int iGetStrategyType ()
  {return iStrategyType;}

public int iGetStrategy ()
{return iStrategy;}

public int iGetAction ()
  {return iAction;}

public int iGetNewAction ()
  {return iNewAction;}

public int iGetColor()
	{return iColor;}

public void vSetColor (int iColorAux)
	{iColor = iColorAux;}

public int iGetAliveNeighbors()
  {return iAliveNeighbors;}

public void vSetAliveNeighbors (int iAliveNeighborsAux)
  {iAliveNeighbors = iAliveNeighborsAux;}

public void vUpdateAction ()
  {iAction = iNewAction;}

public void vSetNewAction (int iAux)
  {iNewAction = iAux;}

public void vSetAction (int iAux)
  {iAction = iAux;}

public void vSetStrategyType (int iStrategyTypeAux)
{iStrategyType = iStrategyTypeAux;}

public void vSetStrategy (int iAux)
{iStrategy = iAux;}

public void vSetNumDefectors (int iNumDefAux)
{iNumDefectors = iNumDefAux;}

public int iGetNumDefectors ()
{return iNumDefectors;}


public void vSetPayoff (double dAux)
  {dPayoff = dAux;}


public void vAddPayoffs (double dPayoffAux, double dPayoffNeighborsAux) {
  dPayoff += dPayoffAux;
  dPayoffNeighbors += dPayoffNeighborsAux;
  }


public void vResetPayoff () {
	dTotPayoff += dPayoff;
  //if (dTotPayoff < 0) dTotPayoff = 0;

  dPayoff = dPayoffGen - dCostGen;                	// Initial value per generation
  dPayoffNeighbors = 0;
  iNumDefectors = 0;  
  }


public void vUpdateBufferPayoff () {
  dPayoffBuffer += dPayoff;  	
  
  ovBufPayoff.addElement (new Double (dPayoff));
  while (ovBufPayoff.size() > Game.iStatsBufferSize) {	// If there is more, delete the first
    Double oDouble = (Double) ovBufPayoff.elementAt(0);
    dPayoffBuffer -= oDouble.doubleValue();
    ovBufPayoff.removeElementAt (0);
    }
}


public double dGetPayoff () {
  if (Game.bStorePayoff)
    return dTotPayoff;
  else
    return dPayoff;
  }

public double dGetAvgPayoff () {
    return (dPayoff / ovNeighbors.size()) ;
  }

public double dGetPrevPayoff () {
  Double oDouble = (Double) ovBufPayoff.lastElement();
  return oDouble.doubleValue();
}

public double dGetPayoffBuffer ()
	{return dPayoffBuffer;}

public double dGetAvgPayoffBuffer ()
	{return (dPayoffBuffer / ovNeighbors.size());}


public double dGetTotPayoff ()
  {return dTotPayoff;}

public double dGetPayoffGen ()
  {return dPayoffGen;}

public void vAddPayoffGen (double dInc)
  {dPayoffGen += dInc;}



      // Social Net
public void vAddNeighbor (Cell oCell)
  {ovNeighbors.add (oCell);}

public void vSetNeighbors (Vector<Cell> oVec)
  {ovNeighbors = oVec;}

public Vector oVGetNeighbors ()
  {return ovNeighbors;}

public void vSetIdPajek (int iId)
  {iIdPajek = iId;}

public int iGetIdPajek()
  {return iIdPajek;}

public double dGetMaxPayoff()
  {return dMaxPayoff;}

public void vSetMaxPayoff (double dPayMax)
  {dMaxPayoff = dPayMax;}


public boolean bIsNeighbor (Cell oNeighbor) {
  for (int i=0; i<ovNeighbors.size(); i++) {
    Cell oVec = (Cell) ovNeighbors.elementAt(i);
    if (oVec == oNeighbor)
      return true;
  }
  return false;
}

public void vSetCellMinPayoff (Cell oCell) {
  oCellMinPayoff = oCell;
}

public Cell oGetCellMinPayoff() {
  return oCellMinPayoff;
}

public double dGetProbAction (int iAction) {
  return dProbAction[iAction];
}


public void vCheckNewResource() {	
	if (Math.random() < Game.dProbResource)							// This cell has some resource in this interaction
		bOwnsResource = true;
	else
		bOwnsResource = false;
}


public boolean bOwnsResource() {
	return bOwnsResource;
}




/**
  * This method generate statistics for every cell.
  * WARNING: It must be called at the end of the iteration (before deciding every new action).
  */
public void vGenerateStats() {
  double dAux;
  Double oDouble;
  Vector<Double> oVect;

  if (dPayoff > dGlobalValMax)
    dGlobalValMax = dPayoff;
  if (dPayoff < dGlobalValMin)
    dGlobalValMin = dPayoff;

  dAux = dPayoff + dPayoffNeighbors;
  if (dAux > dAllGlobalValMax)
    dAllGlobalValMax = dAux;
  if (dAux < dAllGlobalValMin)
    dAllGlobalValMin = dAux;

  oVect = (Vector<Double>) ovBufStatxAcc.elementAt (iAction);
  oVect.addElement (new Double (dPayoff));
  iNumTimesAction[iAction]++;
  dPayoffAction[iAction] += dPayoff;
  
  while (oVect.size() > Game.iStatsBufferSize)	{				// Keeping buffer size
  	iNumTimesAction[iAction]--;
  	oDouble = (Double) oVect.elementAt (0);
  	dPayoffAction[iAction] -= (double) oDouble.doubleValue();
    oVect.removeElementAt (0);
  }
  
}





/**
  * This method is used to select the next action (Schaerf) considering a statistical
  * criteria for the action that provided more benefits in the last iStatsBufferSize attempts.
  *
  */
public void vGetNewActionStats () {
  double dAux, dAuxTot;
  double[] dAuxValAction = new double [Game.iNumActions];

                  // Checking that I have tested all actions
  if (!bAllActions) {
    bAllActions = true;
    for (int i=0; i<Game.iNumActions; i++)
      if (iNumTimesAction[i] == 0) {
        bAllActions = false;
        break;
        }
    }
  else {                  // If all has been tested, the probabilities are adjusted
    dAuxTot = 0;
    for (int i=0; i<Game.iNumActions; i++) {																// Calculating average incomes
      dAuxValAction[i] = dPayoffAction[i] / (double) iNumTimesAction[i];		// Avg. value
      dAuxValAction[i] = Math.pow (dAuxValAction[i], Game.dExponent);				// We raise it to dExponent
      dAuxTot += dAuxValAction[i];																					// Adding the results
      }

    for (int i=0; i<Game.iNumActions; i++)
      dProbAction[i] = dAuxValAction[i] / dAuxTot;                      		// Calculating probs.
    }	// if (bAllActions)


  dAuxTot = 0;
  dAux = Math.random();
  for (int i=0; i<Game.iNumActions; i++) {
	dAuxTot += dProbAction[i];
    if (dAux <= dAuxTot) {
      iNewAction = i;
      break;
    }
  }

}




/**
 * This method is used to imitate probabilistically a memetic majority behavior.
 * It is basically a probabilistic TFT adapted to neighborhoods. 
 */
public void vGetNewActionProbTFT() {
 if ( Math.random() < ((double) iNumDefectors / (double) ovNeighbors.size()) )
   iNewAction = 0;
 else
   iNewAction = 1;
 }






/**
  * This method uses Learning Automata (LA) to select a new action depending on the
  * past experiences but without states. The algorithm works as: store, adjust and generate.
  */
public void vGetNewActionAutomata () {
  int iBest=-1, iNumBest=1;
  double dAux;
  double[] dAvgPayoffAction = new double [Game.iNumActions];

                  // Check that all actions have been already tried
  if (!bAllActions) {
    bAllActions = true;
    for (int i=0; i<Game.iNumActions; i++)
      if (iNumTimesAction[i] == 0) {
        bAllActions = false;
        break;
        }
    }

    // If all actions have been tried, adjust the probabilities of the automata
  else {
    for (int i=0; i<Game.iNumActions; i++)						// Determine the average benefits    
      dAvgPayoffAction[i] = dPayoffAction[i] / iNumTimesAction[i];

    dAux = -Double.MAX_VALUE;
    for (int i=0; i<Game.iNumActions; i++)
      if (dAux < dAvgPayoffAction[i]) {
        iBest = i;
        iNumBest = 1;							// Reseting the number of best actions
        dAux = dAvgPayoffAction[i];
        }
      else if (dAux == dAvgPayoffAction[i]) {
				iNumBest++;
				if (Math.random() < 1.0 / (double) iNumBest) {				// Select randomly with reducing probabilities
					iBest = i;
					dAux = dAvgPayoffAction[i];
				}
      }

    if (dAvgPayoffAction[iAction] == dAvgPayoffAction[iBest])		// If the action performed is among the best ones, it is reinforced
      for (int i=0; i<Game.iNumActions; i++)
        if (i == iAction)
          dProbAction[i] = dProbAction[i] + Game.dLearnRate * (1.0 - dProbAction[i]);	// Reinforce this
        else
          dProbAction[i] = (1.0 - Game.dLearnRate) * dProbAction[i];					// The rest are weakened
    }	// if (bAllActions)

/*
  if ( (iBest > -1) && (Math.random() > dEpsilon) )	// Use e-greedy policy to select the best or randomly any from the others
	iNewAction = iBest;
  else do {
	iNewAction = (int) (Math.random() * (double) Game.iNumActions);
  } while (iNewAction == iBest);
*/
  
  double dValAcc = 0;
  double dValRandom = Math.random();
  for (int i=0; i<Game.iNumActions; i++) {
		dValAcc += dProbAction[i];
		if (dValRandom < dValAcc) {
		  iNewAction = i;
		  break;
		}
  }
  
  dLearnRate *= Game.dDecFactor;		// Reducing the learning rate
  if (dLearnRate < Game.dMINLearnRate)
  	dLearnRate = Game.dMINLearnRate;
  
/*
  if (sIdCell.equals("0,0")) {
	System.out.println ("\n\nEpsilon: "+dEpsilon+"   dLearnRate: "+dLearnRate+
						"   iBest: "+iBest+"   iAction: "+iAction+"   iNewAction: "+iNewAction);
	for (int i=0; i<Game.iNumActions; i++)
	  System.out.println ("Action: "+i+"  iNumTimesAction: "+iNumTimesAction[i]+"   dAvgPayoffAction: "+dAvgPayoffAction[i]+
			  			  "   dProbAction: "+dProbAction[i]);
  }
*/
}





/**
 * This method uses Learning Automata (LA) to select a new action depending on the
 * past experiences on every state. The algorithm works as: store, adjust and generate.
 */
public void vGetNewActionAutomata (String sState, int iNActions, double dFunEval) {
  boolean bFound;
  StateAction oStateProbs;
 
  if (oMapStateActions.containsKey (sState)) {		// Searching if we already have the state
    oPresentStateAction = oMapStateActions.get (sState);
  } else {    																		// If not we add it
    oPresentStateAction = new StateAction (sState, iNActions, true);
    oMapStateActions.put (sState, oPresentStateAction);
  }
  
/*  
  bFound = false;														// Searching if we already have the state
  for (int i=0; i<oVStateActions.size(); i++) {
	oStateProbs = (StateAction) oVStateActions.elementAt(i);
    if (oStateProbs.sState.equals (sState)) {
      oPresentStateAction = oStateProbs;
      bFound = true;
      break;
    }
  }

  if (!bFound) {														// If we do not have it, we add it
    oPresentStateAction = new StateAction (sState, iNActions, true);
    oVStateActions.add (oPresentStateAction);
  }
*/
  
  
  if (oLastStateAction != null) {              			// Adjusting Probabilities
    if (dFunEval - dLastFunEval > 0)								// If reward grows and the previous action was allowed --> reinforce that action
      for (int i=0; i<iNActions; i++)
        if (i == iAction)
          oLastStateAction.dValAction[i] += dLearnRate * (1.0 - oLastStateAction.dValAction[i]);	// Reinforce the last action
        else
          oLastStateAction.dValAction[i] *= (1.0 - dLearnRate);		// The rest are weakened
  }
  
  double dValAcc = 0;
  double dValRandom = Math.random();
  for (int i=0; i<iNActions; i++) {
		dValAcc += oPresentStateAction.dValAction[i];
		if (dValRandom < dValAcc) {
		  iNewAction = i;
		  break;
		}
  }

  oLastStateAction = oPresentStateAction;
  dLastFunEval = dFunEval;
  dLearnRate *= Game.dDecFactor;									// Reducing the learning rate
  if (dLearnRate < Game.dMINLearnRate)
  	dLearnRate = Game.dMINLearnRate;
}






/**
  * This method uses Learning Automata (LA) to select a new action depending on the
  * neighborhood actions but without states. The algorithm works as: store, adjust and generate.
  * 
  *   @param bBest indicates if it is the best action in the neighborhood
  */
public void vGetNewActionSimpleAutomata (boolean bBest) {

	// Check that all actions have been already tried
  if (!bAllActions) {
    bAllActions = true;
    for (int i=0; i<Game.iNumActions; i++)
      if (iNumTimesAction[i] == 0) {
        bAllActions = false;
        break;
      }
  }

  // If all actions have been tried, adjust the probabilities of the automata
  else if (bBest)		// If the action performed was the best in the neighborhood, it is reinforced
  	if (dProbAction[iAction] < 0.95)									// We limit the maximum value
	    for (int i=0; i<Game.iNumActions; i++)
	      if (i == iAction)
	        dProbAction[i] = dProbAction[i] + Game.dLearnRate * (1.0 - dProbAction[i]);	// Reinforce this
	      else
	        dProbAction[i] = (1.0 - Game.dLearnRate) * dProbAction[i];					// The rest are weakened

  
  double dValAcc = 0;
  double dValRandom = Math.random();
  for (int i=0; i<Game.iNumActions; i++) {
		dValAcc += dProbAction[i];
		if (dValRandom < dValAcc) {
		  iNewAction = i;
		  break;
		}
  }
  
  dLearnRate *= Game.dDecFactor;		// Reducing the learning rate
  if (dLearnRate < Game.dMINLearnRate)
  	dLearnRate = Game.dMINLearnRate;
  
/*
  if (sIdCell.equals("0,0")) {
	System.out.println ("\n\nEpsilon: "+dEpsilon+"   dLearnRate: "+dLearnRate+
						"   iBest: "+iBest+"   iAction: "+iAction+"   iNewAction: "+iNewAction);
	for (int i=0; i<Game.iNumActions; i++)
	  System.out.println ("Action: "+i+"  iNumTimesAction: "+iNumTimesAction[i]+"   dAvgPayoffAction: "+dAvgPayoffAction[i]+
			  			  "   dProbAction: "+dProbAction[i]);
  }
*/
}




/**
  * This method is used to implement Q-Learning:
  *  1. I start with the last action a, the previous state s and find the actual state s'
  *  2. Select the new action with Qmax{a'}
  *  3. Adjust:   Q(s,a) = Q(s,a) + Game.dLearnRate [R + dGamma . Qmax{a'}(s',a') - Q(s,a)]
  *  4. Select the new action by a epsilon-greedy methodology
  *
  *	@param sState contains the present state
  * @param iNActions contains the number of actions that can be applied in this state
  * @param dFunEval is the new value of the function to evaluate (depend on the games). This value 
  * 	   minus last value determines the reward to be used.
  */
public void vGetNewActionQLearning (String sState, int iNActions, double dFunEval) {
  int iBest=-1, iNumBest=1;
  double dR, dQmax;
 
  if (oMapStateActions.containsKey (sState)) {		// Searching if we already have the state
    oPresentStateAction = oMapStateActions.get (sState);
  } else {    																		// If not we add it
    oPresentStateAction = new StateAction (sState, iNActions, true);
    oMapStateActions.put (sState, oPresentStateAction);
  }

  dQmax = 0;
  for (int i=0; i<iNActions; i++) {									// Determining the action to get Qmax{a'}
    if (oPresentStateAction.dValAction[i] > dQmax) {
      iBest = i;
      iNumBest = 1;													// Reseting the number of best actions
      dQmax = oPresentStateAction.dValAction[i];
    }
    else if ( (oPresentStateAction.dValAction[i] == dQmax) && (dQmax > 0) ) {
      iNumBest++;
      if (Math.random() < 1.0 / (double) iNumBest) {				// If equal, choose randomly with reducing probabilities
        iBest = i;
    	dQmax = oPresentStateAction.dValAction[i]; 
      }
    }
  }
              														// Adjusting Q(s,a)
  if (oLastStateAction != null) {
    dR = dFunEval - dLastFunEval;
    if (dR > 0)												// If reward grows and the previous action was allowed --> reinforce that action
      oLastStateAction.dValAction[iAction] +=  dLearnRate * (dR + dGamma * dQmax - oLastStateAction.dValAction[iAction]);
  }

  if ( (iBest > -1) && (Math.random() > dEpsilon) ) 		// Using the e-greedy policy to select the best action or any of the rest
    iNewAction = iBest;
  else do {
    iNewAction = (int) (Math.random() * (double) Game.iNumActions);
  } while (iNewAction == iBest);
 
  oLastStateAction = oPresentStateAction;
  dLastFunEval = dFunEval;
  
  dLearnRate *= Game.dDecFactor;		// Reducing the learning rate
  if (dLearnRate < Game.dMINLearnRate)
  	dLearnRate = Game.dMINLearnRate;
  
  dEpsilon *= Game.dDecFactor;			// Reducing the value of epsilon
  if (dEpsilon < Game.dMINepsGreedy)
  	dEpsilon = Game.dMINepsGreedy;		// Keeping a minimum value to allow exploration
}




/**
 * This method reinforces the buffer trace, after a success, in LA.
 */

public void vReinforceTraceLA () {
  int iActionAux;
  Integer oInt;
  StateAction oSA;
  
  for (int j=0; j<oVBufferStateActions.size(); j++) {
	oSA = (StateAction) oVBufferStateActions.elementAt(j);
	oInt = (Integer) oVBufferActions.elementAt(j);
	iActionAux = oInt.intValue();
  for (int i=0; i<oSA.dValAction.length; i++)
    if (i == iActionAux)
      oSA.dValAction[i] += (1.0 - oSA.dValAction[i]) * dLearnRate * j / Game.iStatsBufferSize;	// Reinforce the actions with a discount factor (Game.iStatsBufferSize)
    else
      oSA.dValAction[i] *= (1.0 - dLearnRate * j / Game.iStatsBufferSize);						// The rest are weakened
  }
}



/**
 * This method updates two buffers of StateActions and the Action performed
 */
public void vAddBufferStateActions() {
  oVBufferStateActions.add (oPresentStateAction);
  while (oVBufferStateActions.size() > Game.iStatsBufferSize)
  	oVBufferStateActions.removeElementAt (0);
  
  oVBufferActions.add (iAction);
  while (oVBufferActions.size() > Game.iStatsBufferSize)
  	oVBufferActions.removeElementAt (0);
}



public void vResetParameters () {
  dLearnRate = Game.dLearnRate;
  dEpsilon = Game.depsGreedy;
}


public double dGetLearningRate() {
  return dLearnRate;
}


public double dGetEpsilon() {
  return dEpsilon;
}

public StateAction oGetLastStateAction () {
  return oLastStateAction;
}




/**
 * This method is used to output data to Pajek/Gephi depending on the games
 */
public double dGetOutput4ExternalTool () {
  return dPayoff;
}


}	// from the class Cell


