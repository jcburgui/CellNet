package games.satBall;

import window.MainWindow;
import window.DlGraphics;
import window.WindowCons;
import games.Cell;
import games.Game;

import java.util.Vector;


/**
* This class implements the Sat Ball games
* 
* Enviar a: 1) JOURNAL OF SPORT SCIENCES, 2) EUROPEAN JOURNAL OF SPORT SCIENCES
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class GameSatBall extends Game implements WindowCons
{
private Cell oCellBall = null;
private boolean bTeamWinner = false;
private int iNumPlayersTeam = 3;
private int iNumColors = 4;
private int iShotDelay = 5;
private int iMaxDist4State = 2;			// Max. distance for a cell in a direction (reduce states during learning).
private double dMAXDist = Math.sqrt(iCellH*iCellH + iCellV*iCellV) / 2;		// Max. distance is diagonal / 2
private int[][] imCellMove;
private int[] imTeamWins = new int[iNumColors];

public static int iShotDelayMin = 4;	// Min. clock ticks to shot the ball
public static int iShotDelayMax = 7;	// Max. clock ticks to shot the ball
public static double dPsucc = 0.5;		// Probability of success
public static double dPcap= 0.1;		// Prob. of capturing the ball before it touches the floor or after touching the floor.
public static double dPrec = 0.3;		// Prob. of recovering the ball after touching the floor by another player (eliminated have dPrec/2).



/**
 * This is the class constructor for bCellNet executions
 *
 */
public GameSatBall () {
  super();
  
  iNumActions = 5;						// 4 possible movements around the cell and no move 0
  iNumTypes = 3;			  			// (0) Dead, (1) Alive or (2) Ball
  iTotNumCells = iNumPlayersTeam * iNumColors;
  iTotPosMatrix = 400;														// Initial number of cells in the matrix
  
  imCellMove = new int[iNumActions][2];	// Moving displacements around a cell
  imCellMove[0][0] = 0;	// Don't move
  imCellMove[0][1] = 0; // Don't move
  imCellMove[1][0] = 0;	// N.x
  imCellMove[1][1] = 1;	// N.y
  imCellMove[2][0] = 1;	// E.x
  imCellMove[2][1] = 0;	// E.y
  imCellMove[3][0] = 0;	// S.x
  imCellMove[3][1] =-1;	// S.y
  imCellMove[4][0] =-1;	// W.x
  imCellMove[4][1] = 0;	// W.y
}


/**
 * This is the class constructor for window executions
 *
 */
public GameSatBall (MainWindow oVentAux) {
  this();

  oMainWindow = oVentAux;
  
  oVTextCellType = new Vector (1,1);
  oVTextCellType.add ("D");						// Dead Players (black in graphics)
  oVTextCellType.add ("A");						// Alive Players (green in graphics)
  
  oVTextAction = new Vector (1,1);
  oVTextAction.add ("Fixed");					// White cells
  oVTextAction.add ("QL");						// Yellow cells
  oVTextAction.add ("LA");						// Green cells
  oVTextAction.add ("LA+TR");					// Cyan cells

  MainWindow.oMIWindow[iFREQxACTION].setEnabled (true);

}

/**
  * This method resets the games when pressing "New".
  *
  */
public void vNewGame() {
	
  if (iNewGame == 0) {
    super.vNewGame();
	  
    iNumActions = 5;						// 4 possible movements around the cell and no move 0
    iNumTypes = 3;			  			// (0) Dead, (1) Alive or (2) Ball
    iTotNumCells = iNumPlayersTeam * iNumColors;
	  
    int iAction = 0, iTipoCell, x, y;
    oVectorCells = new Vector (1,1);
	  
    for (int i=0; i<iTotNumCells; i++) {
	  do {
	    x = (int) (Math.random() * (double) iCellH);
	    y = (int) (Math.random() * (double) iCellV);
	  } while (oCellMatrix[x][y] != null);
		
	  if (i==0)
	    iTipoCell = 2;			// Cell with the ball
	  else
	    iTipoCell = 1;			// Alive cell
	
	  imCellsType[iTipoCell]++;
	  imCellsAction[iAction]++;
	  oCellMatrix[x][y] = new Cell (x, y, iTipoCell, iAction);
	  if (iTipoCell == 2)
	    oCellBall = oCellMatrix[x][y];
	    
	  		// White cells (0, fixed strategies), Yellow cells (1, QL), Green cells (2, LA), Cyan cells (3, LA+TR)
	  oCellMatrix[x][y].vSetColor (i % iNumColors);
	    	
	  oVectorCells.add (oCellMatrix[x][y]);
    }
    
  if (MainWindow.iBatchMode < 2) {			// OJO: No va porque ya no uso acciones
    MainWindow.omDlGraf[iFREQxACTION] = new DlGraphics (oMainWindow, " CellNet: Alive cells x Team", false, iFREQxACTION);
    MainWindow.omDlGraf[iFREQxACTION].setVisible (true);
  }

  }
  
  else for (int i=0; i<oVectorCells.size(); i++) {		// Cells are not reinitialized to avoid loosing their memories.
	Cell oCell = (Cell) oVectorCells.elementAt(i);
	oCell.vResetParameters ();							// Restarting the learning rate and epsilon to the original values (for learning)
	if (oCell.iGetCellType() == 0)
	  oCell.vSetCellType (1);
  }
  
  bTeamWinner = false;
  sTextStateBar = "NGen: "+iNumGen +"  Death: "+imCellsAction[0] +"  Alive: "+ (imCellsAction[1]+imCellsAction[2]) +
		  	  "   Cel: "+iTotNumCells +"   N: "+iTotPosMatrix;
  
  iNewGame++; 
}



public void vMatrixReloaded () {
  iShotDelay = 5;
  
  oVectorCells = new Vector (1,1);
  for (int x=0; x<iCellH; x++)
    for (int y=0; y<iCellV; y++)
	  if (oCellMatrix[x][y] != null) {
		oVectorCells.add(oCellMatrix[x][y]);
	    if (oCellMatrix[x][y].iGetCellType() == 2)
		  oCellBall = oCellMatrix[x][y];
      }
}



/**
  * This method contains the code to be executed as a thread
  */
public void vRunLoop() {
  Cell oCell;
  Vector oVect;

  iNumGen++;                                    // Increasing the number of generations (games iterations)
  
  imCellsType = new int [iNumTypes];			// Reset
  
  iNumChanges = 0;
  if (iShotDelay <= 0)
	vExecAction (oCellBall);
  else for (int i=0; i<oVectorCells.size(); i++)
    vExecAction ((Cell) oVectorCells.elementAt(i));
  
  if (bTeamWinner){			// The games ends when there is only one team alive
	//MainWindow.iGenStopTMP = iNumGen;
    for (int i=0; i<oVectorCells.size(); i++) {
	  oCell = (Cell) oVectorCells.elementAt (i);
	  if (oCell.iGetCellType() > 0) {
	    imTeamWins[oCell.iGetColor()]++;
	    break;
	  }
	}
    System.out.print("\nHall of Fame:    iNumGen:"+iNumGen);
    for (int i=0; i<iNumColors; i++)
      switch (i) {
    	case 0:   System.out.print("   Fixed Team:"+imTeamWins[i]); break;
    	case 1:   System.out.print("   QL Team:"+imTeamWins[i]); break;
    	case 2:   System.out.print("   LA Team:"+imTeamWins[i]); break;
    	case 3:   System.out.print("   LA Trace Team:"+imTeamWins[i]); break;
      }
	//return;
    vNewGame();
  }
  
  for (int i=0; i<oVectorCells.size(); i++) {
	oCell = (Cell) oVectorCells.elementAt (i);
	imCellsType[oCell.iGetCellType()]++;
  }

  oVect = (Vector) oVFrecTypes.elementAt (0);
  oVect.add (new Integer(100 * imCellsType[0]/iTotNumCells));                    	// Storing dead cells
  while (oVect.size() > MainWindow.iLastNGen)
  	oVect.removeElementAt (0);
  oVect = (Vector) oVFrecTypes.elementAt (1);
  oVect.add (new Integer(100 * (imCellsType[1]+imCellsType[2])/iTotNumCells));		// Storing alive cells
  while (oVect.size() > MainWindow.iLastNGen)
  	oVect.removeElementAt (0);

  vSetGraphicValues();
  sTextStateBar = "NGen: "+iNumGen +"  Death: "+imCellsType[0] +"  Alive: "+ (imCellsType[1]+imCellsType[2]) +"   Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
}		// vRunLoop()



/**
  * This method executes and action depending on the cell type: with or without the ball
  *
  *	@param oCell is the cell that will perform the action
  */
private void vExecAction (Cell oCell) {
  int x, y, xPel, yPel, xAux, yAux, xNew, yNew;
  int iTypeAux, iActionAux, iColorAux;
  int iDistX, iDistY;
  double dFunEval, dDist, dNewDist, dDistMin=Double.MAX_VALUE;
  String sState = new String("");
  Cell oCellAux=null, oCellDistMin=null;
  Vector oVVec;
  
  iTypeAux = oCell.iGetCellType ();
  iColorAux = oCell.iGetColor();
  x = oCell.iGetPosX();
  y = oCell.iGetPosY();
  
  
  if (iTypeAux == 2) {
	if (iShotDelay > 0)			// Cell with the ball, while the counter does not reach zero it is only decremented
	  iShotDelay--;
	else {
	  for (int i=0; i<oVectorCells.size(); i++) {				// Calculating the distance to the nearest one.
	    oCellAux = (Cell) oVectorCells.elementAt(i);
		if ( (oCell == oCellAux) || (oCellAux.iGetCellType() == 0) || (oCellAux.iGetColor() == iColorAux) ) continue;
		xAux = oCellAux.iGetPosX();
		yAux = oCellAux.iGetPosY();
		dDist = dCalcDistance (oCell, oCellAux);
		if (dDist < dDistMin) {
		  dDistMin = dDist;
		  oCellDistMin = oCellAux;
		}
	  }
	  if (oCellDistMin != null)
	    vBallLaunching (oCellDistMin);
	  else {
		bTeamWinner = true;
		return;
	  }
		  
	}
  }
	  
  else if (iTypeAux == 1)		// Alive without ball, try to avoid the ball and other cells
	switch (oCell.iGetColor()) {
		case 1:								// Color 1 uses Q-Learning
		case 2:								// Color 2 uses Learning Automata
		case 3:								// Color 3 uses Learning Automata with reinforced trace
		  iDistX = oCell.iGetPosX() - oCellBall.iGetPosX();
		  iDistY = oCell.iGetPosY() - oCellBall.iGetPosY();
		  if (Math.abs(iDistX) > iMaxDist4State) iDistX = iMaxDist4State * iDistX / Math.abs(iDistX);
		  if (Math.abs(iDistY) > iMaxDist4State) iDistY = iMaxDist4State * iDistY / Math.abs(iDistY);
		  sState += iDistX + "," + iDistY;			// Encoding distance to ball

		  oVVec = oVOrderbyDistance (oCell);
		  for (int i=0; i<oVVec.size(); i++) {
		    oCellAux = (Cell) oVVec.elementAt(i);	// Avoiding ball, dead players and same team
		    if ( (oCellAux.iGetCellType() != 1) || (oCellAux.iGetColor() == iColorAux) ) continue;
	        iDistX = oCell.iGetPosX() - oCellAux.iGetPosX();
			iDistY = oCell.iGetPosY() - oCellAux.iGetPosY();
			if (Math.abs(iDistX) > iMaxDist4State) iDistX = iMaxDist4State * iDistX / Math.abs(iDistX);
			if (Math.abs(iDistY) > iMaxDist4State) iDistY = iMaxDist4State * iDistY / Math.abs(iDistY);
			sState += "|" + iDistX + "," + iDistY;							// Encoding distance to nearest enemy alive
			break;
		  }

		  dFunEval = dCalcDistance (oCellBall, oCell) + 0.5 * dCalcDistance (oCellAux, oCell);
	
		  switch (oCell.iGetColor()) {
		    case 1: oCell.vGetNewActionQLearning (sState, iNumActions, dFunEval); break;	// Calling QLearning and sending state and evaluation
		    case 2:
		    case 3: oCell.vGetNewActionAutomata (sState, iNumActions, dFunEval); break;		// Calling Learning Automata and sending state and evaluation
		  }
		  
		  iActionAux = oCell.iGetNewAction();
		  xNew = x + imCellMove[iActionAux][0];
		  yNew = y + imCellMove[iActionAux][1];
		  if (xNew < 0) xNew = 0;
		  if (xNew > (iCellH-1)) xNew = iCellH - 1;
		  if (yNew < 0) yNew = 0;
		  if (yNew > (iCellV-1)) yNew = iCellV - 1;
		  if (oCellMatrix[xNew][yNew] == null) {				// If not empty then selects randomly below
			oCellMatrix[xNew][yNew] = oCellMatrix[x][y];
			oCellMatrix[x][y] = null;
			oCell.vSetNewPos(xNew, yNew);
			oCell.vUpdateAction();
		    break;
		  }

		default:												// Color 0: Fixed ad-hoc strategy
		  oCell.vSetAction(0);									// It does not move by defect
		  for (int i=0; i<5; i++) {								// Alive without ball, has 5 random attempts to move
		    xPel = oCellBall.iGetPosX();
			yPel = oCellBall.iGetPosY();
			dDist = dCalcDistance (oCellBall, oCell);
			iActionAux = (int) ((double) iNumActions * Math.random());
			xNew = x + imCellMove[iActionAux][0];
			yNew = y + imCellMove[iActionAux][1];
			if (xNew < 0) xNew = 0;
			if (xNew > (iCellH-1)) xNew = iCellH - 1;
			if (yNew < 0) yNew = 0;
			if (yNew > (iCellV-1)) yNew = iCellV - 1;
			dNewDist = dCalcDistance (xPel, yPel, xNew, yNew);
			if ( (dNewDist >= dDist) & (oCellMatrix[xNew][yNew] == null) ) {	// Escaping from the ball to an empty cell
			  oCellMatrix[xNew][yNew] = oCellMatrix[x][y];
			  oCellMatrix[x][y] = null;
			  oCell.vSetNewPos(xNew, yNew);
			  oCell.vSetAction(iActionAux);
			  break;
			}
		  }
		
		if (oCellBall.iGetColor() == 3)						// Color 3 (cyan) uses the trace reinforcement when success
		  oCell.vAddBufferStateActions ();
	}
  
}	// from vExecAction (Cell oCell)




/**
  * This method consider what happens when the ball is shot
  * 
  * @param oCellDistMin is the target cell.
  *
  */
private void vBallLaunching (Cell oCellDistMin) {
  double dPrecAux;
  double dDist = dCalcDistance (oCellBall, oCellDistMin);
  Cell oCell=null;
  Vector oVec=null;

  oCellBall.vSetCellType(1);							// The cell with the ball releases it
 
  if (Math.random() < dPsucc - 0.25*dDist/dMAXDist) {  	// Success depends on distance
    oCellDistMin.vSetCellType(0);						// Eliminated
    if (oCellBall.iGetColor() == 3)
      oCellBall.vReinforceTraceLA();					// Reinforcing the last actions (iStatsBufferSize) of the cell ball that eliminated the other one.
  }
  else if (Math.random() < dPcap * dDist/dMAXDist)		// The target captures the ball as a function of the distance
	oCell = oCellDistMin;								// Captured

  if (oCell == null) {									// The ball is free and it is recovered by anybody depending on distance
	boolean bCapcha = false;							// Ordered depending on the distance to the target and selected by prob. dPrec
	oVec = oVOrderbyDistance (oCellDistMin);
	for (int i=0; i<oVec.size(); i++) {
	  oCell = (Cell) oVec.elementAt (i);
	  dPrecAux = dPrec;
	  if (oCell.iGetCellType() == 0)						// Dead cells have half probability of recovering a ball
		dPrecAux *= 0.5;
	  if (Math.random() < dPrecAux) {
		bCapcha = true;
		break;
	  }
	}
	
	if (!bCapcha) {										// If nobody got the ball depending on distance, then assigned by random
      int iSel = (int) (oVectorCells.size() * Math.random());
      oCell = (Cell) oVectorCells.elementAt(iSel);
	}

  } 
  
  oCell.vSetCellType(2);									// The new CellBall is updated
  oCellBall = oCell;
 
  iShotDelay = (int) (iShotDelayMin + Math.random() * (iShotDelayMax - iShotDelayMin));		// Reset a new shot trigger
}


/**
 * This method orders from closer to longer the other cells depending on the distance.
 * 
 * @param oCell is the origin of distances.
 *
 */
private Vector oVOrderbyDistance (Cell oCell) {
  boolean bInserted;
  double dDist, dDistAux;
  Double oDouble;
  Cell oCellAux;
  Vector oVDist = new Vector (1,1);
  Vector oVVec = new Vector (1,1);
  
  for (int i=0; i<oVectorCells.size(); i++) {					// Looping over all the cells
	oCellAux = (Cell) oVectorCells.elementAt(i);
	if (oCellAux == oCell) continue;							// Avoiding the origin of distances

    dDist = dCalcDistance (oCell.iGetPosX(), oCell.iGetPosY(), oCellAux.iGetPosX(), oCellAux.iGetPosY());
	
	bInserted = false;
	for (int j=0; j<oVVec.size(); j++) {						// Looping over the cells already inserted
	  oDouble = (Double) oVDist.elementAt(j);
	  dDistAux = oDouble.doubleValue();
	  if (dDist < dDistAux) {									// If the distance is lower, insert new one here
		oVDist.add(j, dDist);
		oVVec.add(j, oCellAux);
		bInserted = true;
		break;
	  }
	}
	
    if (!bInserted) {											// If it was not inserted before, add it here to the end of the list 
	  oVDist.add(dDist);
      oVVec.add(oCellAux);  
    }
    
  }		// Loop over the whole set of Cells
  
  return oVVec;
}




/**
 * States the basic graphic values for this games
 */
protected void vSetGraphicValues() {
  int[] imAliveCellsColor = new int[iNumColors];
  Cell oCell;
  Vector oVect;
	  
  for (int i=0; i<oVectorCells.size(); i++) {
	oCell = (Cell) oVectorCells.elementAt(i);
	if (oCell.iGetCellType() != 0)
	  imAliveCellsColor[oCell.iGetColor()]++;
  }
  
  for (int i=0; i<iNumColors; i++) {
	oVect = (Vector) oVFrecActions.elementAt (i);
	oVect.add (new Integer(100 * imAliveCellsColor[i] / iNumPlayersTeam));
	while (oVect.size() > MainWindow.iLastNGen)
	  oVect.removeElementAt (0);
  }

}



}	// from GameSatBall class
