package games.satBall;

import javax.swing.*;

import window.MainWindow;

import java.awt.*;
import java.awt.event.*;

import games.*;



/**
* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class DlgParamSatBall extends JDialog implements ActionListener, GameCons
{
private Label oLabel;
private JTextField  oTdPfail,
                    oTdPcap,
                    oTdPrec,
                    oTiTmin,
                    oTiTmax;
private MainWindow oMainWindow;



/**
 * This is the Dialog constructor
 *
 * @param	oPadre 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 */
public DlgParamSatBall (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);

  oMainWindow = (MainWindow) oParent;
  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(7,2));
  

  oLabel = new Label (" Prob. of success:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdPfail = new JTextField(String.valueOf(GameSatBall.dPsucc), 7);
  add (oTdPfail);

  oLabel = new Label (" Prob. of capture:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdPcap = new JTextField(String.valueOf(GameSatBall.dPcap), 7);
  add (oTdPcap);

  oLabel = new Label (" Prob. of recuperation:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdPrec = new JTextField(String.valueOf(GameSatBall.dPrec), 7);
  add (oTdPrec);

  oLabel = new Label (" Min. time to launch [1,10]:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTiTmin = new JTextField(String.valueOf(GameSatBall.iShotDelayMin), 7);
  add (oTiTmin);
  
  oLabel = new Label (" Max. time to launch [min,10]:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTiTmax = new JTextField(String.valueOf(GameSatBall.iShotDelayMax), 7);
  add (oTiTmax);
  
  add (new Label (""));
  add (new Label (""));

  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(500,400));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {
	GameSatBall.dPsucc = Double.parseDouble (oTdPfail.getText());
	GameSatBall.dPcap = Double.parseDouble (oTdPcap.getText());
	GameSatBall.dPrec = Double.parseDouble (oTdPrec.getText());
	GameSatBall.iShotDelayMin = Integer.parseInt (oTiTmin.getText());
	GameSatBall.iShotDelayMax = Integer.parseInt (oTiTmax.getText());
    }

  dispose();
}

}	// from the class
