package games;

import java.util.Vector;


public class CellCoa extends Cell
{
protected CellCoa oLeader;                                     						// If Leader == null, but with Leader -> ref. to Cell
protected int iCompromiseWithLeader;
protected double dTax=Game.dLeaderTax;
protected Vector<Integer> ovCompromiseWithNeighbors;
protected Vector<CellCoa> oVHolonParts = new Vector<CellCoa> (1,1);       // Contains the other cells that conform this holon


public CellCoa (int x, int y, int iCellTypeAux, int iActionAux) {
  super (x, y, iCellTypeAux, iActionAux);
  
  oLeader = null;            														// Initially cells have no leader
  if (Game.bRandomTaxes)
    dTax = Math.random();
  
  if (Game.iChangeType == Game.iMETA_STRAT) {
	int iAux = (int) (Math.random() * (double) Game.iMaxStrategies);
	if (iAux == 0)
	  iStrategyType = Game.iIMITATION;
	else
	  iStrategyType = Game.iLEARNING;
  }
}

public void vSetNeighbors (Vector oVec) {
  super.vSetNeighbors (oVec);
  if (Game.iGameType == Game.iCOA_IPD) {
    ovCompromiseWithNeighbors = new Vector<Integer> (1,1);
    for (int i=0; i<ovNeighbors.size(); i++)
      ovCompromiseWithNeighbors.add (new Integer (0));
  }
}

public int iGetCompromiseWithNeighbor (int iNumNeighbor) {
  Integer oInt = ovCompromiseWithNeighbors.elementAt (iNumNeighbor);
  return oInt.intValue();
  }

public void vChangeCompromiseWithNeighbor (int iNumNeighbor, int iVarCompromise) {
  int iAux;
  Integer oInt = ovCompromiseWithNeighbors.elementAt (iNumNeighbor);

  iAux = oInt.intValue();
  iAux += iVarCompromise;
  if (iAux < 0) iAux = 0;
  if (iAux > 100) iAux = 100;
  ovCompromiseWithNeighbors.setElementAt (new Integer (iAux), iNumNeighbor);
}

public void vSetCompromiseWithLeader (int iCompromise)
  {iCompromiseWithLeader = iCompromise;}

public void vChangeCompromiseWithLeader (int iVarCompromise) {
  iCompromiseWithLeader += iVarCompromise;
  if (iCompromiseWithLeader < 0) iCompromiseWithLeader = 0;
  if (iCompromiseWithLeader > 100) iCompromiseWithLeader = 100;
  }

public int iGetCompromiseWithLeader ()
  {return iCompromiseWithLeader;}

public boolean bIsLeader() {
  if (oVHolonParts.size() > 0) return true;
  else return false;
}

public boolean bIsCoaMember() {						// Hint: this method should be overwritten if oLeader is not used
  if (oLeader != null) return true;
  else return false;
  }

public boolean bIsIndependent() {					// Hint: this method should be overwritten if oLeader is not used
  if ( (oVHolonParts.size() == 0) && (oLeader == null) ) return true;
  else return false;
}

public CellCoa oGetLeader ()
  {return oLeader;}

  // This method is an extension of the previous one to return a pointer to itself if it is the leader
public CellCoa oRecGetLeader () {
	if (oVHolonParts.size() > 0)      // If it is the leader
	  return this;
	else
	  return oLeader;
}

public void vNewLeader (CellCoa oHolon)
  {oLeader = oHolon;}

public void vAddHolonPart (CellCoa oHolonPart)
  {oVHolonParts.addElement (oHolonPart);}

public void vRemoveHolonPart (CellCoa oHolonPart) {
  for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoa oHolon = oVHolonParts.elementAt(i);
    if (oHolon == oHolonPart)
      oVHolonParts.removeElementAt (i);
  }
}

public void vResetHolonParts() {
	oVHolonParts = new Vector<CellCoa> (1,1);
}

public Vector<CellCoa> oVGetHolonParts()
  {return oVHolonParts;}

public int iGetHolonSize ()
  {return (1 + oVHolonParts.size());}

public void vNewRandomTax()
  {dTax = Math.random();}

public double dGetTax()
  {return dTax;}

public void vSetTax (double dTaxAux)
	{dTax = dTaxAux;}

public void vAddPayoffs (double dIncomeAux, double dIncomeNeighborAux) {
  if ( (oLeader == null) || (dIncomeAux < 0) )
    dPayoff += dIncomeAux;
  else {
    dPayoff += dIncomeAux * (1 - oLeader.dGetTax());
    oLeader.vAddPayoffs (dIncomeAux * oLeader.dGetTax(), 0);
  }
  dPayoffNeighbors += dIncomeNeighborAux;
}

public boolean bChangeLeaderOK (CellCoa oLeaderOther, CellCoa oCellMax) {
  if (this == oLeaderOther)
     return false;
  else for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoa oHolon = oVHolonParts.elementAt(i);
    if (oCellMax == oHolon)
      return false;
  }
  
  return true;
}



}	// from the class


