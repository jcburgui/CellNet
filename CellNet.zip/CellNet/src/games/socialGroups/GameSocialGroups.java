package games.socialGroups;

import games.Cell;
import games.Game;
import games.Pos;

import java.util.Vector;

import window.MainWindow;

/**
* This class implements the Social Group Game
*
* @author  Juan C. Burguillo Rial
* @version 3.0
*/
public class GameSocialGroups extends Game
{
public static double dProbBlack = 0.75;

public GameSocialGroups() {
  iNumActions = 2;
  dProbEmpty = 0.65;
  bMovement = true;
  iTotPosMatrix = 400;														// Initial number of cells in the matrix

  oVTextAction = new Vector (1,1);
  oVTextAction.add ("B");						// It is the black one
  oVTextAction.add ("G");						// It is the green one
  for (int i=0; i<oVTextAction.size(); i++) {
    oVFrecActions.add (new Vector (1,1));
    oVFrecMov.add (new Vector (1,1));
    } 
  }

/**
  * This methods resets the games when pressing "New".
  *
  */
public void vNewGame() {
  super.vNewGame();

  String sId;
  int iTipoCell = 0;
  int iAction;

  for (int x=0; x<iCellH; x++)             	
    for (int y=0; y<iCellV; y++) { 
      if (Math.random() < dProbEmpty)
        oCellMatrix[x][y] = null;
      else {
        sId = new String ("Cell("+x+","+y+")");
/*
        dAux = Math.random();
        if (dAux < dFrecCelA)
                iTipoCell = 0;
        else if (dAux < (dFrecCelA + dFrecCelB))
                iTipoCell = 1;
        else
                iTipoCell = 2;                  // 3 types of cells
*/
        
        iAction=1;				// Green
        if (Math.random() < dProbBlack)
          iAction = 0;			// Black

        imCellsType[0]++;
        imCellsAction[iAction]++;
        iTotNumCells++;
        oCellMatrix[x][y] = new Cell (sId, iTipoCell, iAction);
        }
      }			

  sTextStateBar = "NGen: "+iNumGen +"  B: "+imCellsAction[0] +"  W: "+imCellsAction[1] +"   Cel: "+iTotNumCells +"   N: "+iTotPosMatrix;
  
  iNewGame++;
}






/**
  * This method contains the code to execute in the thread
  */
public void vRunLoop() {
  Vector oVect;

  iNumGen++;                                    // Increasing the number of generations (games iterations)
  
  imCellsAction = new int [iNumActions];			// Reset
  imMovAction = new int [iNumActions];
  
  iNumChanges = 0;
  for (int y=0; y<iCellV; y++)
    for (int x=0; x<iCellH; x++)						
    if (oCellMatrix[x][y] == null)
      continue;
    else
      vChangePosition (x,y);

  for (int y=0; y<iCellV; y++)
    for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
      continue;
    else
      oCellMatrix[x][y].vUpdateAction ();		// Updates synchronously the new actions

  oVect = (Vector) oVFrecMov.elementAt (0);
  oVect.add (new Integer(100 * imMovAction[0] / imCellsAction[0]));		// Storing the blacks
  oVect = (Vector) oVFrecMov.elementAt (1);
  oVect.add (new Integer(100 * imMovAction[1] / imCellsAction[1]));		// Storing the green ones

  sTextStateBar = "NGen: "+iNumGen +"  B: "+imCellsAction[0] +"  W: "+imCellsAction[1] +"   Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
  }		// de vEjecutaCiclo()



/**
  * This method updates a cell position
	*
	*	@param x  Horizontal position of the cell.
	*	@param y	Vertical position of the cell.
  */
private void vChangePosition (int x, int y) {
  int xAux, yAux;
  int iAction, iRadio = (int) dRadio;
  int iPos;
  float fIgual, fDistinto, fDenom;
  double dDist=0;
  Cell oCell = oCellMatrix[x][y];
  Vector oVPosVacias = new Vector();
  Pos oPos;

  fIgual = 0;
  fDistinto = 0;
  for (int v=-iRadio; v<=iRadio; v++)
    for (int h=-iRadio; h<=iRadio; h++) {
      dDist = Math.sqrt (h*h + v*v);
      if ( (dDist > dRadio) || (dDist == 0)) continue;
      xAux = x+h;
      yAux = y+v;

      if (xAux < 0)                                                   // Adjunting to a toroidal world
        xAux += iCellH;
      else if (xAux >= iCellH)
        xAux -= iCellH;

      if (yAux < 0)
        yAux += iCellV;
      else if (yAux >= iCellV)
        yAux -= iCellV;

      if (oCellMatrix[xAux][yAux] == null)                             // If it is an empty cell
        oVPosVacias.add (new Pos (xAux, yAux));
                                                                      // If it is a friend
      else if (oCell.iGetAction() == oCellMatrix[xAux][yAux].iGetAction())
        fIgual++;
      else
        fDistinto++;
      }

  fDenom = fIgual + fDistinto;
  if (fDenom > 0.0)
    fIgual = fIgual / (fDenom);						// Proportion of equals

  iAction = oCell.iGetAction();

  if ( ((iAction == 1) && (fIgual < 0.5)) ||		// It is the green one
       ((iAction == 0) && (fIgual < 0.33)) ) {		// It is the black one
	  
    if (oVPosVacias.size() == 0) {                  // If it can not move, perhaps mutates
      if (Math.random() < dProbMut) {               // If surrounded and happens a mutation then changes action
        iAction = (int) (2.0 * Math.random());
        oCell.vSetNewAction (iAction);
        }
      }

    else {                                                               // If it can move, tries it
      iPos = (int) (Math.random() * (double) oVPosVacias.size());
      oPos = (Pos) oVPosVacias.elementAt(iPos);
      oCellMatrix[oPos.x][oPos.y] = oCell;
      oCellMatrix[x][y] = null;
      imMovAction[iAction]++;
      iNumChanges++;
      }
    
    }	

  imCellsAction[iAction]++;

                                                  // If it has changed action
  if (oCell.iGetNewAction() != oCell.iGetAction())
    iNumChanges++;
  }	// from the method


}// from the class GameSocialGroups
