package games.coaIPD;

import games.CellCoa;
import games.Game;

import java.util.Vector;

import window.DlGraphics;
import window.MainWindow;
import window.WindowCons;


/**
 * This class implements the Iterated Prisoner's Dilemma with Coalitions. Strategies:
 *		- Cooperator (C)
 *		- Defector (D)
 *		- Pavlov, WSLS (P): cooperates at the beginning and when the other chooses the same as me in the previous round
 *		- TFT (T): cooperates at the beginning and imitates the action done by the other in the previous round
 *
 * @author  Juan C. Burguillo Rial
 * @version 1.0
 */
public class GameCoaIPD extends Game implements WindowCons
{
public static CellCoa[][] oCellMatrix = new CellCoa [iCellH][iCellV];


/**
  * This is the class constructor
  *
  */
public GameCoaIPD () {
  super();
  
  iNumActions = 3;                              	// 3 options: Independent (IC), Coalition (CC) or Leader (LC)
  iVisorShow = 0;
  
  iTotPosMatrix = 1600;														// Initial number of cells in the matrix
}



/**
  * This is the class constructor
  *
  */
public GameCoaIPD (MainWindow oVentAux) {
  this();

  oMainWindow = oVentAux;
            // Initializing the payoff matrix [with T>R>P>S and 2R > S+T]
  dPayMatrix[0][0][0] = 1.0; // dP=0.5;
  dPayMatrix[0][1][0] = 5.0; // dT=3.5;
  dPayMatrix[1][0][0] = 0.0; // dS=0.0;
  dPayMatrix[1][1][0] = 3.0; // dR=3.0;

  dPayMatrix[0][0][1] = 1.0; // dP=0.5;
  dPayMatrix[0][1][1] = 0.0; // dS=0.0;
  dPayMatrix[1][0][1] = 5.0; // dT=3.5;
  dPayMatrix[1][1][1] = 3.0; // dR=3.0;
  
  iMaxStrategies = 2;  
}





/**
  * This method sets up the games when we press "New".
  *
  */
public void vNewGame() {
  super.vNewGame();

  Game.oCellMatrix = null;
  oCellMatrix = new CellCoa [Game.iCellH][Game.iCellV];

  int iTipoCell = 0;
  int iAction;

  ovAvgTaxCoaCell = new Vector (1,1);          	// Average tax per coalition cell
  
  imCellsAction = new int [iNumTypes];			// The actions are: D, C or Coa.
  oVProfitAction = new Vector<Vector> (1,1);
  oVFrecActions = new Vector<Vector> (1,1);
  for (int i=0; i<iNumTypes; i++) {
	oVFrecActions.add (new Vector (1,1));
	oVProfitAction.add (new Vector (1,1));
  }

  oVTextAction = new Vector (1,1);
  oVTextAction.add ("D");						// D == 0, Defectors
  oVTextAction.add ("C");						// C == 1, Cooperators
  oVTextAction.add ("G");						// G, Groups

  for (int x=0; x<iCellH; x++)
  for (int y=0; y<iCellV; y++) {
    if (dProbEmpty > 0.0)
      if (dProbEmpty > Math.random()) {
        oCellMatrix[x][y] = null;				// null for empty cells
        continue;
      }

    iAction = (int) (2.0 * Math.random());		// The two real initial actions are C and D
    imCellsType[0]++;
    imCellsAction[iAction]++;
    oCellMatrix[x][y] = new CellCoa (x, y, iTipoCell, iAction);
    iTotNumCells++;
  }

  Game.oCellMatrix = oCellMatrix;
  oVectorCells = ovCells2Vector (oCellMatrix);
  vSetNeighborsSpatialRadio (oCellMatrix);

  for (int i =0; i<iNumCellRec; i++) {
    int x = (int) ( (double) iCellH * Math.random());
    int y = (int) ( (double) iCellV * Math.random());
    if (oCellMatrix[x][y] != null) {
      oCellMatrix[x][y].vAddPayoffGen (1.0);
      Vector ovNeighbors = oCellMatrix[x][y].oVGetNeighbors();
      for (int j=0; j<ovNeighbors.size(); j++) {
        CellCoa oCell = (CellCoa) ovNeighbors.elementAt(j);
        oCell.vAddPayoffGen (0.5);
      }
    }
  }

  if ( (iNewGame == 0) && (MainWindow.iBatchMode < 2) ) {
	  
  	MainWindow.oMIPayMatrix.setEnabled (true);

    for (int i=3; i<=10; i++)
      MainWindow.oMIWindow[i].setEnabled (true);
    
    if (MainWindow.iBatchMode == 0) {
      MainWindow.omDlGraf[iGLOBAL_PROFIT] = new DlGraphics (oMainWindow, " CellNet: Global Profit", false, iGLOBAL_PROFIT);
      MainWindow.omDlGraf[iGLOBAL_PROFIT].setVisible(true);
      MainWindow.omDlGraf[iPROFITxTYPE] = new DlGraphics (oMainWindow, " CellNet: Profit x Type", false, iPROFITxTYPE);
      MainWindow.omDlGraf[iPROFITxTYPE].setVisible(true);
      MainWindow.omDlGraf[iTAX_HISTOGRAM] = new DlGraphics (oMainWindow, " CellNet: Tax Histogram", false, iTAX_HISTOGRAM);
      MainWindow.omDlGraf[iTAX_HISTOGRAM].setVisible(true);
      MainWindow.omDlGraf[iTAXxCOA_CELL] = new DlGraphics (oMainWindow, " CellNet: Average Tax per Coalition Cell", false, iTAXxCOA_CELL);
      MainWindow.omDlGraf[iTAXxCOA_CELL].setVisible(true);
    }
  }

  iNewGame++;
}




/**
  * Este método contiene la secuencia de acciones en cada ciclo
  */
public void vRunLoop() {
  int iAux;
  Vector oVectorCellsAux;
	
  iNumGen++;                                    // Increasing the number of generations
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
      continue;
    else
      oCellMatrix[x][y].vResetPayoff ();

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
      continue;
    else
      vCalcPayoffs (oCellMatrix[x][y]);			// Calculates the payoffs for this cell

  oVectorCellsAux = (Vector) oVectorCells.clone();
  while (oVectorCellsAux.size() > 0) {
		iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
		CellCoa oCell = (CellCoa) oVectorCellsAux.elementAt (iAux);
		oVectorCellsAux.removeElementAt (iAux);
		vChangeCoa (oCell);				// Changes coalition or gets independence
  }

  oVectorCellsAux = (Vector) oVectorCells.clone();
  while (oVectorCellsAux.size() > 0) {
		iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
		CellCoa oCell = (CellCoa) oVectorCellsAux.elementAt (iAux);
		oVectorCellsAux.removeElementAt (iAux);
		vChangeAction (oCell);			// New action for this cell
  }
  
  vSetStatsGameCoa();               // Must be before updating

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
      continue;
    else
      oCellMatrix[x][y].vUpdateAction ();		// Updates synchronously the new actions


  if (MainWindow.iBatchMode < 2)
  	vSetGraphicValues();                        	// Must be after updating
  sTextStateBar = "NGen: "+iNumGen+"    D: "+imCellsAction[0]+"  C: "+imCellsAction[1]+"  Coa: "+imCellsType[1]+" ("+imCellsType[2]+")"
                      +"     Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
  }		// de vEjecutaCiclo()






/**
  * This method updates the payoff for its neighborhood
  *
  *	@param oCell Cell where we are playing
  */
private void vCalcPayoffs (CellCoa oCell)
  {
  CellCoa oVecino;
  CellCoa oLiderCell = oCell.oGetLeader();	// Obtaining the leader of this cell
  CellCoa oLiderVecino=null;                // Leader of a neighbor cell
  boolean bSameHolon;                       // Tells if both cells belong to the same coalition
  int iAccPropia=0;                         // Own action
  int iAccVecino=0;							// Neighbor action
  int iTamPropio=oCell.iGetHolonSize();
  int iTamVecino=1;
  int iNumDesleales=0;
  double dKl=1;
  double dKw=0;
  double dBotinPropio=0;
  double dBotinVecinos=0;
  Vector ovNeighbors = oCell.oVGetNeighbors();

  if (oLiderCell == null)
    iAccPropia = oCell.iGetAction();
  else {
    iTamPropio = oLiderCell.iGetHolonSize();
    iAccPropia = oLiderCell.iGetAction();
  }

  for (int i=0; i<ovNeighbors.size(); i++) {
    oVecino = (CellCoa) ovNeighbors.elementAt(i);
    oLiderVecino = oVecino.oGetLeader();

    bSameHolon=false;
    if (  (oLiderVecino == oCell) || (oLiderCell == oVecino) ||
      ( (oLiderCell == oLiderVecino) && (oLiderCell != null)) ) { 		// Cooperate if they are in the same coalition 
      iAccPropia=1; iAccVecino=1;
      bSameHolon=true;
    }
    else if (oLiderVecino == null)                                    // Independent neighbor
      iAccVecino = oVecino.iGetAction();
    else                                                              // Neighbor in another coalition
      iAccVecino = oLiderVecino.iGetAction();

    iTamVecino = 1;
    if (oLiderVecino != null)
      iTamVecino = oLiderVecino.iGetHolonSize();

    dBotinPropio += dPayMatrix[iAccPropia][iAccVecino][0];
    dBotinVecinos += dPayMatrix[iAccVecino][iAccPropia][0];
    switch (iAccPropia) {
      case 0:   switch (iAccVecino) {
                  case 0: dBotinPropio -= dKl * Math.log((double) iTamVecino);
                          dBotinVecinos -= dKl * Math.log((double) iTamPropio);
                          break;
                  case 1: dBotinPropio += dKw * Math.log((double) iTamVecino);
                          dBotinVecinos -= dKl * Math.log((double) iTamPropio);
                }
                break;
      case 1:   switch (iAccVecino) {
                  case 0: dBotinPropio -= dKl * Math.log((double) iTamVecino);
                          dBotinVecinos += dKw * Math.log((double) iTamPropio);
                          break;
                  case 1: if (!bSameHolon) {
	                          dBotinPropio += dKw * Math.log((double) iTamVecino);
	                          dBotinVecinos += dKw * Math.log((double) iTamPropio);
                          }
                  }
    }

    if (iAccVecino == iDEFECT) {
      oCell.vChangeCompromiseWithNeighbor (i, -10);
      iNumDesleales++;
    }
    else
      oCell.vChangeCompromiseWithNeighbor (i, 10);
  }

  oCell.vAddPayoffs (dBotinPropio, dBotinVecinos);
  oCell.vSetNumDefectors(iNumDesleales);
}





/**
  * This method changes the coalition for a cell
  *
  *	@param x  Horizontal position of the cell
  *	@param y  Vertical position of the cell
  */
private void vChangeCoa (CellCoa oCell) {
  CellCoa oLiderCell = oCell.oGetLeader();
  CellCoa oVecino, oCellMax = null, oLiderCellMax = null;
  boolean bGrupoCerca = false;
  int iCellMaxNumVecino = -1;
  double dNumMaxOtros = 2.0;                        // Used for choosing randomly an action, when there are several options
  double dAux, dMediaAux = 0;
  double dBotinCellMax = -Double.MAX_VALUE;			// Set up the best payoff for the neighbor
  double dBotinCellMin = Double.MAX_VALUE;			// Set up the worst payoff for the neighbor
  double dGanancia = 0;
  Vector ovNeighbors = oCell.oVGetNeighbors();

  for (int i=0; i<ovNeighbors.size(); i++) {
    oVecino = (CellCoa) ovNeighbors.elementAt(i);
    dAux = oVecino.dGetPayoff();

    if (oLiderCell != null)
      if ( (oLiderCell == oVecino) || (oLiderCell == oVecino.oGetLeader()) )
        bGrupoCerca = true;

    if (dAux > dBotinCellMax) {
      dNumMaxOtros = 2.0;							// The first resets all
      dBotinCellMax = dAux;
      oCellMax = oVecino;
      iCellMaxNumVecino = i;
      oLiderCellMax = oCellMax.oGetLeader ();
    }
    else if (dAux == dBotinCellMax)					// If they are equal, then choose randomly
      if (Math.random() < 1.0/dNumMaxOtros) {
        dNumMaxOtros += 1.0;					    // The next reduces the probability
        oCellMax = oVecino;
        iCellMaxNumVecino = i;
        oLiderCellMax = oCellMax.oGetLeader ();
      }

    if (dAux < dBotinCellMin)
      dBotinCellMin = dAux;

    dMediaAux += dAux;
  }	// del for i

  dMediaAux = dMediaAux / ((double) ovNeighbors.size());     // Average payoff for the rest
  dGanancia = oCell.dGetPayoff();


  // *************************************** INI: Coalition change ************************************
  // Independent (without leader or coalition)
  if ( (oLiderCell == null) && (oCell.iGetHolonSize() == 1) ) {
    if ( (dBotinCellMin > dGanancia) ||      	// If it is the worst or (its bad and compromise with neighbor > 75) -> join neighbor
       ( (dBotinCellMax > dGanancia) && (oCell.iGetCompromiseWithNeighbor(iCellMaxNumVecino) > 75)) ) {

      if (oLiderCellMax == null) {              // If CellMax has no leader
        oCell.vNewLeader (oCellMax);
        oCellMax.vAddHolonPart(oCell);
      }
      else {
        oCell.vNewLeader (oLiderCellMax);
        oLiderCellMax.vAddHolonPart(oCell);
      }
    }
  }

  	// If belongs to a coalition
  else if (oLiderCell != null) {
         // a) Isolated from the coalition -> change tax and independence
    if (!bGrupoCerca) {
      oLiderCell.vRemoveHolonPart (oCell);
      oCell.vNewLeader (null);
      if (Game.bRandomTaxes)
    	  oCell.vNewRandomTax();
      if (Game.iChangeType == Game.iMETA_STRAT)
        oCell.vSetStrategyType (oCellMax.iGetStrategyType());
    }

    	// b) If there is rebellion or (the other is independent and compromise with leader low) -> change tax and independence
    else if ( (Math.random() < dProbReb) ||
    		((oLiderCellMax == null) && (oCellMax.iGetHolonSize() == 1) && (oCell.iGetCompromiseWithLeader() < 25)) ) {
      oLiderCell.vRemoveHolonPart (oCell);
      oCell.vNewLeader (null);
      if (Game.bRandomTaxes)
	    oCell.vNewRandomTax();
      if (Game.iChangeType == Game.iMETA_STRAT)
        oCell.vSetStrategyType (oCellMax.iGetStrategyType());
    }
    
         // c) If the payoff is good and bigger than zero -> increase compromise with leader
    else if ( (dBotinCellMax <= dGanancia) && (dGanancia > 0) )
      oCell.vChangeCompromiseWithLeader (10);

         // d) If payoff is bad and CellMax is not my leader -> reduce compromise with leader
    else if ( (dBotinCellMax > dGanancia) && (oLiderCell != oCellMax) ) {
      oCell.vChangeCompromiseWithLeader (-10);

            // If payoff is the worst or the compromise with CellMax is > 50 -> joining CellMax's coalition
		  if ( (dBotinCellMin > dGanancia) || (oCell.iGetCompromiseWithNeighbor(iCellMaxNumVecino) > 75) ) {
	      oCell.vSetCompromiseWithLeader (50);        // Initialize compromise at 50%
	      oLiderCell.vRemoveHolonPart (oCell);
	      if (oLiderCellMax == null) {              	// If CellMax has no leader
	        oCell.vNewLeader (oCellMax);
	        oCellMax.vAddHolonPart(oCell);
	      }
	      else {
	        oCell.vNewLeader (oLiderCellMax);
	        oLiderCellMax.vAddHolonPart(oCell);
	      }
	    }
	    
    }   // d) If payoff is bad and CellMax is not my leader -> reduce compromise with leader
    
  }   // If belongs to a coalition
// *************************************** END: Coalition change ************************************

}



/**
  * This method changes the action of this cell
  */
private void vChangeAction (CellCoa oCell)
  {

  // *************************************** INI: Action Change ************************************

      // If this is a leader cell
  if (oCell.iGetHolonSize() > 1) {
    switch (oCell.iGetStrategyType()) {
      case iIMITATION:            oCell.vSetNewAction (0);                // Leaders play defect against non members
                                  break;
                                  
      case iLEARNING:    					oCell.vGenerateStats();      						// The cell generates its statistics
      														oCell.vGetNewActionAutomata();          // Learning Automata
                                  break;
    }
  }

      // If is is an independent cell -> changes action depending on the strategy type
  else if (oCell.oGetLeader() == null)
    switch (oCell.iGetStrategyType()) {
      case iIMITATION:            oCell.vGetNewActionProbTFT();           // This is the probabilistic TFT
                                  break;
                                  
      case iLEARNING:    					oCell.vGenerateStats();      						// The cell generates its statistics
      														oCell.vGetNewActionAutomata();          // Learning Automata
                                  break;
    }

// *************************************** END: Action Change ************************************


                        // If it has changes action increase the changes variable
  if (oCell.iGetNewAction() != oCell.iGetAction())
    iNumChanges++;
}



/**
  * This method updates the statistics of this games
  */
private void vSetStatsGameCoa() {
  double dPayoffCell;

  dGlobalProfit = 0;
  dMaxIncome = 0;
  dMinIncome = Double.MAX_VALUE;
  imCellsAction = new int [iNumTypes];       // Reseting
  imCellsType = new int [iNumTypes];
  imMovAction = new int [iNumActions];
  dmProfitAction = new double [iNumTypes];
  iNumCellStrat = new int [Game.iMaxStrategies];

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y] == null)
      continue;
    else {
      dPayoffCell = oCellMatrix[x][y].dGetPayoff();
      if (oCellMatrix[x][y].bIsLeader()) {                	// If it is a leader
        dmProfitAction[2] += dPayoffCell;							// Coalition payoff: action G
        dmProfitType[2] += dPayoffCell;							// LC payoff: type 2
        imCellsAction[2]++;										  	
        imCellsType[2]++;
      } 
      else if (oCellMatrix[x][y].bIsCoaMember()) {			// If it is in a coalition
        dmProfitAction[2] += dPayoffCell;							// Coalition payoff: action G
        dmProfitType[1] += dPayoffCell;							// CC payoff: type 1
        imCellsAction[2]++;
        imCellsType[1]++;
      }
      else {																// Not a leader and without leader -> independent
        dmProfitAction[oCellMatrix[x][y].iGetAction()] += dPayoffCell;	// Independent payoff: actions D or C
        dmProfitType[0] += dPayoffCell;									// IC payoff: type 0
        imCellsAction[oCellMatrix[x][y].iGetAction()]++;			
        imCellsType[0]++;										
      }

      dGlobalProfit += dPayoffCell;
      if (dMaxIncome < dPayoffCell) dMaxIncome = dPayoffCell;
      if (dMinIncome > dPayoffCell) dMinIncome = dPayoffCell;

      if (oCellMatrix[x][y].bIsIndependent()) {
	    	int iAux = oCellMatrix[x][y].iGetStrategyType();
	    	if (iAux > 0) iAux = 1;
	    		iNumCellStrat [iAux]++;
      }
    }
}


/**
  * This method updates the graphics for this games
  */
protected void vSetGraphicValues() {  
  int iAux, iNumTax=0;
  double dAux, dMediaTax=0;
  Vector oVectAux;

  super.vSetGraphicValues();

  iAux=0;
  for (int i=0; i<Game.iMaxStrategies; i++)
    iAux += iNumCellStrat[i];
  
  if (iAux > 0) for (int i=0; i<Game.iMaxStrategies; i++) {
    oVectAux = (Vector) oVCellsxStrat.elementAt(i);
    oVectAux.add (new Integer (100 * iNumCellStrat[i] / iAux));
    while (oVectAux.size() > MainWindow.iLastNGen)
      oVectAux.removeElementAt (0);
  }


  iMFrecTax = new int [10];
  for (int y=0; y<iCellV; y++)
    for (int x=0; x<iCellH; x++)
      if (oCellMatrix[x][y] == null)
        continue;
      else {
        if (oCellMatrix[x][y].bIsLeader()) {         // If it is a leader
          dAux = oCellMatrix[x][y].dGetTax();
          iAux = (int) Math.floor(dAux*10);
          iMFrecTax [iAux]++;
        }
        else if (oCellMatrix[x][y].bIsCoaMember()) {    // If it belongs to a coalition
          dMediaTax += oCellMatrix[x][y].oGetLeader().dGetTax();
          iNumTax++;
        }
      }

  dMediaTax = dMediaTax / iNumTax;
  ovAvgTaxCoaCell.add (new Integer ((int) (100.0 * dMediaTax)));
  while (ovAvgTaxCoaCell.size() > MainWindow.iLastNGen)
    ovAvgTaxCoaCell.removeElementAt (0);
  
  
  for (int i=0; i<iNumTypes; i++) {
		oVectAux = (Vector) oVProfitType.elementAt(i);
		if (imCellsType[i] > 0)
		  oVectAux.add (new Double (dmProfitType[i] /= (double) imCellsType[i]));
		else
		  oVectAux.add (new Double (0));
		while (oVectAux.size() > MainWindow.iLastNGen)
		  oVectAux.removeElementAt (0);
	  }

}

}	// from class GameCoaIPD

