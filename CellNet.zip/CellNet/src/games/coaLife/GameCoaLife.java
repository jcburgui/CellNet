package games.coaLife;

import games.CellCoa;
import games.Game;

import java.util.Vector;

import window.DlGraphics;
import window.MainWindow;
import window.WindowCons;


class LeaderPop {
CellCoa oLeader = null;
int iPop = 1;               // Popularity of this leader. Note that it starts with one !!!

LeaderPop (CellCoa oLeaderAux) {
	oLeader = oLeaderAux;
  }

}

/**
* This class implements the Game of Life with coalitions
* Note: The classical radio is R = 1.5
* 
* - The version with coalitions is a survival games, where coalitions are cell tribes.
* - Birth is again associated having 3 cells around, but:
* 	+ If they do not have coalition a new one is created by the new cell.
* 	+ Otherwise, it joins the biggest coalition in the neighborhood.
* - When an independent cell is surrounded by 2 or 3 from another coalition joins that coalition (its captured).
* - If a coalition cell has no fellows in its neighborhood it gets independence.
* 
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class GameCoaLife extends Game implements WindowCons
{
private final int iDEAD = 0;
private final int iALIVE = 1;

public static boolean bPlayIPD = true;					// Plays or not the IPD among cells
public static boolean bCreateCoalitions=false;	// Independent new born cells start coalitions around
public static int iNumPlayers = 4;							// Number of initial coalitions
public static double dProbAlive = 0.25;	      	// Probability of having an alive cell
public static double dInfLeaderTax = 0.5;	      // Influence of leader over the tax when a cell is born
public static CellCoa[][] oCellMatrix = new CellCoa [iCellH][iCellV];

/**
 * This is the class constructor
 *
 */
public GameCoaLife () {
  super ();
  bMovement = true;
  iVisorShow = 0;               // By defect we show the Strats
  iMaxStrategies = 2;						// DEFECTOR or COOPERATOR
  iTotPosMatrix = 2500;					// Initial number of cells in the matrix
	
  iNumActions = 2;                                              // Dead or alive
  iNumTypes = 3;																								// Independent, coalition member and leader
  dRadio = 1.5;                                                 // Radio of neighbor influence
  dProbReb = 0;                                                 // Initially no rebellions

  bCoalitions = true;
  
  oVTextAction = new Vector (1,1);
  oVTextAction.add ("D");						// Dead cell
  oVTextAction.add ("A");						// Alive cell
  for (int i=0; i<oVTextAction.size(); i++)
    oVFrecActions.add (new Vector (1,1));
  
  
  // Initializing the payoff matrix [with T>R>P>S and 2R > S+T]
	dPayMatrix[0][0][0] = 1.0;
	dPayMatrix[0][1][0] = 5.0;
	dPayMatrix[1][0][0] = 0.0;
	dPayMatrix[1][1][0] = 3.0;
	
	dPayMatrix[0][0][1] = 1.0;
	dPayMatrix[0][1][1] = 0.0;
	dPayMatrix[1][0][1] = 5.0;
	dPayMatrix[1][1][1] = 3.0;

}



/**
 * This is the class constructor
 *
 */
public GameCoaLife (MainWindow oVentAux) {  
 this();

 oMainWindow = oVentAux;
}



/**
  * This method sets up the games when "New" is pressed
  *
  */
public void vNewGame() {
  super.vNewGame();
  
  int iTipoCell = 0;
  int iAction;
  CellCoa oCoaLeader;

  Game.oCellMatrix = null;
  oCellMatrix = new CellCoa [iCellH][iCellV];
  
  for (int x=0; x<iCellH; x++)             	// Initializing the cell matrix as a function of dProbAlive
  for (int y=0; y<iCellV; y++) {
    if (Math.random() < dProbAlive)
      iAction = iALIVE;											// Alive Cell
    else
    	iAction = iDEAD;											// Dead Cell
    
    oCellMatrix[x][y] = new CellCoa (x, y, iTipoCell, iAction);
    
    if (Math.random() < 0.5) oCellMatrix[x][y].vSetStrategy (iDEFECT);
    else oCellMatrix[x][y].vSetStrategy (iCOOPERATE);
    
    imCellsType[0]++;
    imCellsAction[iAction]++;
    iTotNumCells++;
  }

  Game.oCellMatrix = oCellMatrix;									// Setup the Game matrix for this games
  oVectorCells = ovCells2Vector (oCellMatrix);		// Creates a line vector to simplify random access
  
  switch (iNetType) {								// Selects the type of complex network to be created
	  case 0:   vSetNeighborsSpatialRadio (oCellMatrix); break;
	  case 1:   vSetNeighborsSmallWorld (oCellMatrix); break;
	  case 2:   vSetNeighborsScaleFree (oCellMatrix); break;
	  case 3:   vSetNeighborsRandomNetwork (oCellMatrix); break;
  }

  if (bCoalitions)
  	switch (iNumPlayers) {
	  	case 2:		vDefineCoalition (0, iCellH/2, 0, iCellV);
	  						vDefineCoalition (iCellH/2, iCellH, 0, iCellV);
	  						break;
	  	case 4:		vDefineCoalition (0, iCellH/2, 0, iCellV/2);
								vDefineCoalition (iCellH/2, iCellH, 0, iCellV/2);
								vDefineCoalition (0, iCellH/2, iCellV/2, iCellV);
								vDefineCoalition (iCellH/2, iCellH, iCellV/2, iCellV);
	  }

  sTextStateBar = "NGen: " +iNumGen+ "  Death: " +imCellsAction[0]+ "  Alive: " +imCellsAction[1]+
  								"   Cel: "+iTotNumCells +"   N: "+iTotPosMatrix;
  
  if ( (iNewGame == 0) && (MainWindow.iBatchMode < 2) ) {
  	
  	MainWindow.oMIPayMatrix.setEnabled (true);
    
    for (int i=5; i<=12; i++)
      MainWindow.oMIWindow[i].setEnabled (true);
    
    if (MainWindow.iBatchMode == 0) {
    	MainWindow.omDlGraf[iFREQxACTION] = new DlGraphics (oMainWindow, " CellNet: Frequency x Action", false, iFREQxACTION);
      MainWindow.omDlGraf[iFREQxACTION].setVisible(true);
      MainWindow.omDlGraf[iCHANGESxGEN] = new DlGraphics (oMainWindow, " CellNet: Action Changes", false, iCHANGESxGEN);
      MainWindow.omDlGraf[iCHANGESxGEN].setVisible(true);
      MainWindow.omDlGraf[iCELLSxSTRAT] = new DlGraphics (oMainWindow, " CellNet: Cells x Strat", false, iCELLSxSTRAT);
      MainWindow.omDlGraf[iCELLSxSTRAT].setVisible(true);
      MainWindow.omDlGraf[iFREQxTYPE] = new DlGraphics (oMainWindow, " CellNet: Frequency x Type", false, iFREQxTYPE);
      MainWindow.omDlGraf[iFREQxTYPE].setVisible(true);
      MainWindow.omDlGraf[iGLOBAL_PROFIT] = new DlGraphics (oMainWindow, " CellNet: Global Profit", false, iGLOBAL_PROFIT);
      MainWindow.omDlGraf[iGLOBAL_PROFIT].setVisible(true);
      MainWindow.omDlGraf[iPROFITxTYPE] = new DlGraphics (oMainWindow, " CellNet: Profit x Type", false, iPROFITxTYPE);
      MainWindow.omDlGraf[iPROFITxTYPE].setVisible(true);
      MainWindow.omDlGraf[iTAX_HISTOGRAM] = new DlGraphics (oMainWindow, " CellNet: Tax Histogram", false, iTAX_HISTOGRAM);
      MainWindow.omDlGraf[iTAX_HISTOGRAM].setVisible(true);
      MainWindow.omDlGraf[iTAXxCOA_CELL] = new DlGraphics (oMainWindow, " CellNet: Average Tax per Coalition Cell", false, iTAXxCOA_CELL);
      MainWindow.omDlGraf[iTAXxCOA_CELL].setVisible(true);
    }
  }

    
    
  
  iNewGame++;
}



/**
 * This method allows to define a coalition in a square grid area
 */
private void vDefineCoalition (int iX1, int iX2, int iY1, int iY2) {
  CellCoa oCoaLeader = null;
  
  for (int y=iY1; y<iY2; y++)
  for (int x=iX1; x<iX2; x++)
    if (oCellMatrix[x][y].iGetAction() == iALIVE) {
    	if (oCoaLeader == null)
    		oCoaLeader = oCellMatrix[x][y];
    	else {
    		oCellMatrix[x][y].vNewLeader (oCoaLeader);
    		oCoaLeader.vAddHolonPart (oCellMatrix[x][y]);
    	}
    }
}



/**
  * This method contains the code to be executed in the thread
  */
public void vRunLoop() {

  iNumGen++;                                    	// Increasing the number of generations
  iNumChanges = 0;

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    vCountAliveNeighbors (oCellMatrix[x][y]);

  if (bPlayIPD) {
	  for (int y=0; y<iCellV; y++)
	  for (int x=0; x<iCellH; x++)
	  	if (oCellMatrix[x][y].iGetAliveNeighbors() > 0)
	  		vPlayPrisonersDilemma (oCellMatrix[x][y]);								// Plays the Prisoner's Dilemma with the alive neighbors
  }
  
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++)
    vVitalChange (oCellMatrix[x][y]);															// Born, keep alive or death  
  
  
  if (bCoalitions) {
	  Vector oVectorCellsAux = (Vector) oVectorCells.clone();				// Must be after vVitalChange
		while (oVectorCellsAux.size() > 0) {				// Join/Change coalition or independence in a "non-sequential" way
		  int iAux = (int) (Math.random () * (double) oVectorCellsAux.size());
		  CellCoa oCell = (CellCoa) oVectorCellsAux.elementAt (iAux);
		  oVectorCellsAux.removeElementAt(iAux);
		  vCoaChange (oCell);
		}
  }
  
  
  if (dProbRewiring > 0) {											// If rewiring is set
	  for (int y=0; y<iCellV; y++)
	  for (int x=0; x<iCellH; x++)
	  	if (oCellMatrix[x][y].iGetAliveNeighbors() < 3)
	    	if (Math.random() < dProbRewiring)			// Note that this part introduces randomness
	    		vRewire (oCellMatrix[x][y]);
  }
  
  
  vSetStatsGameCoaLife ();                		  // Must be before updating

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++) {
    oCellMatrix[x][y].vUpdateAction ();					// Updating synchronously the new actions
  	oCellMatrix[x][y].vResetPayoff();
  }
  
  if (MainWindow.iBatchMode < 2)
  	vSetGraphicValues();                        // Must be after updating
  sTextStateBar = "NGen: "+iNumGen+"     Ind: "+imCellsType[0]+"  Coa: "+imCellsType[1]+" ("+imCellsType[2]+")"
             +"     Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
  
  }



/**
 * This method counts the alive neighbors a cell has around
 *
 *	@param oCell  CellCoa with the cell 
 */
private void vCountAliveNeighbors (CellCoa oCell) {
	int iAliveNeighbors = 0;
  CellCoa oNeighbor;
  Vector ovNeighbors =  oCell.oVGetNeighbors();
  

  for (int i=0; i<ovNeighbors.size(); i++)  {
    oNeighbor = (CellCoa) ovNeighbors.elementAt(i);
    if (oNeighbor == null)			               			 	// If the neighbor is an empty cell
    	continue;
    else if (oNeighbor.iGetAction() == 1)	            // If the neighbor is alive
      iAliveNeighbors++;
    
    oCell.vSetAliveNeighbors (iAliveNeighbors);
  }

}




/**
 * This method plays the Prisoner's Dilemma with the neighbors of a cell
 *
 *	@param oCell  CellCoa with the cell 
 */
private void vPlayPrisonersDilemma (CellCoa oCell) {
	int iStrat, iMateStrat;
	double dPayoff=0, dMatePayoff;
	CellCoa oMate, oMateLeader, oLeader = oCell.oRecGetLeader();
	Vector ovNeighbors =  oCell.oVGetNeighbors();
	
	for (int i=0; i<ovNeighbors.size(); i++) {
		oMate = (CellCoa) ovNeighbors.elementAt(i);
		if (oLeader == null)
			iStrat = oCell.iGetStrategy();
		else
			iStrat = oLeader.iGetStrategy();
		
    if (oMate.iGetAction() == iALIVE) {	            								// If the neighbor is alive
    	oMateLeader = oMate.oRecGetLeader();

  		if (oMateLeader == null)
  			iMateStrat = oMate.iGetStrategy();
  		else
  			iMateStrat = oMateLeader.iGetStrategy();

    	if ( (oMateLeader != null) && (oMateLeader == oLeader) ) { 		// In the same coalition all members cooperate
    		iMateStrat = iCOOPERATE;
    		iStrat = iCOOPERATE;
    	}
    	
    	dPayoff = dPayMatrix[iStrat][iMateStrat][0];
      dMatePayoff = dPayMatrix[iStrat][iMateStrat][1];

      
      oCell.vAddPayoffs (dPayoff, dMatePayoff);
      oMate.vAddPayoffs (dMatePayoff, dPayoff);
    }
	}

}




/**
  * This method updates the state of a cell
  *
  *	@param oCell  CellCoa with the cell 
  */
private void vVitalChange (CellCoa oCell) {
	boolean bFound = false;
  int	iActionCell = oCell.iGetAction(),								// Present action
  		iNewActionCell,
  		iAliveNeighbors = oCell.iGetAliveNeighbors();   // Total number of neighbors
  double dMaxPayoff = -Double.MAX_VALUE;
  CellCoa oNeighbor;
  Vector ovNeighbors = oCell.oVGetNeighbors();
  
  // *********************************** INI: Vital Changes **********************************************

  iNewActionCell = iActionCell;																				// Keeping the present action
  if (iAliveNeighbors == 3)                    												// 3 alive cells around -> alive
  	iNewActionCell = iALIVE;
  else if ( (iAliveNeighbors < 2) || (iAliveNeighbors > 3) ) 					// [2,3] alive cells around -> die
    iNewActionCell = iDEAD;
  
  oCell.vSetNewAction (iNewActionCell);
  
  // *********************************** END: Vital Changes **********************************************
  
  
  //*********************************** END: New strat when a cell is born **********************************************
  if (bPlayIPD)
	  if ( (iActionCell == iDEAD) && (iNewActionCell == iALIVE) ) {				// Cell is born
	  	for (int i=0; i<ovNeighbors.size(); i++) {
	  		oNeighbor = (CellCoa) ovNeighbors.elementAt(i);
	  		if (oNeighbor.iGetAction() == iALIVE)
	  				if (oNeighbor.dGetPayoff() > dMaxPayoff) {
	  					bFound = true;
	  					dMaxPayoff = oNeighbor.dGetPayoff();
							oCell.vSetStrategy(oNeighbor.iGetStrategy());						// Imitates the strat of the best alive neighbor
	  				}
	  	}
	  	
	  	if (!bFound)
	  		if (Math.random() < 0.5) oCell.vSetStrategy (iDEFECT);				// If no independent cell is found, then random
	  		else oCell.vSetStrategy (iCOOPERATE);
	  }
  //*********************************** END: New strat when a cell is born **********************************************
  
  if (oCell.iGetNewAction() != oCell.iGetAction())              			// If it has born or died, we count those changes
    iNumChanges++;

}       // from vVitalChange (CellCoa oCell)






/**
 * This method updates the coalition membership of a cell
 *
 *	@param oCell  CellCoa with the cell 
 */
private void vCoaChange (CellCoa oCell) {
	int			iActionCell = oCell.iGetAction(),										// Present action
					iNewActionCell = oCell.iGetNewAction(),							// New action
					iMaxLeaderPop=0;
	double	dMatePayoff,
					dPayoff,
					dWorstMatePayoff = Double.MAX_VALUE;
	CellCoa oCoaMember, oLeaderCell = (CellCoa) oCell.oRecGetLeader();
	CellCoa oNeighbor, oNeighborLeader;
	LeaderPop oLeaderPop, oMaxLeaderPop=null;
	Vector ovNeighbors = oCell.oVGetNeighbors();
	Vector<LeaderPop> oVLeaders = new Vector<LeaderPop> (1,1);

	// If this cell keeps death then nothing to do here
	if ( (iActionCell == iDEAD) && (iNewActionCell == iDEAD) ) return;

	if (oCell.iGetAliveNeighbors() == 0)
		dPayoff  = oCell.dGetPayoff() / (double) oCell.iGetAliveNeighbors();
	else
		dPayoff  = oCell.dGetPayoff();

	//*********************************** INI: Rebellion for cells badly paid in coalitions *************************************
	if (oCell.bIsCoaMember() ) {
		for (int i=0; i<ovNeighbors.size(); i++)  {
			oNeighbor = (CellCoa) ovNeighbors.elementAt(i);
			if (oNeighbor.iGetAction() == iDEAD) continue;										// Only for alive neighbors
			
			dMatePayoff = oNeighbor.dGetPayoff() / (double) oNeighbor.iGetAliveNeighbors();
			if (dMatePayoff < dWorstMatePayoff)
				dWorstMatePayoff = dMatePayoff;
		}
		
		if (dPayoff < dWorstMatePayoff) {
			oLeaderCell.vRemoveHolonPart (oCell);        											// Leaving its former coalition
			oCell.vNewLeader(null);
			return;
		}
	}
	//*********************************** END: Rebellion for cells bad paid in coalitions *************************************
	
	//*********************************** INI: Searching for the bigger coalition in the neighborhood *************************************
	for (int i=0; i<ovNeighbors.size(); i++)  {
	  oNeighbor = (CellCoa) ovNeighbors.elementAt(i);
		if (oNeighbor.iGetAction() == iALIVE) {							// If the neighbor is alive
		  oNeighborLeader = oNeighbor.oRecGetLeader();
		  if (oNeighborLeader == null) continue;						// If the neighbor is independent jump to next
		
		  boolean bFound = false;
		  for (int j=0; j<oVLeaders.size(); j++) {
		   	oLeaderPop = (LeaderPop) oVLeaders.elementAt (j);
	   		if (oNeighborLeader == oLeaderPop.oLeader) {    // If the neighbor leader is already indexed
	   			oLeaderPop.iPop++;														// The size of the coalition around increases
	   			bFound = true;
	   			break;
	   		}
		  }
		     
		  if (!bFound) {
		  	oLeaderPop = new LeaderPop (oNeighborLeader);
		  	oVLeaders.add (oLeaderPop);
		  }
		}	       
	}	// for (int i=0; i<ovNeighbors.size(); i++)

	iMaxLeaderPop = 0;
	oMaxLeaderPop = null;
	for (int j=0; j<oVLeaders.size(); j++) {
   	oLeaderPop = (LeaderPop) oVLeaders.elementAt (j);
		if (oLeaderPop.iPop > iMaxLeaderPop) {							// Searching for the most winner coalition around
			iMaxLeaderPop = oLeaderPop.iPop;
			oMaxLeaderPop = oLeaderPop;
		}
		else if (oLeaderPop.iPop == iMaxLeaderPop)					// If there are two or more winners, then no winner at all
			oMaxLeaderPop = null;
	}

	//*********************************** END: Searching for the bigger coalition in the neighborhood ****************************************
	
	
	
	//*********************************** INI: Change Coalitions **********************************************

	if ( (iActionCell == iDEAD) && (iNewActionCell == iALIVE) )	{		// If this cell will born
		if (oMaxLeaderPop != null) {     															// If there a winner coalition around, then it captures this cell
		  oCell.vNewLeader (oMaxLeaderPop.oLeader);
		  oMaxLeaderPop.oLeader.vAddHolonPart (oCell);								// The leader influences the new tax		  
			oCell.vSetTax ((1-dInfLeaderTax)*Math.random() + dInfLeaderTax*oMaxLeaderPop.oLeader.dGetTax());
		}
		else if (bCreateCoalitions)	{																	// Otherwise
			oCell.vSetTax (Math.random());															// Random tax
			for (int i=0; i<ovNeighbors.size(); i++)  {									// It starts a coalition with independent cells around
				oNeighbor = (CellCoa) ovNeighbors.elementAt(i);
				if ( (oNeighbor.iGetAction() == 1) && (oNeighbor.iGetNewAction() == 1) && (oNeighbor.oRecGetLeader() == null) ) {
		  		oNeighbor.vNewLeader (oCell);
		  		oCell.vAddHolonPart (oNeighbor);
				}
			}
		}
	}


	else if ( (iActionCell == iALIVE) && (iNewActionCell == iALIVE) ) {		// Keeping alive
		if  (oMaxLeaderPop != null) { 																			// with a winner coalition around
			if (oCell.bIsIndependent()) {
		    oCell.vNewLeader (oMaxLeaderPop.oLeader);												// Then the new leader captures this cell
		    oMaxLeaderPop.oLeader.vAddHolonPart (oCell);
			}
			else if ( oCell.bIsCoaMember() && (iMaxLeaderPop > 1) ) {		
				if (oMaxLeaderPop.oLeader != oLeaderCell) {								// The winner coalition is not the same of the cell									
					oLeaderCell.vRemoveHolonPart (oCell);        						// Leaving its former coalition
			    oCell.vNewLeader (oMaxLeaderPop.oLeader);								// Then the new leader captures this cell
			    oMaxLeaderPop.oLeader.vAddHolonPart (oCell);
			  }
			}
		}																															// Note that leaders can't be captured
	}


	else if ( (iActionCell == iALIVE) && (iNewActionCell == iDEAD) )	{		// If this cell will die
		if (oCell.bIsCoaMember()) {																					// If it is in a coalition
			oLeaderCell.vRemoveHolonPart (oCell);        											// Leaving its former coalition
			oCell.vNewLeader(null);
		}
		else if (oCell.bIsLeader()) {																				// If it is the leader (OJO)
			Vector<CellCoa> oVHolonParts = oCell.oVGetHolonParts();
			CellCoa oCoaFirstMember = (CellCoa) oVHolonParts.firstElement();	// The 1st member may become the new leader
			oCoaFirstMember.vNewLeader (null);																// The only member becomes independent
			
			if (oVHolonParts.size() > 1)																			// If it has at least two members
				for (int i=1; i<oVHolonParts.size(); i++) {											// It joins the rest of the members
					oCoaMember = (CellCoa) oVHolonParts.elementAt(i);
					oCoaMember.vNewLeader (oCoaFirstMember);
					oCoaFirstMember.vAddHolonPart (oCoaMember);
				}
				
			oCell.vResetHolonParts();
		}
	}


	//*********************************** END: Change Coalitions **********************************************
	
	}       // from vChangeCoa (CellCoa oCell)




/**
  * This method rewires cells depending on the neighborhood reputation
  * 
  *	@param oCell  It is the cell that will rewire
  */
protected void vRewire (CellCoa oCell) {
	int iAux, iSize;
  CellCoa oNeighbor, oNeighbor2Leave, oNewNeighbor;
  Vector ovMatesMate, ovNeighbors = oCell.oVGetNeighbors();
  
  iSize = ovNeighbors.size();
  if ( (iSize==0) || (iSize == iTotNumCells-1) ) return;        // If it has no neighbors or all are neighbors, then exiting
  
  oNeighbor2Leave = null;
  for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (CellCoa) ovNeighbors.elementAt(i);
    if ( (oNeighbor.iGetAction() == iDEAD) && (oNeighbor.oVGetNeighbors().size() > 1) ) {
    	oNeighbor2Leave = oNeighbor;															// Found a dead neighbor with more than one link
    	break;
    }
  }
  
  
  if (oNeighbor2Leave != null) {
  	oNewNeighbor = null;
  	for (int i=0; i<5; i++) {																		// Five attempts to rewire to another alive cell
  	  iAux = (int) (Math.random() * (double) iTotNumCells);
  	  oNeighbor = (CellCoa) oVectorCells.elementAt (iAux);
  	  if ( (oNeighbor != oCell) && !oCell.bIsNeighbor (oNeighbor) && (oNeighbor.iGetAction() == iALIVE ) ) {
  	  	oNewNeighbor = oNeighbor;
  	  	break;
  	  }
  	}   
	  
  	if (oNewNeighbor != null) {																	// If another alive cell has been found to rewire
	  	ovNeighbors.add (oNewNeighbor);                           // Adding that neighbor
		  ovMatesMate = oNewNeighbor.oVGetNeighbors();
		  ovMatesMate.add (oCell);                                  // Adding myself to the neighbor
		  ovNeighbors.remove (oNeighbor2Leave);                     // Removing the dead
		  ovMatesMate = oNeighbor2Leave.oVGetNeighbors();
		  ovMatesMate.remove (oCell);                               // The dead removes me
  	}
	}
  
}




private void vSetStatsGameCoaLife () {
  double dPayoffCell;
  CellCoa oLeader = null;

  dGlobalProfit = 0;
  dMaxIncome = -Double.MAX_VALUE;
  dMinIncome = Double.MAX_VALUE;
  imCellsAction = new int [iNumTypes];       // Reseting
  imCellsType = new int [iNumTypes];
  dmProfitAction = new double [iNumTypes];
  iNumCellStrat = new int [Game.iMaxStrategies];

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++) {
    imCellsAction[oCellMatrix[x][y].iGetAction()]++;					// Counting the actions
    
  	if (oCellMatrix[x][y].iGetAction() == iALIVE) {
	    dPayoffCell = oCellMatrix[x][y].dGetPayoff();
	    
	    if (oCellMatrix[x][y].bIsLeader()) {           					// If it is a leader
	      dmProfitAction[2] += dPayoffCell;											// Coalition payoff: action G
	      dmProfitType[2] += dPayoffCell;												// LC payoff: type 2
	      imCellsType[2]++;
	    } 
	    else if (oCellMatrix[x][y].bIsCoaMember()) {						// If it is in a coalition
	      dmProfitAction[2] += dPayoffCell;											// Coalition payoff: action G
	      dmProfitType[1] += dPayoffCell;												// CC payoff: type 1
	      imCellsType[1]++;
	    }
	    else {																									// Not a leader or coalition cell -> independent
	      dmProfitAction[oCellMatrix[x][y].iGetAction()] += dPayoffCell;	// Independent payoff: actions D or C
	      dmProfitType[0] += dPayoffCell;												// IC payoff: type 0
	      imCellsType[0]++;										
	    }
	
	    dGlobalProfit += dPayoffCell;
	    if (dPayoffCell > dMaxIncome) dMaxIncome = dPayoffCell;
	    if (dPayoffCell < dMinIncome) dMinIncome = dPayoffCell;

   		iNumCellStrat [oCellMatrix[x][y].iGetStrategy()]++;
  	}
  }
  
  
}





/**
  * This method updates some graphics for this games OJO !!!
  */
protected void vSetGraphicValues() {  
  int iAux, iNumTax=0;
  double dAux, dMediaTax=0;
  Vector oVectAux;

  super.vSetGraphicValues();

  iAux=0;
  for (int i=0; i<Game.iMaxStrategies; i++)
    iAux += iNumCellStrat[i];
  
  if (iAux > 0) for (int i=0; i<Game.iMaxStrategies; i++) {
    oVectAux = (Vector) oVCellsxStrat.elementAt(i);
    oVectAux.add (new Integer (100 * iNumCellStrat[i] / iAux));
    while (oVectAux.size() > MainWindow.iLastNGen)
      oVectAux.removeElementAt (0);
  }

  iMFrecTax = new int [10];
  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++) {
    if (oCellMatrix[x][y].bIsLeader()) {     		    // If it is a leader
      dAux = oCellMatrix[x][y].dGetTax();
      iAux = (int) Math.floor(dAux*10);
      iMFrecTax [iAux]++;
    }
    else if (oCellMatrix[x][y].bIsCoaMember()) {    // If it belongs to a coalition
      dMediaTax += oCellMatrix[x][y].oGetLeader().dGetTax();
      iNumTax++;
    }
  }

  dMediaTax = dMediaTax / iNumTax;
  ovAvgTaxCoaCell.add (new Integer ((int) (100.0 * dMediaTax)));
  while (ovAvgTaxCoaCell.size() > MainWindow.iLastNGen)
    ovAvgTaxCoaCell.removeElementAt (0);
  
  
  for (int i=0; i<iNumTypes; i++) {
		oVectAux = (Vector) oVProfitType.elementAt(i);
		if (imCellsType[i] > 0)
		  oVectAux.add (new Double (dmProfitType[i] /= (double) imCellsType[i]));
		else
		  oVectAux.add (new Double (0));
		while (oVectAux.size() > MainWindow.iLastNGen)
		  oVectAux.removeElementAt (0);
	  }

}



}	// from class GameCoaLife


