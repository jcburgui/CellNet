package games.coaLife;

import javax.swing.*;

import window.MainWindow;

import java.awt.*;
import java.awt.event.*;

import games.*;



/**
* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class DlgParamCoaLife extends JDialog implements ActionListener, GameCons
{
private Label oLabel;
private Choice oChbPlayIPD;
private Choice oChbCoalitions;
private Choice oChbCreateCoalitions;
private JTextField  oTiNumPlayers;
private JTextField  oTdProbAlive;
private JTextField  oTdInfLeaderTax;
private MainWindow oMainWindow;


/**
 * This is the Dialog constructor
 *
 * @param	oPadre 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 */
public DlgParamCoaLife (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);

  oMainWindow = (MainWindow) oParent;
  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(7,2));

  
  oLabel = new Label (" Play the IPD:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oChbPlayIPD = new Choice();
  oChbPlayIPD.add ("no");
  oChbPlayIPD.add ("yes");
  if (GameCoaLife.bPlayIPD)
  	oChbPlayIPD.select ("yes");
  add (oChbPlayIPD);
  
  oLabel = new Label (" Use Coalitions:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oChbCoalitions = new Choice();
  oChbCoalitions.add ("no");
  oChbCoalitions.add ("yes");
  if (Game.bCoalitions)
  	oChbCoalitions.select ("yes");
  add (oChbCoalitions);
  
  oLabel = new Label (" Create New Coalitions:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oChbCreateCoalitions = new Choice();
  oChbCreateCoalitions.add ("no");
  oChbCreateCoalitions.add ("yes");
  if (GameCoaLife.bCreateCoalitions)
  	oChbCreateCoalitions.select ("yes");
  add (oChbCreateCoalitions);
  
  oLabel = new Label (" Num. initial players {0,2,4}:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTiNumPlayers = new JTextField(String.valueOf(GameCoaLife.iNumPlayers), 7);
  add (oTiNumPlayers);
  
  oLabel = new Label (" Empty Cell Prob. [0,1]:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdProbAlive = new JTextField(String.valueOf(GameCoaLife.dProbAlive), 7);
  add (oTdProbAlive);
  
  oLabel = new Label (" Leader influence over tax [0,1]:", Label.LEFT);
  oLabel.setForeground (Color.blue);
  add (oLabel);
  oTdInfLeaderTax = new JTextField(String.valueOf(GameCoaLife.dInfLeaderTax), 7);
  add (oTdInfLeaderTax);
  
  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(400,300));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {
  	
		if ("yes".equals (oChbPlayIPD.getSelectedItem()))
			GameCoaLife.bPlayIPD = true;
		else
			GameCoaLife.bPlayIPD = false;
  	
		if ("yes".equals (oChbCoalitions.getSelectedItem()))
		  Game.bCoalitions = true;
		else
			Game.bCoalitions = false;
		
		if ("yes".equals (oChbCreateCoalitions.getSelectedItem()))
		  GameCoaLife.bCreateCoalitions = true;
		else
			GameCoaLife.bCreateCoalitions = false;

		GameCoaLife.iNumPlayers = Integer.parseInt (oTiNumPlayers.getText());
    GameCoaLife.dProbAlive = Double.parseDouble (oTdProbAlive.getText());
    GameCoaLife.dInfLeaderTax = Double.parseDouble (oTdInfLeaderTax.getText());
    
    if (GameCoaLife.iNumPlayers < 2) GameCoaLife.iNumPlayers = 0;
    if (GameCoaLife.iNumPlayers > 2) GameCoaLife.iNumPlayers = 4;
    
    oMainWindow.vSetupThread();
    }

  dispose();
}

}	// from the class
