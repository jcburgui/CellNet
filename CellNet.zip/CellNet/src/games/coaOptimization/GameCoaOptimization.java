package games.coaOptimization;

import problems.ProblemI;
import problems.optimization.integer.*;
import window.DlGraphics;
import window.JPanelMainWindow;
import window.MainWindow;
import window.WindowCons;
import games.Game;

import java.util.Vector;



/**
  * Esta clase implementa el algoritmo de EACO para optimización (minimización)
  *
  * @author  Juan C. Burguillo Rial
  * @version 3.0
  * 
  * Consideraciones generales:
  *   + A mayor tamaño de coalición -> mejor
  *   + A mayor varianza en el dominio -> mejor
  *   + A menor media en el rango -> mejor
  *   + Hacemos una reproducción aleatoria con vecinos por torneo binario de cada celda (se escogen otras 2 al azar y se selecciona al mejor).
  *   + El vecindario de una celda son todas las celdas de la coalición.
  *   + La celda se puede unir a coaliciones vecinas con mejores valores.
  *   + Cada celda sólo puede estar en una coalición.
  *
  * Funcionamiento:
  *   + Cada coalición tiene una Valoración Vi = Alfa.Tamaño + Beta.Varianza + Ganma/Media; con (Alfa + Beta + Ganma = 1 y todos en [0,1])
  *   + V = Sum(i) Vi
  *   + Pi = OffSpring Total . Vi / V;
  *   + En cada coalición habrá tantas reproducciones posibles como Pi, pero la prob. de reproducirse será proporcional a la calidad del valor funcional de cada celda.
  *   + Una celda en coalición se reproduce con cualquier compañera mediante torneo binario.
  *   + Una celda aislada se reproduce con su vecindario normal, pero se puede unir a la vecina con mejor Vi.
  *   + Una celda frontera de una coalición Ci se puede unir con una probabilidad P_Reb a otra coalición Cj contigua de forma proporcional a Vj/V
  *   + En cada coalición Ci se generan una serie de celdas hijas M, las mejores sustituyen a los M peores padres de esa coalición Ci (puede que Card(Ci) < M).
  *   
  *     El óptimo para cada problema está en la variable maxFitness de la clase del problema correspondiente. Detallo aquí los óptimos para cada problema. 
  *     Son problemas de maximización, pero EACO minimiza, por lo que los negamos. Se indica también el porcentaje de veces que mi cGA encuentra la solución
  *     (de 100 ejecuciones) con una población de 400 soluciones, un máximo de 2500 generaciones y una configuración como la que tu utilizas:
  *     
  *     0 - ECC: -0.0674 100%
  *     1 - MAXCUT100: -1077.0 45%
  *     2 - MAXCUT20_01: -10.119812 100%
  *     3 - MAXCUT20_09:  -56.740064 100%
  *     4 - MMDP:  -40 47%
  *     5 - MTTP100: -0.005 100%
  *     6 - MTTP200: -0.0025 100%
  *     7 - PEAKS: -1.0 100%
  */

public class GameCoaOptimization extends Game implements WindowCons
{
public static CellCoaOpt[][] oCellMatrix = new CellCoaOpt [iCellH][iCellV];// Cell matrix, to be accessed from VisorWorld

public static int iProblemTypeI = 0;								// Number linked with oProblemI to select in menus
public static ProblemI oProblemI;
public static double dAlfa = 0.1;
public static double dBeta = 0.1;
public static double dGamma = 0.8;

public static double dMEDValFun = 0;                 // Stores the functional average
public static double dMINValFun = Double.MAX_VALUE;  // Stores the lowest value
public static double dMAXValFun = Double.MIN_VALUE;  // Stores the highest value

public static Vector oVValFun = new Vector (1,1);	 // Contains the functional values: minimum, average and maximum
protected static int iTotNumChildren = iTotNumCells;        // Number of total children cells in the new generation



/**
 * This is the class constructor
 *
 */
public GameCoaOptimization () {
  super();
 
  //iAlgorithm = icGA;
  iAlgorithm = iEACO;
  // Here we change the problem, from the packet "problems":
  oProblemI = new MMDP();
  iProblemTypeI = 4;			// Value that corresponds to MMDP()
  //Here we change the problem, from the packet "problems":

  iNumActions = 3;                    // 3 options: Independent (IC), Coalition (CC) or Leader (LC)
  iVisorShow = 0;                     // 0: Coalitions y 10: Solutions

  iTotPosMatrix = 400;								// Standard number of cells in the matrix
}

/**
  * This is the class constructor
  *
  */
public GameCoaOptimization (MainWindow oVentAux) {
  this();
  oMainWindow = oVentAux;
}



/**
  * This method initializes the games when we start a new one
  *
  */
public void vNewGame() {
  super.vNewGame();

  switch (iProblemTypeI) {
    case 0:  oProblemI = new ECC(); break;
    case 1:  oProblemI = new MAXCUT100(); break;
    case 2:  oProblemI = new MAXCUT20_01(); break;
    case 3:  oProblemI = new MAXCUT20_09(); break;
    case 4:  oProblemI = new MMDP(); break;
    case 5:  oProblemI = new MTTP100(); break;
    case 6:  oProblemI = new MTTP200(); break;
    case 7:  oProblemI = new PEAK(); break;
  }
  
  Game.oCellMatrix = null;
  oCellMatrix = new CellCoaOpt [Game.iCellH][Game.iCellV];

  int iTipoCell = 0;
  int iAction;
  oVTextAction = new Vector (1,1);
  oVTextAction.add ("IC");           // IC == 0, Independent Cells
  oVTextAction.add ("CC");           // CC == 1, Coalition Cells
  oVTextAction.add ("CN");           // NC == 2, Coalitions Number

  oVValFun = new Vector (1,1);
  for (int i=0; i<iNumActions; i++)
    oVValFun.add (new Vector (1,1));

  iTotNumCells=0;
  for (int x=0; x<iCellH; x++)         // Initializing the cell matrix as a function of
    for (int y=0; y<iCellV; y++) {     // dFrecCoop (portion of cooperators)
      if (dProbEmpty > 0.0)
        if (dProbEmpty > Math.random()) {
          oCellMatrix[x][y] = null;        
          continue;
          }

      iAction = 0;
      imCellsType[iTipoCell]++;
      imCellsAction[iAction]++;
      iTotNumCells++;
      oCellMatrix[x][y] = new CellCoaOpt (x, y, iTipoCell, iAction);
      }
  
  Game.oCellMatrix = oCellMatrix;
  oVectorCells = ovCells2Vector (oCellMatrix);

  switch (iNetType) {
    case 0:   vSetNeighborsSpatialRadio (oCellMatrix); break;
    case 1:   vSetNeighborsSmallWorld (oCellMatrix); break;
    case 2:   vSetNeighborsScaleFree (oCellMatrix); break;
    case 3:   vSetNeighborsRandomNetwork (oCellMatrix); break;
  }
  
  iTotNumChildren = iTotNumCells;
  

  if ( (iNewGame == 0) && (MainWindow.iBatchMode < 2) ) {
	
	MainWindow.oMIWindow[iFREQxACTION].setEnabled (true);
	MainWindow.oMIWindow[iCHANGESxGEN].setEnabled (true);
	MainWindow.oMIWindow[iFUN_VALUES].setEnabled (true);
	  
	JPanelMainWindow.oJLabelInfo.setText ("Problem: "+GameCoaOptimization.iProblemTypeI);
			
	if (Game.iAlgorithm == Game.icGA) {
	  oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (cGA)");
	  Game.iVisorShow = 10;
	} else {
	  oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (EACO)");
	  Game.iVisorShow = 0;
	}  

	if (MainWindow.iBatchMode == 0) {
	  MainWindow.omDlGraf[iFREQxACTION] = new DlGraphics (oMainWindow, " CellNet: Frequency per Action", false, iFREQxACTION);
	  MainWindow.omDlGraf[iFREQxACTION].setVisible(true);
      MainWindow.omDlGraf[iCHANGESxGEN] = new DlGraphics (oMainWindow, " CellNet: Action Changes", false, iCHANGESxGEN);
      MainWindow.omDlGraf[iCHANGESxGEN].setVisible(true);
      MainWindow.omDlGraf[iFUN_VALUES] = new DlGraphics (oMainWindow, " CellNet: Functional Values", false, iFUN_VALUES);
      MainWindow.omDlGraf[iFUN_VALUES].setVisible(true);
	}
  }
  
  iNewGame++;
}




/**
  * This method contains the sequence of actions per cycle
  */
public void vRunLoop() {
  double 	dWorst = -Double.MAX_VALUE,
  				dValuationTot = 0;
  CellCoaOpt oWorst=null, oLeader;
  
  iNumGen++;                            // Increasing the number of generations (games iterations)
  iNumChanges = 0;

  for (int y=0; y<iCellV; y++)					// Common code
  for (int x=0; x<iCellH; x++) {				// Every cell determines the value of the objective function
    oCellMatrix[x][y].vCalcValFun ();
  	if (dWorst < oCellMatrix[x][y].dGetValFun()) {
  	  dWorst = oCellMatrix[x][y].dGetValFun();
  	  oWorst = oCellMatrix[x][y];
  	}
  }

  if (Math.random() < dProbRewiring) {
    if (Math.random() < dProbRewireRandom)					// Change the worst in the neighborhood
      oWorst.vRewireRandom ();
    else
      oWorst.vRewire2BestMate ();
    }
  
  
  if (iAlgorithm == iEACO) {                    		// Coalitions are only used by EACO
	  dValuationTot=0;
	  oVCoaLeaders = new Vector (1,1);
	  for (int y=0; y<iCellV; y++)
	  for (int x=0; x<iCellH; x++)     								// Every leader cell determines the value of its coalition
	    if (oCellMatrix[x][y].bIsLeader()) {    			// If it is a leader
	      oVCoaLeaders.add (oCellMatrix[x][y]);
	      oCellMatrix[x][y].vCalcQuality ();
	      dValuationTot += oCellMatrix[x][y].dGetQuality ();
	    }
	    else if (! oCellMatrix[x][y].bIsCoaMember()) {   			// It is not a leader neither a coalition member -> Independent
	      oCellMatrix[x][y].vCalcQuality ();           	 			// This is done here to store it, and compare it with vChangeCoalition
	      oCellMatrix[x][y].vNewGenOffspringNeighborhood (); 	// It mates with its neighbors
	    }
	  
  } else {														// Code for cGA
	  for (int y=0; y<iCellV; y++)
	  for (int x=0; x<iCellH; x++)     											// Every leader cell determines the value of its coalition
		oCellMatrix[x][y].vNewGenOffspringNeighborhood (); 		// It mates with its neighbors
  }

  
  for (int y=0; y<iCellV; y++)				// Common code
  for (int x=0; x<iCellH; x++)
    if (oCellMatrix[x][y].bIsIndependent())
      oCellMatrix[x][y].vUpdate ();												// Updating independent cells

  
  if (iAlgorithm == iEACO) {                    					// Coalitions are only used by EACO, cGA does not enter here (the rest is equal)
    for (int i=0; i<oVCoaLeaders.size(); i++) {           // Every coalition generates offspring, and the best substitute the worst
	  oLeader = (CellCoaOpt) oVCoaLeaders.elementAt (i);
	  oLeader.vNewGenOffspringValCoalition (dValuationTot);
	  //oLeader.vNewGenOffspringCoalition ();								// The simplest version: coa cells reproduce without quotes
	}
    
    for (int y=0; y<iCellV; y++)
    for (int x=0; x<iCellH; x++)
      if (! oCellMatrix[x][y].bIsLeader())        				// If it is not a leader -> independent or coalition member
        oCellMatrix[x][y].vChangeCoalition ();           	// Coalition change
  }

  
  vSetStatsGameOptimization();			// Common code
  if (MainWindow.iBatchMode < 2)
  	vSetGraphicValues();
  sTextStateBar = "NGen: "+iNumGen+"     Ind: "+imCellsType[0]+"  Coa: "+imCellsType[1]+" ("+imCellsType[2]+")"
             +"     Cells: "+iTotNumCells +"   N: "+iTotPosMatrix;
                      
                      
  }														// from vRunLoop()





/**
  * This method updataes the statistics of the stored values
  */
protected void vSetStatsGameOptimization() {
  double dAux;

  dMINValFun = Double.MAX_VALUE;              // This is the global minimum functional value
  dMAXValFun = Double.MIN_VALUE;              // This is the global maximum functional value
  dMEDValFun = 0;

  imCellsAction = new int [iNumActions];	  	// Reset
  imCellsType = new int [iNumTypes];		  		// Reset

  for (int y=0; y<iCellV; y++)
  for (int x=0; x<iCellH; x++) {

    dAux = oCellMatrix[x][y].dGetValFun();
    dMEDValFun += dAux;
    if (dMAXValFun < dAux) dMAXValFun = dAux;
    if (dMINValFun > dAux) dMINValFun = dAux;

    if (oCellMatrix[x][y].iGetHolonSize() > 1)         // If it is a leader
      imCellsType[2]++;
    else if (oCellMatrix[x][y].oGetLeader() != null)   // If it is in a coalition
      imCellsType[1]++;
    else                                               // If it is independent
      imCellsType[0]++;
  }

  dMEDValFun = dMEDValFun / iTotNumCells;
  }




/**
  * This method updates the values used for the graphics
  */
protected void vSetGraphicValues() {
  Vector oVect;
  
  oVChangesxGen.addElement (new Integer (100 * iNumChanges) / iTotNumCells); // Storing the action changes normalized
  while (oVChangesxGen.size() > MainWindow.iLastNGen)
  	oVChangesxGen.removeElementAt (0);
  
  for (int i=0; i<iNumActions; i++) {
    oVect = (Vector) oVFrecActions.elementAt (i);
    oVect.add (new Integer(100 * imCellsAction[i] / iTotNumCells));
    while (oVect.size() > MainWindow.iLastNGen)
      oVect.removeElementAt (0);
    }
  
  
  for (int i=0; i<oVValFun.size(); i++) {
    oVect = (Vector) oVValFun.elementAt (i);
    switch (i) {
      case 0: oVect.add (new Double (dMINValFun)); break;
      case 1: oVect.add (new Double (dMEDValFun)); break;
      case 2: oVect.add (new Double (dMAXValFun));
    }
    while (oVect.size() > MainWindow.iLastNGen)
      oVect.removeElementAt (0);   
  }  
  
}


}	// class GameOptimization

