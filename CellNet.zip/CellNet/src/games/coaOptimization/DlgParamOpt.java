package games.coaOptimization;

import javax.swing.*;

import window.JPanelMainWindow;
import window.MainWindow;

import java.awt.*;
import java.awt.event.*;

import games.*;



/**
* This class allows to obtain a dialog parameter window with two buttons: OK and Cancel.
*
* @author  Juan C. Burguillo Rial
* @version 1.0
*/
public class DlgParamOpt extends JDialog implements ActionListener, GameCons
{
private MainWindow oMainWindow;
	
private Label oLabel;
private JTextField  oTAlfa,
                    oTBeta,
                    oTGamma;
private Choice oChiAlgorithm, oChiProblemType;



/**
 * This is the Dialog constructor
 *
 * @param	oParent 	Pointer to the parent
 * @param	sTit   	Dialog title
 * @param	bBool 	Tells if the window is modal (true) or not
 */
public DlgParamOpt (JFrame oParent, String sTit, boolean bBool) {
  super (oParent, sTit, bBool);
  
  oMainWindow = (MainWindow) oParent;

  setBackground (Color.lightGray);
  setForeground (Color.black);

  setLayout(new GridLayout(6,2));

  oLabel = new Label (" Algorithm:", Label.LEFT);
  add (oLabel);
  oChiAlgorithm = new Choice();
  for (int i=0; i<sALGOR_OPTIM.length; i++)
    oChiAlgorithm.add (sALGOR_OPTIM[i]);
  oChiAlgorithm.select (Game.iAlgorithm);
  add (oChiAlgorithm);

  oLabel = new Label (" Problem:", Label.LEFT);
  add (oLabel);
  oChiProblemType = new Choice();
  for (int i=0; i<sPROBLEM_OPTIM_I.length; i++)
    oChiProblemType.add (sPROBLEM_OPTIM_I[i]);
  oChiProblemType.select (GameCoaOptimization.iProblemTypeI);
  add (oChiProblemType);

  oLabel = new Label (" Size:", Label.LEFT);
  add (oLabel);
  oTAlfa = new JTextField(String.valueOf (GameCoaOptimization.dAlfa), 7);
  add (oTAlfa);

  oLabel = new Label (" Diversity:", Label.LEFT);
  add (oLabel);
  oTBeta = new JTextField(String.valueOf (GameCoaOptimization.dBeta), 7);
  add (oTBeta);

  oLabel = new Label (" Fitness:", Label.LEFT);
  add (oLabel);
  oTGamma = new JTextField(String.valueOf (GameCoaOptimization.dGamma), 7);
  add (oTGamma);

  JButton oBut = new JButton ("OK");
  oBut.addActionListener (this);
  add (oBut);
  oBut  = new JButton ("Cancel");
  oBut.addActionListener (this);
  add (oBut);

  setSize(new Dimension(300,300));
  setLocation (new Point (730, 0));
  setResizable(false);
  setVisible(true);
  }



/**
 * This method process all the events produced by this class
 *
 *	@param evt This is the event received
 */
public void actionPerformed (ActionEvent evt) {

  if ("OK".equals (evt.getActionCommand())) {
    Game.iAlgorithm = oChiAlgorithm.getSelectedIndex();

    GameCoaOptimization.iProblemTypeI = oChiProblemType.getSelectedIndex();
    JPanelMainWindow.oJLabelInfo.setText ("Problem: "+GameCoaOptimization.iProblemTypeI);
    JPanelMainWindow.vActivateButtons();

    if (Game.iAlgorithm == Game.icGA) {
      oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (cGA)");
      Game.iVisorShow = 10;
    } else {
      oMainWindow.setTitle (" CellNet:   " + sGAME_TYPE[Game.iGameType]+" (EACO)");
      Game.iVisorShow = 0;
    }

    GameCoaOptimization.dAlfa = Double.parseDouble (oTAlfa.getText());
    GameCoaOptimization.dBeta = Double.parseDouble (oTBeta.getText());
    GameCoaOptimization.dGamma = Double.parseDouble (oTGamma.getText());
    
    oMainWindow.vSetupThread();
  }

  dispose();
}

}	// from the class
