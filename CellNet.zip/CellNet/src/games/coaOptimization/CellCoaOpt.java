package games.coaOptimization;

import games.CellCoa;
import games.Game;

import java.util.Vector;


/**
 * This class implements the children cells to substitute the mothers
 * @author  Juan C. Burguillo Rial
 * @version 1.0
 */
class CellChild {
  boolean[] bmPoint = new boolean [GameCoaOptimization.oProblemI.numberOfVariables()];
  double dValFun = 0;                              // Functional value a that point
}








/**
 * This class implements the cells (points) in this simulation
 * @author  Juan C. Burguillo Rial
 * @version 1.0
 */
public class CellCoaOpt extends CellCoa {
protected CellCoaOpt oLeaderOpt=null;                 	// If LiderHolon == null, with LiderHolon -> ref. to Cell
protected double dQuality;                           		// Quality of an independent cell or a coalition

boolean bOJO=false;

//----------------------- Bernabé -----------------------------------
protected boolean[] bmPoint;                            // The point that this cell contains
protected boolean[] bmNewPoint;                         // New generated point
protected double dValFun;                               // Functional value of that point
//----------------------- Bernabé -----------------------------------






public CellCoaOpt (int x, int y, int iTipoCellAux, int iActionAux) {
  super (x, y, iTipoCellAux, iActionAux);
  oLeaderOpt = null;            // Initially cells have no Leader

//----------------------- Bernabé -----------------------------------
	// Initialize all cells to random values
	bmPoint = new boolean [GameCoaOptimization.oProblemI.numberOfVariables()];
	for (int i=0; i<GameCoaOptimization.oProblemI.numberOfVariables(); i++) {
		if (Math.random() <= 0.5)
			bmPoint[i] = true;
		else
			bmPoint[i] = false;
	}
//----------------------- Bernabé -----------------------------------
  }




public boolean bIsIndependent() {					// Hint: this method should be overwritten if oLeader is not used
  if ( (iGetHolonSize() == 1) && (oLeaderOpt == null) ) return true;
  else return false;
}

public boolean bIsCoaMember() {						// Hint: this method should be overwritten if oLeader is not used
  if (oLeaderOpt != null) return true;
  else return false;
  }

public CellCoaOpt oGetLeader ()
  {return oLeaderOpt;}

// This method is an extension of the previous one to return a pointer to itself if it is the leader
public CellCoaOpt oRecGetLeader () {
if (oVHolonParts.size() > 0)      // If it is the leader
  return this;
else
  return oLeaderOpt;
}

public void vNewLeader (CellCoaOpt oLiderHolonAux)
  {oLeaderOpt = oLiderHolonAux;}
  
public void vNewHolonPart (CellCoaOpt oHolonPart)
  {oVHolonParts.addElement(oHolonPart);}

public void vRemoveHolonPart (CellCoaOpt oHolonPart) {
  for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoaOpt oCell = (CellCoaOpt) oVHolonParts.elementAt(i);
    if (oCell == oHolonPart) {
      oVHolonParts.removeElementAt (i);
      return;
      }
    }
  }

public boolean bChangeLeaderOK (CellCoaOpt oLiderHolonOtro, CellCoaOpt oCellMax) {
  if (this == oLiderHolonOtro)
     return false;
  else for (int i=0; i<oVHolonParts.size(); i++) {
    CellCoaOpt oCell = (CellCoaOpt) oVHolonParts.elementAt(i);
    if (oCellMax == oCell)
      return false;
    }

  return true;
  }


public boolean[] bmGetPoint() {
  return bmPoint;
}

public void vUpdate() {
  bmPoint = bmNewPoint;
}

public double dGetValFun () {
  return dValFun;
}


public double dGetQuality () {
  if (oLeaderOpt != null)                       // If it has a leader
    return oLeaderOpt.dGetQuality();
  else
    return dQuality;
}




/**
  * This method calls to the function evaluate with the cell point to determine the functional value
  */
public void vCalcValFun () {
  dValFun = GameCoaOptimization.oProblemI.evaluate (bmPoint);
}



/**
  * This method calls to the function evaluate with the cell point to determine the functional value
  */
public double dCalcValFun (boolean[] bmPointAux) {
  return GameCoaOptimization.oProblemI.evaluate (bmPointAux);
}




/**
 * This method calculates the quality of a coalition or an independent cell,
 * using the hamming distance with its best member as a diversity measure
 * 
 */
public void vCalcQuality () {
  double dAux, dMin;
  double dNumCoaCells = 1.0 + oVHolonParts.size();
  double dAvg=0;		// Average value (minimum)
  double dDiv=0;		// Diversity
  CellCoaOpt oCell, oCellMin = null;

  dAvg += dValFun;
  dMin = dValFun;
  oCellMin = this;
	  
  for (int i=0; i<oVHolonParts.size(); i++) {
    oCell = (CellCoaOpt) oVHolonParts.elementAt (i);
    dAux = oCell.dGetValFun();
    dAvg += dAux;
    if (dAux < dMin) {
    	dMin = dAux;
    	oCellMin = oCell;
      }
  }
		  
  if (oCellMin != this)
    for (int i=0; i<GameCoaOptimization.oProblemI.numberOfVariables(); i++)	// Coalition leader
	  if (oCellMin.bmPoint[i] != bmPoint[i]) dDiv++;
  
  for (int i=0; i<oVHolonParts.size(); i++) {							// Coalition members
	oCell = (CellCoaOpt) oVHolonParts.elementAt (i);
	if (oCellMin != oCell)
	  for (int j=0; j<GameCoaOptimization.oProblemI.numberOfVariables(); j++)
        if (oCellMin.bmPoint[j] != oCell.bmPoint[j]) dDiv++;
  }

  
  dQuality =	GameCoaOptimization.dAlfa * dNumCoaCells / ((double) Game.iTotNumCells)
		  		+ GameCoaOptimization.dBeta * dDiv / dNumCoaCells
		  		- GameCoaOptimization.dGamma * dAvg / dNumCoaCells;
}	
	




/**
  * This method calculates the value of a coalition or an independent cell
  */
/*
public void vCalcValuation () {
  double dAux;
  double dNumCells = 1.0 + oVHolonParts.size();
  double dVar=0;
  double dAvg=0;
  CellCoaOpt oCell;

  dAvg += dValFun;										// Coalition leader
  for (int i=0; i<oVHolonParts.size(); i++) {			// Coalition members
    oCell = (CellCoaOpt) oVHolonParts.elementAt (i);
    dAvg += oCell.dGetValFun();
  }
  dAvg = dAvg / dNumCells;

  dAux = dValFun - dAvg;
  dVar = dAux * dAux;									// Coalition leader
  for (int i=0; i<oVHolonParts.size(); i++) {			// Coalition members
    oCell = (CellCoaOpt) oVHolonParts.elementAt (i);
    dAux = oCell.dGetValFun() - dAvg;
    dVar += dAux * dAux;
  }
  dVar = dVar / dNumCells;
  
  dQuality = GameOptimization.dAlfa * dNumCells + GameOptimization.dBeta * dVar - GameOptimization.dGamma * dAvg;
}
*/


/**
  * This method mutates some of the bits of a cell
  */
/*
public void vMutation () {
  for (int j=0; j<GameOptimization.oProblem.numberOfVariables(); j++) {
    if (Math.random() <= 1.0 / (double) GameOptimization.oProblem.numberOfVariables())
      if (bmPoint[j]) bmPoint[j] = false;
      else bmPoint[j] = true;
  }
}
*/


/**
 * This method recombines and mutates a new child from two parents.
 * 
 *  @param	oParent1		First Parent Cell
 *  @param	oParent2		Second Parent Cell
 */
private CellChild oGetNewChild (CellCoaOpt oParent1, CellCoaOpt oParent2) {
  int iCut1, iCut2;                               // Cut points to do the reproduction
  CellChild oCellChild = new CellChild ();

  // 1. We choose two cut points
  iCut1 = (int) (Math.random()*GameCoaOptimization.oProblemI.numberOfVariables());
  do {
	iCut2 = (int) (Math.random()*GameCoaOptimization.oProblemI.numberOfVariables());
  } while (iCut1==iCut2);

  if (iCut1 > iCut2) {
	int iAux = iCut1;
	iCut1 = iCut2;
	iCut2 = iAux;
  }

  // 2. oCellChild inherits the longest part from the best parent  (MINIMIZE)
  if ((iCut2 - iCut1) > GameCoaOptimization.oProblemI.numberOfVariables()/2) {
	if (oParent1.dGetValFun() > oParent2.dGetValFun()) {
	  System.arraycopy (oParent1.bmPoint, 0, oCellChild.bmPoint, 0, oParent2.bmPoint.length);
	  System.arraycopy (oParent2.bmPoint, iCut1+1, oCellChild.bmPoint, iCut1+1, iCut2-iCut1);
	} else {
	  System.arraycopy (oParent2.bmPoint, 0, oCellChild.bmPoint, 0, oParent2.bmPoint.length);
	  System.arraycopy (oParent1.bmPoint, iCut1+1, oCellChild.bmPoint, iCut1+1, iCut2-iCut1);
	}

  } else {

	if (oParent1.dGetValFun() > oParent2.dGetValFun()) {
	  System.arraycopy (oParent2.bmPoint, 0, oCellChild.bmPoint, 0, oParent2.bmPoint.length);
	  System.arraycopy (oParent1.bmPoint, iCut1+1, oCellChild.bmPoint, iCut1+1, iCut2-iCut1);
	} else {
	  System.arraycopy (oParent1.bmPoint, 0, oCellChild.bmPoint, 0, oParent2.bmPoint.length);
	  System.arraycopy (oParent2.bmPoint, iCut1+1, oCellChild.bmPoint, iCut1+1, iCut2-iCut1);
	}
  }

  // 3. Mutation applied to oCellChild
  for (int j=0; j<GameCoaOptimization.oProblemI.numberOfVariables(); j++) {
	if (Math.random() <= 1.0 / (double) GameCoaOptimization.oProblemI.numberOfVariables())
	  if (oCellChild.bmPoint[j]) oCellChild.bmPoint[j] = false;
	  else oCellChild.bmPoint[j] = true;
  }

  return oCellChild;
}




/**
  * This method is called if this cell is the leader, and it generates some offspring in the coalition as a function of the valuation
  */
public void vNewGenOffspringValCoalition (double dTotQuality) {
  int iNumChildren = (int) ( ((double) GameCoaOptimization.iTotNumChildren) * dQuality / dTotQuality);
  int iCut1, iCut2;                               // Cut points to do the reproduction
  boolean bInserted = false;
  CellChild oCellChild, oCellChildAux;
  CellCoaOpt oCell;
  CellCoaOpt oCellAux, oCellAux2;
  Vector<CellCoaOpt> oVOrderMothers = new Vector<CellCoaOpt> (1,1);
  Vector<CellChild> oVOrderChilds = new Vector<CellChild> (1,1);

    // If it cannot have offspring then return
  if (iNumChildren == 0) return;

    // Ordering coalition cells depending on its functional value (from lower to higher)
  oVOrderMothers.add (this);                         // Adding the leader
  for (int i=0; i<oVHolonParts.size(); i++) {
    oCell = (CellCoaOpt) oVHolonParts.elementAt (i);
    bInserted = false;
    for (int j=0; j<oVOrderMothers.size(); j++) {
      oCellAux = (CellCoaOpt) oVOrderMothers.elementAt (j);
      if (oCell.dGetValFun() < oCellAux.dGetValFun()) {
        oVOrderMothers.insertElementAt (oCell, j);
        bInserted = true;
        break;
      }
    }
    if (!bInserted)
      oVOrderMothers.add (oCell);
  }


      // iNumHijas are generated with the previous functional ordering and in a number proportional to the coalition valuation
  for (int i=0; i<iNumChildren; i++) {
	  
    oCell = (CellCoaOpt) oVOrderMothers.elementAt (i % oVOrderMothers.size());
    do {
      oCellAux = (CellCoaOpt) oVOrderMothers.elementAt ((int) (Math.random() * (double) oVOrderMothers.size()));
    } while (oCell == oCellAux);
    
    if (oVOrderMothers.size() > 2) {
      do {
        oCellAux2 = (CellCoaOpt) oVOrderMothers.elementAt ((int) (Math.random() * (double) oVOrderMothers.size()));
      } while (oCell == oCellAux2);

      if (oCellAux.dGetValFun() > oCellAux2.dGetValFun())
    	oCellAux = oCellAux2;
    }

    oCellChild = oGetNewChild (oCell, oCellAux);				// Generates a new child from its parents

    oCellChild.dValFun = dCalcValFun (oCellChild.bmPoint);

        // Children are ordered in oVOrdenChildren depending on the functional value (lower to higher)
    bInserted = false;
    for (int j=0; j<oVOrderChilds.size(); j++) {
      oCellChildAux = (CellChild) oVOrderChilds.elementAt (j);
      if (oCellChild.dValFun < oCellChildAux.dValFun) {
        oVOrderChilds.insertElementAt (oCellChild, j);
        bInserted = true;
        break;
      }
    }
    if (!bInserted)
      oVOrderChilds.add (oCellChild);
  }   // end for i (generation of iNumChildren)



      // The best children substitute parents
  for (int i=0; i<oVOrderMothers.size(); i++) {
    if (oVOrderChilds.size() == 0) break;
    oCell = (CellCoaOpt) oVOrderMothers.elementAt (i);
    oCellChild = (CellChild) oVOrderChilds.elementAt (0);
    if (oCellChild.dValFun <= oCell.dGetValFun()) {
      if (oCellChild.dValFun < oCell.dGetValFun())            	// Only accounting the change if it is better
        Game.iNumChanges++;
      oVOrderChilds.removeElementAt (0);                       	// Deleting this child
      oCellAux = (CellCoaOpt) oVOrderMothers.lastElement();    	// Taking the last of the parents
      oCellAux.bmPoint = oCellChild.bmPoint;                  	// That cell copies the child
      oCellAux.dValFun = oCellChild.dValFun;
      oVOrderMothers.insertElementAt(oCellAux, i);             	// Inserting the cell in the present position
      oVOrderMothers.removeElementAt(oVOrderMothers.size()-1);  // Deleting the cell from the last position
    }
  }

}     // public void vNuevaGeneracionValCoa (double dValoracionTot)





/**
  * This method is called if this cell is the leader, and it generates children without valuations nor functional ordering. 
  * Basically, each cell generates a child that substitutes her, if the child is better. This is a simpler scheme that needs
  * more generations to converge (4 times more in problem 4) and has less success (6 times lower in problem 4).
  * 
  */
public void vNewGenOffspringCoalition () {
  int iCell1, iCell2, iCut1, iCut2;           // Cut points to do the reproduction
  CellChild oCellChild;
  CellCoaOpt oCell, oCellAux, oCellAux2;
  Vector<CellCoaOpt> oVCoaCells = new Vector<CellCoaOpt> (1,1);

  oVCoaCells.add (this);                         // Adding the leader
  for (int i=0; i<oVHolonParts.size(); i++)
    oVCoaCells.add ((CellCoaOpt) oVHolonParts.elementAt (i));
  
  
  for (int i=0; i<oVCoaCells.size(); i++) {
	  
    oCell = (CellCoaOpt) oVCoaCells.elementAt (i);
    
    // A new child is generated by binary tournament in the coalition
    do {
      iCell1 = (int) (Math.random() * (double) oVCoaCells.size());
    } while (iCell1 == i);
    oCellAux = (CellCoaOpt) oVCoaCells.elementAt (iCell1);
    
    if (oVCoaCells.size() > 2) { 
      do {
        iCell2 = (int) (Math.random() * (double) oVCoaCells.size());
      } while ( (iCell2 == i) || (iCell2 == iCell1) );

      oCellAux2 = (CellCoaOpt) oVCoaCells.elementAt (iCell2);
      if (oCellAux.dGetValFun() > oCellAux2.dGetValFun())
        oCellAux = oCellAux2;
    }

    oCellChild = oGetNewChild (oCell, oCellAux);					// Generates a new child from its parents

    oCellChild.dValFun = dCalcValFun (oCellChild.bmPoint);

    if (oCellChild.dValFun < oCell.dValFun ) Game.iNumChanges++;    // Only if it is better
  
    if (oCellChild.dValFun <= oCell.dValFun)                        // Here <= to allow for diversity
      oCell.bmPoint = oCellChild.bmPoint;                          	// Child substitutes parent
    
  }   // for (int i=0; i<oVCoaCells.size(); i++)

}   // public void vNuevaGeneracionCoa ()






/**
  * This method generates children in the neighborhood
  */
public void vNewGenOffspringNeighborhood () {
  int iCut1, iCut2;                               // Cut points to do the reproduction
  CellChild oCellChild;
  CellCoaOpt oCellAux;
  CellCoaOpt oCellAux2;
  
  
    // A child is generated by a binary tournament with the neighborhood
  oCellAux = (CellCoaOpt) ovNeighbors.elementAt ((int) (Math.random() * (double) ovNeighbors.size()));
  if (ovNeighbors.size() > 1) {
	do {
      oCellAux2 = (CellCoaOpt) ovNeighbors.elementAt ((int) (Math.random() * (double) ovNeighbors.size()));
	} while (oCellAux == oCellAux2);
  
	if (oCellAux.dGetValFun() > oCellAux2.dGetValFun())
	  oCellAux = oCellAux2;
  }

  oCellChild = oGetNewChild (this, oCellAux);					// Generates a new child from its parents

  oCellChild.dValFun = dCalcValFun (oCellChild.bmPoint);

  if (oCellChild.dValFun < dValFun ) Game.iNumChanges++;     	// Only if it is the best
  
  if (oCellChild.dValFun <= dValFun)                         	// Here <= to allow for diversity
    bmNewPoint = oCellChild.bmPoint;                         	// The new child substitutes the independent cell
  else
    bmNewPoint = bmPoint;                                   	// When updating, the mother remains

}   // public void vNuevaGeneracionVec ()





/**
  * This method allows to change the coalition a cell belongs
  */
public void vChangeCoalition () {
  CellCoaOpt oNeighbor, oCellAux;
  CellCoaOpt oCellMax = null, oLiderHolonMax = null;
  boolean bCoaNear = false;
  double dNumMaxOthers = 2.0;                       // Use to choose the actions to do when there is deuce
  double dAux, dAvgAux = 0;
  double dQualityCellMax = -Double.MAX_VALUE;      // Initializing the best ones
  double dQualityCellMin = +Double.MAX_VALUE;      // Initializing the worst ones


  dQuality = dGetQuality();
  for (int i=0; i<ovNeighbors.size(); i++) {
    oNeighbor = (CellCoaOpt) ovNeighbors.elementAt(i);
    
    if (bIsCoaMember())
      if ( (oLeaderOpt == oNeighbor) || (oLeaderOpt == oNeighbor.oGetLeader()) ) {
        bCoaNear = true;
        continue;                               // If we have the same leader we continue to next
      }

    dAux = oNeighbor.dGetQuality();
    
    if (dAux > dQualityCellMax) {
      dNumMaxOthers = 2.0;         				// Reset for the first one
      dQualityCellMax = dAux;
      oCellMax = oNeighbor;
      oLiderHolonMax = oCellMax.oGetLeader ();
      }
    else if (dAux == dQualityCellMax)       	// If it is equal we selected by random
      if (Math.random() < 1.0/dNumMaxOthers) {
        dNumMaxOthers += 1.0;          			// Prob. is reduced for next one
        oCellMax = oNeighbor;
        oLiderHolonMax = oCellMax.oGetLeader ();
        }

    if (dAux < dQualityCellMin)
      dQualityCellMin = dAux;

    dAvgAux += dAux;
    } // del for i

  dAvgAux = dAvgAux / ((double) ovNeighbors.size());    // Average of valuations

  if (oCellMax == null) return;                           	// If it has not find a better cell -> returns

  // *************************************** INI: Changing coalition ************************************

  if (bOJO) System.out.println ("DEBUG: Soy "+sIdCell+"  dQuality: "+dQuality+"   dValoracionCellMin: "+dQualityCellMin);

  		// Independent (no leader neither coalition)
  if (bIsIndependent()) {
    if ( (dQuality <= dQualityCellMin) && (Math.random() < Game.dProbJoinCoa) ) {
      Game.iNumChanges++;														// If worst or equal (OJO) -> join the best one
      if (bOJO) System.out.println ("DEBUG 0 (Me uno a líder): Soy "+sIdCell);
      if (oLiderHolonMax == null) {              								// If CellMax has no leader
        vNewLeader (oCellMax);
        oCellMax.vNewHolonPart(this);
      } else {
        vNewLeader (oLiderHolonMax);
        oLiderHolonMax.vNewHolonPart(this);
      }
    }
  }

  		// If it belongs to a coalition
  else if (bIsCoaMember()) {

         // a) Isolated -> independence
    if (!bCoaNear) {
      Game.iNumChanges++;
      if (bOJO) System.out.println ("DEBUG 1 (Me independizo): Soy "+sIdCell);
      oLeaderOpt.vRemoveHolonPart (this);
      vNewLeader (null);
    }

         // b) If it is the worst or equal (OJO) -> change to others coalition
    else if (dQuality <= dQualityCellMin) {
      Game.iNumChanges++;
      if (bOJO) System.out.print ("DEBUG 2 (Cambio de coalición): Soy "+sIdCell+"  Mi Val: "+dQuality+"  Su Val: "+dQualityCellMax+"  dValMin: "+dQualityCellMin);
      if (bOJO) System.out.print ("  Mi líder es: "+oLeaderOpt);
      oLeaderOpt.vRemoveHolonPart (this);
      if (oLiderHolonMax == null) {              // If CellMax has no leader
        if (bOJO) System.out.println ("  Me uno a independiente: "+oCellMax);
        vNewLeader (oCellMax);
        oCellMax.vNewHolonPart(this);
      } else {
        if (bOJO) System.out.println ("  Me uno a coalición: "+oLiderHolonMax);
        vNewLeader (oLiderHolonMax);
        oLiderHolonMax.vNewHolonPart(this);
      }
    }


        // c) None of previous cases happen, but there is a rebellion -> independence
    else if (Math.random() < Game.dProbReb) {
      Game.iNumChanges++;
      if (bOJO) System.out.println ("DEBUG 3 (Rebelión): Soy "+sIdCell);
      oLeaderOpt.vRemoveHolonPart (this);
      vNewLeader (null);
    }
    
  }
// *************************************** FIN: Change of Coalition ************************************

}   // public void vChangeCoalition ()




/**
 * This method is used by a cell to rewire randomly to a 'possibly' better neighbor
 */
public void vRewireRandom () {
  double dWorst = -Double.MAX_VALUE;
  CellCoaOpt oWorst=null, oNeighbor, oCellSel;
  Vector ovMatesWorst, ovVecCellSel;
  
  for (int i=0; i<ovNeighbors.size(); i++) {							// Finding the worst neighbor
    oNeighbor = (CellCoaOpt) ovNeighbors.elementAt(i);
    if (dWorst < oNeighbor.dGetValFun()) {
      dWorst = oNeighbor.dGetValFun();
      oWorst = oNeighbor;
    	}
  }
  
  ovMatesWorst = oWorst.oVGetNeighbors();
  if (ovMatesWorst.size() == 1) return; 														// I can not leave a neighbor only connected to me
  else for (int i=0; i<Game.iMaxRandomAttempts; i++) {						// We try to rewire a certain number of times
		int iAux = (int) (Math.random() * (double) Game.oVectorCells.size());	
		oCellSel = (CellCoaOpt) Game.oVectorCells.elementAt (iAux);
	    
		if ( (oCellSel == this) || (bIsNeighbor (oCellSel)) || (dWorst < oCellSel.dGetValFun()) ) continue;
		else {																																	// Rewiring
		  ovVecCellSel = oCellSel.oVGetNeighbors();
		  ovVecCellSel.add (this);                                              // Adding myself to the neighbor
		  ovNeighbors.add (oCellSel);                                           // Adding that neighbor
		  ovNeighbors.remove (oWorst);					                                // Removing the worst
		  ovMatesWorst.remove (this);                                             // The worst removes me
		  break;
		}
  }
  
}





/**
 * This method is used by a cell to rewire randomly to a 'possibly' better neighbor
 */
public void vRewire2BestMate () {
	double dBest = Double.MAX_VALUE;
  double dWorst = -Double.MAX_VALUE;
  CellCoaOpt oBest=null, oWorst=null, oNeighbor, oCellAux;
  Vector ovMatesWorst, ovMatesBest, ovMatesMate;
  
  for (int i=0; i<ovNeighbors.size(); i++) {					// Finding the worst neighbor
    oNeighbor = (CellCoaOpt) ovNeighbors.elementAt(i);
    if (dWorst < oNeighbor.dGetValFun()) {
      dWorst = oNeighbor.dGetValFun();
      oWorst = oNeighbor;
    	}
  }
  
  ovMatesWorst = oWorst.oVGetNeighbors();
  if (ovMatesWorst.size() == 1) return; 							// I can not leave a neighbor only connected to me
  
	else for (int i=0; i<ovNeighbors.size(); i++) {			// Finding the best neighbor of my neighbors
	  oNeighbor = (CellCoaOpt) ovNeighbors.elementAt(i);
	  ovMatesMate = oNeighbor.oVGetNeighbors();
	  
	  for (int k=0; k<ovMatesMate.size(); k++) {
	  	oCellAux = (CellCoaOpt) ovMatesMate.elementAt(k);
	    if ( (oCellAux == this) || (bIsNeighbor (oCellAux)) || (dBest < oCellAux.dGetValFun()) ) continue;
	    else {
	      dBest = oCellAux.dGetValFun();
	      oBest = oCellAux;
	    } 
	  }
	  	
	}
	
	if (oBest != null) {																										// Rewiring
	  ovMatesBest = oBest.oVGetNeighbors();
	  ovMatesBest.add (this);                                              		// Adding myself to the neighbor
	  ovNeighbors.add (oBest);                                           		// Adding that neighbor
	  ovNeighbors.remove (oWorst);					                                // Removing the worst
	  ovMatesWorst.remove (this);                                             // The worst removes me
	}
  
}




}	// from the class

