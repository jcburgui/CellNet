/* ------------------------------------------
   File: SinCos.java
   Author: Juan C. Burguillo
   Description: Defines a trigonometric function for predicting.
   ------------------------------------------*/

package problems.prediction;

import games.coaPrediction.GameCoaPrediction;
import problems.Function;

import java.util.Vector;


public class ExternalData extends Function {

public static final int iNumInputVarCTE = 4;         		// Input Variables
private int iSample = 0;									// Present sample
private Vector ovSamples;
private int iSampleOrder = 0;								// Next vector position to sample
private Vector ovSampleOrder;								// Random set of sampling points




public ExternalData() {
  super();
  iNumInputVar = iNumInputVarCTE;
  ovSamples = GameCoaPrediction.ovTrainSamples;  
}



public ExternalData (int iNumInputVarAux) {
  super();
  iNumInputVar = iNumInputVarAux;
}


public void vSetTraining () {
  ovSamples = GameCoaPrediction.ovTrainSamples;
  vDefineSampleOrder (ovSamples.size());
  iSampleOrder = 0;
  iSample = ( (Integer) ovSampleOrder.elementAt(iSampleOrder)).intValue();  
}


public void vSetTesting () {
  ovSamples = GameCoaPrediction.ovTestSamples;
  vDefineSampleOrder (ovSamples.size());
  iSampleOrder = 0;
  iSample = ( (Integer) ovSampleOrder.elementAt(iSampleOrder)).intValue();  
}



public void vDefineSampleOrder (int iNumSamples) {
  Vector ovSampleOrderAux = new Vector (1,1);
  for (int i=0; i<iNumSamples; i++)
	ovSampleOrderAux.add (new Integer (i));
  
  ovSampleOrder = new Vector (1,1);
  while (ovSampleOrderAux.size() != 0) {
	int iAux = (int) (ovSampleOrderAux.size() * Math.random());
	ovSampleOrder.add (ovSampleOrderAux.elementAt(iAux));
	ovSampleOrderAux.removeElementAt (iAux);
  }

}


/**
  * Initialize all cells inputs to random values
  */
public double[] dmSetInput () {
  double[] dmPunto = new double [iNumInputVar];
  for (int i=0; i<iNumInputVar; i++)
	dmPunto[i] = 1.0 - 2.0 * Math.random();
    
  return dmPunto;
}


/**
 * Initialize all cells outputs to random values
 */
public double dSetOutput () {
  return (1.0 - 2.0 * Math.random());
}


/**
  * This is the function to train the network
  */
private double dTrainFunction () {
  Float oFloat = (Float) GameCoaPrediction.ovTrainSamples.elementAt (iSample);
  return oFloat.doubleValue();
}



/**
  * This is the function to train the network
  */
private double dTestFunction () {
  Float oFloat = (Float) GameCoaPrediction.ovTestSamples.elementAt (iSample);
  return oFloat.doubleValue();
}



/**
  * This method receive the input values and generates the next output value of the system.
  *
  * @return dOutput[]   is a matrix that contains Output (iNumVar + 1) values: Input samples + Next sample
  */
public double[] dmEval () {
  double[] dOutput = new double [iNumInputVar+1];    // Input variables + output one

  for (int i=0; i<iNumInputVar+1; i++) {
	if (GameCoaPrediction.bTraining)
	  dOutput[i] = dTrainFunction ();
	else
	  dOutput[i] = dTestFunction ();
	
    iSample++;
    if (iSample >= ovSamples.size())
      iSample = 0;
  }

  iSampleOrder++;
  if (iSampleOrder >= ovSampleOrder.size())
	iSampleOrder = 0;
  iSample = ( (Integer) ovSampleOrder.elementAt (iSampleOrder)).intValue();
  
  return dOutput;
}


}
