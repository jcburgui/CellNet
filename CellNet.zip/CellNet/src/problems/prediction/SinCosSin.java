/* ------------------------------------------
   File: SinCos.java
   Author: Juan C. Burguillo
   Description: Defines a trigonometric function for predicting.
   ------------------------------------------*/

package problems.prediction;

import games.coaPrediction.GameCoaPrediction;
import problems.Function;


public class SinCosSin extends Function {

public static final int iNumInputVarCTE = 8;               // Input Variables
public static final double dIncSampleCTE = 0.00125 * Math.PI;       // Distance between successive samples
public static final double dInitSampleCTE = 0.0;      // Initial point to sample



public SinCosSin() {
  super();
  iNumInputVar = iNumInputVarCTE;
  dIncSample = dIncSampleCTE;
  dInitSample = dInitSampleCTE;
}



public SinCosSin(int iNumInputVarAux, double dIncSampleAux, double dInitSampleAux) {
  super();
  iNumInputVar = iNumInputVarAux;
  dIncSample = dIncSampleAux;
  dInitSample = dInitSampleAux;
}



/**
  * Initialize all cells inputs to random values
  */
public double[] dmSetInput () {
	double[] dmPunto = new double [iNumInputVar];
	for (int i=0; i<iNumInputVar; i++)
		dmPunto[i] = 4.0 - 8.0 * Math.random();
    
  return dmPunto;
}


/**
 * Initialize all cells outputs to random values
 */
public double dSetOutput () {
  return (4.0 - 8.0 * Math.random());
}


/**
  * This is the function to predict
  */
private double dPredFunction (double x) {
  double y = 2.0 * Math.sin (x) - Math.cos (3*x) + Math.sin(5*x);
  return y;
}


/**
  * This method receive the input values and generates the next output value of the system.
  *
  * @return dOutput[]   is a matrix that contains the Output (iNumVar + 1) values: Input samples + Next sample
  */
public double[] dmEval () {
  double dSample = dInitSample;
  double[] dOutput = new double [iNumInputVar+1];    // Input variables + output one

  for (int i=0; i<iNumInputVar+1; i++) {
    dOutput[i] = dPredFunction (dSample);
    dSample += dIncSample;
  }

  if (GameCoaPrediction.bTraining)
	dInitSample = dIncSample * GameCoaPrediction.iNumTrainSamples * Math.random();     // To get a random position during training
  else
	dInitSample = dIncSample * GameCoaPrediction.iNumTestSamples * Math.random();     // To get a random position during testing
  
  return dOutput;
}


}
