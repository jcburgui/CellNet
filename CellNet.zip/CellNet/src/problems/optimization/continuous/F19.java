/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F19 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
	private double [][] a = {{4.0, 4.0, 4.0, 4.0}, {1.0, 1.0, 1.0, 1.0}, {8.0, 8.0, 8.0, 8.0},
			{6.0, 6.0, 6.0, 6.0}, {3.0, 7.0, 3.0, 7.0}, {2.0, 9.0, 2.0, 9.0}, {5.0, 5.0, 3.0, 3.0},
			{8.0, 1.0, 8.0, 1.0}, {6.0, 2.0, 6.0, 2.0}, {7.0, 3.6, 7.0, 3.6}};
	
	private double [] c = {0.1, 0.2, 0.2, 0.4, 0.4, 0.6, 0.3, 0.7, 0.5, 0.5};
	
	public F19() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 4; // num de genes del individuo
      maxFitness = -10.15319; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i<numberOfVariables(); i++)
      {
	      minAllowedValues.add(new Double(0.0));
		  maxAllowedValues.add(new Double(10.0));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {

	  double [][] matrix = new double [4][5];
	  double prod = 0;
	  double sum = 0;
	  
	  for (int i=0; i<5; i++){
		  prod = 0;
		  for (int j=0; j<4; j++)
			  prod += (individual[j] - a[i][j]) * (individual[j] - a[i][j]);
		  
		  sum += Math.pow(prod + c[i],-1);
	  }
	  
	  return -sum;
    
  } // F19
  
  
} // class F19
