/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F10 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
  public F10() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 30; // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-32.00));
  		maxAllowedValues.add(new Double(32.00));
      }
      
  } // 
  
  public F10(Integer vars) {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = vars.intValue(); // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-32.00));
  		maxAllowedValues.add(new Double(32.00));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {
    double fitness = 0.0;
    double gene;
    double inSqrt = 0;
    double cos = 0;
    
    int length = individual.length;
    
    for(int i = 0; i < length; i++) {
    	gene = individual[i];
    	inSqrt += gene*gene;
    	cos += Math.cos(2.0*Math.PI*gene);
    } //for
    
    return -20.0 * Math.exp(-0.2 * Math.sqrt((1.0/length)*inSqrt)) - Math.exp((1.0/length)*cos) + 20.0 + Math.E;
  } // F10
} // class F10
