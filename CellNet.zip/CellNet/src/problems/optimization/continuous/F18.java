/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F18 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
	public F18() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 2; // num de genes del individuo
      maxFitness = 3.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i<numberOfVariables(); i++)
      {
	      minAllowedValues.add(new Double(-2.0));
		  maxAllowedValues.add(new Double(2.0));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {

	  double prod1 = 1.0 + Math.pow(individual[0]+individual[1]+1.0,2) * (19.0-14.0*individual[0]+3.0*individual[0]*individual[0]-14.0*individual[1]+6.0*individual[0]*individual[1]+3.0*individual[1]*individual[1]);
	  double prod2 = 30.0 + Math.pow(2*individual[0]-3.0*individual[1],2)*(18.0-32.0*individual[0]+12.0*individual[0]*individual[0]+48.0*individual[1]-36.0*individual[0]*individual[1]+27.0*individual[1]*individual[1]); 
	  return prod1*prod2;
    
  } // F18
  
  
} // class F18
