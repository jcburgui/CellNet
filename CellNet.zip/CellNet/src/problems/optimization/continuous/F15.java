/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F15 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
	private double [] a = {0.1957, 0.1947, 0.1735, 0.1600, 0.0844, 0.0627, 0.0456, 0.0342, 0.0323, 0.0235, 0.0246};
	private double [] b = {0.25, 0.5, 1.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0};
 
	public F15() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 4; // num de genes del individuo
      maxFitness = 0.0003075; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-5.0));
  		maxAllowedValues.add(new Double(5.0));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {
    double fitness = 0.0;
    double gene;
    double sum = 0.0;

    int length = individual.length;
    
    for (int i=0; i<11; i++){
    	
//	    	gene = individual[i];
	    	
    	sum = a[i] - ((individual[0]*(b[i]*b[i]+b[i]*individual[1])) / (b[i]*b[i]+b[i]*individual[2]+individual[3]));
	    fitness += 	sum * sum;
	     
    }
    	
    return fitness;
    
  } // F15
  
  
} // class F15
