/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F3 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
  public F3() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 30; // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-100.0));
  		maxAllowedValues.add(new Double(100.0));
      }
      
  } // Rastrigin constructor
  
  public F3(Integer vars) {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = vars.intValue(); // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-100.0));
  		maxAllowedValues.add(new Double(100.0));
      }
      
  } // Rastrigin constructor
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {
    double fitness = 0.0;
    double gene;
    double sum = 0.0, prod = 1.0;
    int length = individual.length;
    
    double sum1 = 0.0;
    for(int i = 0; i < length; i++) {
    	for (int j=0; j<=i; j++)
    	{
    		gene = individual[i];
    		sum1 += gene; 
    	}
    	
    	sum += sum1*sum1;
    	sum1 = 0.0;
    } //for
    
    return sum;
  } // F3
} // class F3
