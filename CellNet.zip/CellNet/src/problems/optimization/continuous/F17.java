/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F17 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
	public F17() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 2; // num de genes del individuo
      maxFitness = 0.398; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      minAllowedValues.add(new Double(-5.0));
  	  maxAllowedValues.add(new Double(0.0));
  	  
  	  minAllowedValues.add(new Double(10.0));
	  maxAllowedValues.add(new Double(15.0));
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {

	  double sum = individual[1]-(5.1/(4.0*Math.PI))*individual[0]*individual[0]+(5.0/Math.PI)*individual[0]-6.0;
	  return sum*sum + 10.0*(1.0-1.0/(8.0*Math.PI))*Math.cos(individual[0]) + 10.0;
    
  } // F17
  
  
} // class F17
