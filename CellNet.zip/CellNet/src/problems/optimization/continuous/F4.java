/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F4 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
  public F4() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 30; // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-100.0));
  		maxAllowedValues.add(new Double(100.0));
      }
      
  } // 
  
  public F4(Integer vars) {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = vars.intValue(); // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-100.0));
  		maxAllowedValues.add(new Double(100.0));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {
    double fitness = 0.0;
    double gene;
    
    int length = individual.length;
    
    for(int i = 0; i < length; i++) {
    	gene = Math.abs(individual[i]);
    	
    	if (gene > fitness)
    		fitness = gene;
    } //for
    
    return fitness;
  } // F4
} // class F4
