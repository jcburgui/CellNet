/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F12 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
  public F12() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 30; // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-50.0));
  		maxAllowedValues.add(new Double(50.0));
      }
      
  } // 
  
  public F12(Integer vars) {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = vars.intValue(); // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-50.0));
  		maxAllowedValues.add(new Double(50.0));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {
    double fitness = 0.0;
    double gene;
    double sum = 0.0;
    double sum2 = 0.0;

    int length = individual.length;
    double []y = new double [length];
    
    length--;
    
    y[0] = 1.25 + 0.25*individual[0];
    for(int i = 0; i < length; i++) {
    	gene = individual[i+1];
    	
    	y[i+1] = 1.25 + 0.25*gene;
    	if (i < length-1)
    		sum += (y[i]-1.0)*(y[i]-1.0)*(1.0+10.0*Math.sin(Math.PI*y[i+1])*Math.sin(Math.PI*y[i+1]));
    	
    	sum2 += u(gene, 10.0, 100.0, 4.0);
    	
     } //for
    
    return (Math.PI/(double)length) * (10.0*Math.sin(Math.PI*y[0])*Math.sin(Math.PI*y[0]) + sum + (y[length]-1.0)*(y[length]-1.0) + sum2);
  } // F11
  
  private double u(double x, double a, double k, double m){
	  if (x>a)
		  return k*Math.pow((x-a),m);
	  else if (x<-a)
		  return k*Math.pow((-x-a),m);
	  
	  return 0.0;
	  }
} // class F11
