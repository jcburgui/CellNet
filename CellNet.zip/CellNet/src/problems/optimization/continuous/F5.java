/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F5 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
  public F5() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 30; // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-30.0));
  		maxAllowedValues.add(new Double(30.0));
      }
      
  } // 

  public F5(Integer vars) {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = vars.intValue(); // num de genes del individuo
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-30.0));
  		maxAllowedValues.add(new Double(30.0));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {
    double fitness = 0.0;
    double gene, gene2;
    
    int length = individual.length;
    length--;
    
    for(int i = 0; i < length; i++) {
    	gene = individual[i];
    	gene2 = individual[i+1];

    	fitness += 100.0 * (gene2-gene*gene)*(gene2-gene*gene) + (gene-1.0)*(gene-1.0);
    } //for
    
    return fitness;
  } // F5
} // class F5
