/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F16 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
	public F16() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 2; // num de genes del individuo
      maxFitness = -1.03162845; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-5.0));
  		maxAllowedValues.add(new Double(5.0));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {

	  return 4.0*individual[0]*individual[0] - 2.1*Math.pow(individual[0], 4) + (1.0/3.0)*Math.pow(individual[0], 6) + individual[0]*individual[1] - 4.0*individual[1]*individual[1] + 4.0*Math.pow(individual[1], 4);
    
  } // F16
  
  
} // class F16
