/*
 * Ackley.java
 *
 */


package problems.optimization.continuous;

//import jcell.*;
import problems.ProblemC;
import java.util.Vector;
import java.lang.Math;

public class F14 extends ProblemC{

        public Vector minAllowedValues;
        public Vector maxAllowedValues;
  
	private double [][] a = {{-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0},{-32.0,-32.0,-32.0,-32.0,-32.0,-16.0,-16.0,-16.0,-16.0,-16.0,0.0,0.0,0.0,0.0,0.0,16.0,16.0,16.0,16.0,16.0,32.0,32.0,32.0,32.0,32.0}};
 
	public F14() {
      super() ;

      //Target.maximize = false;
      //variables = 25; // num de genes del individuo
      variables = 2; // num de genes del individuo
//      maxFitness = 0.998004; // maximo valor de fitness
      maxFitness = 0.0; // maximo valor de fitness

      minAllowedValues = new Vector (numberOfVariables());
      maxAllowedValues = new Vector (numberOfVariables());
      
      for (int i=0; i< numberOfVariables(); i++)
      {
  		minAllowedValues.add(new Double(-65.536));
  		maxAllowedValues.add(new Double(65.536));
      }
      
  } // 
  
  // Count the number of 1's in the string
  public double eval(double[] individual) {
    double fitness = 0.0;
    double gene;
    double sum2 = 0.0;

    int length = individual.length;
    
    for (int j=0; j<25; j++){
    	double sum = 0.0;
	    for(int i = 0; i < length; i++) {
	    	gene = individual[i];
	    	
	    	sum += Math.pow(gene- a[i][j], 6.0);	
	     } //for
    
    
    	sum2 += 1.0 / ((double)j+sum); 
    }
    	
    return Math.pow(0.002+sum2, -1.0);
  } // F14
  
  
} // class F14
