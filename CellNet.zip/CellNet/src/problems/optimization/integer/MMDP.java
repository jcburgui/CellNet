/* ------------------------------------------
   File: MMDP.java
   Author: Mario Giacobini
   Description
   It defines a specific subclass of Problem.
   The Massively Multimodal Deceptive Problem
   ------------------------------------------*/

package problems.optimization.integer;

import problems.ProblemI;

public class MMDP extends ProblemI
{
	public static final int longitCrom = 240; // Length of chromosomes
	public static final double maxFitness = 40.0; // Maximum Fitness Value

    int subproblemsLength = 6;
    int subproblemsNumber = 40;

    public MMDP()   {
    	super();
		variables = longitCrom;
		super.maxFitness = maxFitness;
    }

   // Overwrite eval method from Problem class.
   // Returns the fitness of Individual ind
   public double eval(boolean[] ind)    {
      int totalOnes = 0;
      double partialFitness = 0.0;
      double fitness = 0.0;

      for (int i=0; i<subproblemsNumber; i++) {
    	  totalOnes = 0;
	  
		  for (int j=0; j<subproblemsLength; j++)
		      if (ind[i*subproblemsLength+j])
			  totalOnes++;
	
		  switch (totalOnes){
			  case 0: case 6: partialFitness = 1.0;
			      break;
			  case 1: case 5: partialFitness = 0.0;
			      break;
			  case 2: case 4: partialFitness = 0.360384;
			      break;
			  case 3: partialFitness = 0.640576;
			      break;
		  }
	
		  fitness = fitness+partialFitness;
	
	      }


      return -fitness;					// We negate it as EACO minimizes
   }
}
