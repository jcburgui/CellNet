/* ------------------------------------------
   File: PEAK.java
   Author: Mario Giacobini
   Description
   It defines a specific subclass of Problem.
   The P-PEAKS Problem
   ------------------------------------------*/

package problems.optimization.integer;
import problems.ProblemI;

public class PEAK extends ProblemI
{

	public static final int longitCrom = 100; // Length of chromosomes
	public static final double maxFitness = 1.0; // Maximum Fitness Value
	
	
	int problemLength = longitCrom;
	int numberOfPeaks = 100;

	static boolean[][] target;
	
	public PEAK() 	{
		super();
		variables = longitCrom;
		super.maxFitness = maxFitness;
		
		target = new boolean[longitCrom][numberOfPeaks];

		for (int x = 0; x<numberOfPeaks; x++)
			for (int y = 0; y<longitCrom; y++) 
				if (Math.random() <= 0.5)
					target[x][y] = true;
				else 
					target[x][y] = false;
	}

   // Overwrite eval method from Problem class.
   // Returns the fitness of Individual ind
   public double eval(boolean[] ind)    {
       int partialFitness = 0;
       int distance = 0;
       double fitness = 0.0;

	   for (int i=0; i<longitCrom; i++){
		   distance = 0;
		   for (int j=0; j<longitCrom; j++) {
		       if (!(target[i][j]^ind[j])) { 
		    	   distance++;
		       }
	     
			   if (distance > partialFitness) {
			       partialFitness = distance;
		//		   boolean a = r.nextBoolean();
			   }
		   }
       }

       fitness = (double)partialFitness/(double)longitCrom;
       return -fitness;					// We negate it as EACO minimizes
       

   }
}

