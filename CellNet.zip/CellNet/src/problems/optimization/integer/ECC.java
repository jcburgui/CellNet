/* ------------------------------------------
   File: ECC.java
   Author: Mario Giacobini
   Description
   It defines a specific subclass of Problem.
   The Error Correcting Code Problem
   ------------------------------------------*/

package problems.optimization.integer;

import problems.ProblemI;

public class ECC extends ProblemI {

	public static final int longitCrom = 144; // Length of chromosomes
	public static final double maxFitness = 0.0674; // Maximum Fitness Value

    int individualLength = 12;
    int halfCode = 12;

    public ECC()    {
    	super();
		variables = longitCrom;
		super.maxFitness = maxFitness;
    }
    
   // Overwrite eval method from Problem class.
   // Returns the fitness of Individual ind
   public double eval(boolean[] ind)    {
      double partialFitness = 0.0;
      int hamming = 0;
      double fitness = 0.0;

      for (int i=0; i<halfCode; i++) {
		  partialFitness += 1.0/(individualLength*individualLength);           // distance from its complementary
		  for (int j=0; j<halfCode; j++) {
		      if (j!=i) {
				  hamming = 0;
				  for (int k=0; k<individualLength; k++){
				      if (ind[i*individualLength+k]^ind[j*individualLength+k]) {  
					  hamming++;
				      }
				  }
			  partialFitness += 1.0/(hamming*hamming) + 1.0/((individualLength-hamming)*(individualLength-hamming));
		      }
		  }
      }
      fitness = 1.0/(2*partialFitness);                   
      return new Double(-fitness);		// We negate it as EACO minimizes
   }
}
